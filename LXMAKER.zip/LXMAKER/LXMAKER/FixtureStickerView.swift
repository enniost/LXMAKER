import SwiftUI
import SwiftData
import AppKit

struct FixtureStickerView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var stickerFields: [FixtureStickerField] = [
        FixtureStickerField(title: "Universe", assignedColumn: "", position: .topLeft),
        FixtureStickerField(title: "Address", assignedColumn: "", position: .topCenter),
        FixtureStickerField(title: "Mode", assignedColumn: "", position: .topRight),
        FixtureStickerField(title: "Plugbox", assignedColumn: "", position: .middleLeft),
        FixtureStickerField(title: "Plug", assignedColumn: "", position: .middleCenter),
        FixtureStickerField(title: "Function", assignedColumn: "", position: .middleRight),
        FixtureStickerField(title: "Position", assignedColumn: "", position: .bottomLeft),
        FixtureStickerField(title: "Distance", assignedColumn: "", position: .bottomCenter),
        FixtureStickerField(title: "DMX-CH", assignedColumn: "", position: .bottomRight)
    ]
    
    @State private var idColumnAssignment = ""
    @State private var typeColumnAssignment = ""
    @State private var logoOption: LogoOption = .none
    @State private var uploadedLogoData: Data? = nil
    @State private var showLogoImporter = false
    @State private var stickerData: [FixtureStickerData] = []
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canGenerateStickers: Bool {
        !idColumnAssignment.isEmpty && !typeColumnAssignment.isEmpty && stickerFields.allSatisfy { !$0.assignedColumn.isEmpty }
    }
    
    private func autoAssignColumns() {
        let columnMappings: [String: [String]] = [
            "Universe": ["universe", "univ", "u", "uni"],
            "Address": ["address", "addr", "dmx address", "dmx addr", "dmx", "a"],
            "Mode": ["mode", "m", "channel mode", "dmx mode"],
            "Plugbox": ["plugbox", "plug box", "pb", "box", "plugb"],
            "Plug": ["plug", "channel", "ch", "plug ch", "plug channel", "p"],
            "Function": ["function", "func", "type", "fixture type", "f"],
            "Position": ["position", "pos", "location", "loc", "place"],
            "Distance": ["distance", "dist", "d", "length", "meter", "m"],
            "DMX-CH": ["dmx-ch", "dmx ch", "dmx channel", "channel", "ch", "channels"]
        ]
        
        // ID-Spalte automatisch zuweisen
        if idColumnAssignment.isEmpty {
            let idKeywords = ["id", "number", "nr", "num", "fixture id", "fixture number", "fix id", "fix nr"]
            for column in availableColumns {
                if idKeywords.contains(where: { column.lowercased().contains($0) }) {
                    idColumnAssignment = column
                    break
                }
            }
        }
        
        // Typ-Spalte automatisch zuweisen
        if typeColumnAssignment.isEmpty {
            let typeKeywords = ["typ", "type", "fixture type", "gerät", "device", "model", "art", "bezeichnung"]
            for column in availableColumns {
                if typeKeywords.contains(where: { column.lowercased().contains($0) }) {
                    typeColumnAssignment = column
                    break
                }
            }
            
            // Wenn keine Übereinstimmung gefunden wurde, automatisch "leer lassen" wählen
            if typeColumnAssignment.isEmpty {
                typeColumnAssignment = "-- Leer lassen --"
            }
        }
        
        // Felder automatisch zuweisen
        for i in 0..<stickerFields.count {
            if stickerFields[i].assignedColumn.isEmpty {
                let fieldTitle = stickerFields[i].title
                var foundMatch = false
                
                if let keywords = columnMappings[fieldTitle] {
                    for column in availableColumns {
                        let columnLower = column.lowercased()
                        
                        // Exakte Übereinstimmung hat Priorität
                        if keywords.contains(columnLower) {
                            stickerFields[i].assignedColumn = column
                            foundMatch = true
                            break
                        }
                        
                        // Teilübereinstimmung als Fallback
                        if keywords.contains(where: { columnLower.contains($0) || $0.contains(columnLower) }) {
                            stickerFields[i].assignedColumn = column
                            foundMatch = true
                            break
                        }
                    }
                }
                
                // Wenn keine Übereinstimmung gefunden wurde, automatisch "leer lassen" wählen
                if !foundMatch {
                    stickerFields[i].assignedColumn = "-- Leer lassen --"
                }
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    headerView
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // ID & Type Column Assignment
                            idColumnView
                            
                            // Field Configuration
                            fieldConfigurationView
                            
                            // Logo Settings
                            logoSettingsView
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Preview
                        VStack(alignment: .leading, spacing: 15) {
                            previewView
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Action Button
                    Button("PDF erstellen") {
                        generateStickerData()
                        exportStickerPDF()
                    }
                    .disabled(!canGenerateStickers)
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .padding(.bottom, 20)
                }
                .padding(20)
            }
            .navigationTitle("Fixture Sticker")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1400, minHeight: 1000)
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
            .onAppear {
                // Automatische Spaltenzuordnung beim ersten Laden
                autoAssignColumns()
            }
        }
    }
    
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("🏷️ Fixture Sticker")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Erstelle Fixture-Etiketten im HERMA 4691 Format (66x33.8mm, 24 Etiketten pro A4)")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            if availableColumns.isEmpty {
                Text("⚠️ Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                    .font(.caption)
                    .foregroundColor(.red)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private var idColumnView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("ID/Hauptnummer-Spalte:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                HStack {
                    Text("ID-Spalte:")
                        .frame(width: 100, alignment: .leading)
                    
                    Picker("ID-Spalte", selection: $idColumnAssignment) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Typ-Spalte:")
                        .frame(width: 100, alignment: .leading)

                    
                    Picker("Typ-Spalte", selection: $typeColumnAssignment) {
                        Text("-- Auswählen --").tag("")
                        Text("-- Leer lassen --").tag("-- Leer lassen --")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Diese Spalte wird als große Hauptnummer oben links angezeigt")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text("Diese Spalte wird als Typ unter der ID angezeigt")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(15)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var fieldConfigurationView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Feld-Konfiguration (3x3 Layout):")
                .font(.headline)
                .fontWeight(.medium)
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 15), count: 3), spacing: 15) {
                ForEach(stickerFields.indices, id: \.self) { index in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(positionTitle(for: stickerFields[index].position))
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        TextField("Feldname", text: $stickerFields[index].title)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .font(.caption)
                        
                        Picker("Spalte", selection: $stickerFields[index].assignedColumn) {
                            Text("-- Auswählen --").tag("")
                            Text("-- Leer lassen --").tag("-- Leer lassen --")
                            ForEach(availableColumns, id: \.self) { column in
                                Text(column).tag(column)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .font(.caption)
                    }
                    .padding(8)
                    .background(getFieldBackgroundColor(for: stickerFields[index].assignedColumn))
                    .cornerRadius(8)
                }
            }
            
            Text("💡 Tipp: Felder ohne passende Spalte werden automatisch leer gelassen.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(15)
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var logoSettingsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Logo-Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                // Logo Option Selection
                Picker("Logo-Option", selection: $logoOption) {
                    ForEach(LogoOption.allCases, id: \.self) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: logoOption) { _, _ in
                    if logoOption != .upload {
                        uploadedLogoData = nil
                    }
                }
                
                // Upload button
                if logoOption == .upload {
                    HStack {
                        Button("Logo auswählen") {
                            showLogoImporter = true
                        }
                        .buttonStyle(.bordered)
                        
                        if uploadedLogoData != nil {
                            Button("Logo entfernen") {
                                uploadedLogoData = nil
                            }
                            .buttonStyle(.bordered)
                            .foregroundColor(.red)
                        }
                    }
                }
                
                // Logo Preview
                if logoOption == .upload {
                    if let logoData = uploadedLogoData, let nsImage = NSImage(data: logoData) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Logo-Vorschau:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                } else if logoOption == .habegger {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logo-Vorschau:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        HStack {
                            Rectangle()
                                .fill(Color(red: 0.8, green: 0.68, blue: 0.4))
                                .frame(height: 8)
                                .overlay(
                                    Text("HABEGGER")
                                        .font(.caption)
                                        .fontWeight(.bold)
                                        .foregroundColor(.black)
                                )
                        }
                        .frame(width: 150, height: 30)
                        .cornerRadius(4)
                        .overlay(
                            RoundedRectangle(cornerRadius: 4)
                                .stroke(Color.gray, lineWidth: 1)
                        )
                    }
                }
            }
        }
        .padding(15)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var previewView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Vorschau:")
                .font(.headline)
                .fontWeight(.medium)
            
            // Sample sticker preview
            VStack(spacing: 8) {
                ForEach(0..<min(4, project.fixtures.count), id: \.self) { index in
                    stickerPreview(for: project.fixtures[index])
                }
            }
            
            if project.fixtures.count > 4 {
                Text("... und \(project.fixtures.count - 4) weitere Etiketten")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(15)
        .background(Color.purple.opacity(0.1))
        .cornerRadius(10)
    }
    
    private func stickerPreview(for fixture: LightFixture) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    // ID Number (large)
                    Text(fixture.rawData[idColumnAssignment] ?? "")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    // Logo placeholder
                    if logoOption != .none {
                        Rectangle()
                            .fill(logoOption == .habegger ? Color(red: 0.8, green: 0.68, blue: 0.4) : Color.gray.opacity(0.3))
                            .frame(width: 40, height: 12)
                            .cornerRadius(2)
                            .overlay(
                                Text(logoOption == .habegger ? "HABEGGER" : "LOGO")
                                    .font(.caption2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.black)
                            )
                    }
                }
                
                // Typ unter ID
                if !typeColumnAssignment.isEmpty && typeColumnAssignment != "-- Leer lassen --" {
                    Text(fixture.rawData[typeColumnAssignment] ?? "")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                // 3x3 Grid
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 2), count: 3), spacing: 2) {
                    ForEach(stickerFields, id: \.position) { field in
                        VStack(alignment: .leading, spacing: 2) {
                            // Wert OBEN
                            Text(fixture.rawData[field.assignedColumn] ?? "")
                                .font(.caption)
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            // Titel UNTEN
                            Text(field.title)
                                .font(.caption2)
                                .foregroundColor(.gray)
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(2)
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(2)
                    }
                }
            }
            
            // Vertical project name
            if !project.name.isEmpty {
                VStack(spacing: 1) {
                    ForEach(Array(project.name.enumerated()), id: \.offset) { index, char in
                        Text(String(char))
                            .font(.caption2)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                            .rotationEffect(.degrees(0))
                    }
                }
                .frame(width: 12)
                .padding(.vertical, 4)
                .background(Color.gray.opacity(0.3))
                .cornerRadius(2)
            }
        }
        .padding(8)
        .background(Color.black)
        .cornerRadius(6)
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(Color.gray, lineWidth: 0.5)
        )
    }
    
    private func positionTitle(for position: FieldPosition) -> String {
        switch position {
        case .topLeft: return "Oben Links"
        case .topCenter: return "Oben Mitte"
        case .topRight: return "Oben Rechts"
        case .middleLeft: return "Mitte Links"
        case .middleCenter: return "Mitte Mitte"
        case .middleRight: return "Mitte Rechts"
        case .bottomLeft: return "Unten Links"
        case .bottomCenter: return "Unten Mitte"
        case .bottomRight: return "Unten Rechts"
        }
    }
    
    private func generateStickerData() {
        var stickers: [FixtureStickerData] = []
        
        for fixture in project.fixtures {
            let id = fixture.rawData[idColumnAssignment] ?? ""
            let type = typeColumnAssignment == "-- Leer lassen --" ? "" : (fixture.rawData[typeColumnAssignment] ?? "")
            
            var fieldData: [String: String] = [:]
            
            for field in stickerFields {
                if field.assignedColumn == "-- Leer lassen --" {
                    fieldData[field.title] = "" // Leer lassen
                } else {
                    fieldData[field.title] = fixture.rawData[field.assignedColumn] ?? ""
                }
            }
            
            stickers.append(FixtureStickerData(id: id, type: type, fields: fieldData))
        }
        
        self.stickerData = stickers
    }
    
    private func exportStickerPDF() {
        guard !idColumnAssignment.isEmpty else {
            showAlert(title: "Keine ID-Spalte ausgewählt", message: "Bitte wählen Sie eine Spalte für die ID/Hauptnummer aus.")
            return
        }
        
        guard !typeColumnAssignment.isEmpty else {
            showAlert(title: "Keine Typ-Spalte ausgewählt", message: "Bitte wählen Sie eine Spalte für den Typ aus oder wählen Sie 'Leer lassen'.")
            return
        }
        
        guard stickerFields.allSatisfy({ !$0.assignedColumn.isEmpty }) else {
            showAlert(title: "Fehlende Spaltenzuordnungen", message: "Bitte weisen Sie allen Feldern eine CSV-Spalte zu oder wählen Sie 'Leer lassen'.")
            return
        }
        
        // Bereite Logo-Daten vor
        var logoData: Data? = nil
        switch logoOption {
        case .none:
            logoData = nil
        case .upload:
            logoData = uploadedLogoData
        case .habegger:
            logoData = createHabeggerLogoData()
        }
        
        let pdfCreator = FixtureStickerPDFCreator()
        let pdfData = pdfCreator.createPDF(
            stickers: self.stickerData,
            fields: stickerFields,
            projectName: project.name,
            logoData: logoData
        )
        
        let filename = "Fixture_Sticker_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                showAlert(title: "PDF erstellt", message: "Die Fixture-Etiketten wurden erfolgreich als PDF gespeichert.")
            } catch {
                showAlert(title: "Fehler beim Speichern", message: "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)")
            }
        }
    }
    
    private func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.alertStyle = .informational
        alert.runModal()
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                let logoData = try Data(contentsOf: url)
                uploadedLogoData = logoData
                
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func createHabeggerLogoData() -> Data? {
        // Versuche zuerst das Logo aus den Assets zu laden
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            guard let tiffData = assetLogo.tiffRepresentation,
                  let bitmapRep = NSBitmapImageRep(data: tiffData),
                  let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
                return nil
            }
            return pngData
        }
        
        // Fallback: Erstelle das Logo programmatisch mit dem richtigen Design
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        // Clear background
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        // Draw gold bar (wichtiger Teil des Habegger-Logos)
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        // Draw "HABEGGER" text in bold
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        // Konvertiere zu PNG Data
        guard let tiffData = image.tiffRepresentation,
              let bitmapRep = NSBitmapImageRep(data: tiffData),
              let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
            return nil
        }
        
        return pngData
    }
    
    private func getFieldBackgroundColor(for assignedColumn: String) -> Color {
        if assignedColumn.isEmpty {
            return Color.red.opacity(0.05) // Rot für nicht zugeordnet
        } else if assignedColumn == "-- Leer lassen --" {
            return Color.yellow.opacity(0.05) // Gelb für leer lassen
        } else {
            return Color.gray.opacity(0.05) // Grau für zugeordnet
        }
    }
}

// MARK: - Data Models
struct FixtureStickerField: Identifiable {
    let id = UUID()
    var title: String
    var assignedColumn: String
    let position: FieldPosition
}

struct FixtureStickerData: Identifiable {
    let id = UUID()
    let mainId: String
    let type: String
    let fields: [String: String]
    
    init(id: String, type: String = "", fields: [String: String]) {
        self.mainId = id
        self.type = type
        self.fields = fields
    }
}

enum FieldPosition: CaseIterable {
    case topLeft, topCenter, topRight
    case middleLeft, middleCenter, middleRight
    case bottomLeft, bottomCenter, bottomRight
}

// MARK: - PDF Creator
class FixtureStickerPDFCreator {
    func createPDF(stickers: [FixtureStickerData], fields: [FixtureStickerField], projectName: String, logoData: Data?) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        // A4 dimensions
        let pageWidth: CGFloat = 595.2
        let pageHeight: CGFloat = 841.8
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        // HERMA 4691: 24 Etiketten pro A4 (3 Spalten x 8 Reihen)
        let stickersPerPage = 24
        let columns = 3
        let rows = 8
        
        // Etikett-Dimensionen in Points (66x33.8mm)
        let stickerWidth: CGFloat = 187.0  // 66mm in points
        let stickerHeight: CGFloat = 95.8  // 33.8mm in points
        
        // Berechne Margins für zentrierte Positionierung
        let totalWidth = CGFloat(columns) * stickerWidth
        let totalHeight = CGFloat(rows) * stickerHeight
        let marginX = (pageWidth - totalWidth) / 2
        let marginY = (pageHeight - totalHeight) / 2
        
        // Konvertiere Logo-Data zu CGImage falls vorhanden
        var logoCGImage: CGImage? = nil
        if let logoData = logoData {
            logoCGImage = createCGImageFromData(logoData)
        }
        
        let totalPages = Int(ceil(Double(stickers.count) / Double(stickersPerPage)))
        
        for page in 0..<totalPages {
            pdfContext.beginPDFPage(nil)
            
            let startIndex = page * stickersPerPage
            let endIndex = min(startIndex + stickersPerPage, stickers.count)
            let pageStickers = Array(stickers[startIndex..<endIndex])
            
            for (index, sticker) in pageStickers.enumerated() {
                let row = index / columns
                let col = index % columns
                
                let x = marginX + CGFloat(col) * stickerWidth
                let y = pageHeight - marginY - CGFloat(row + 1) * stickerHeight
                
                let stickerRect = CGRect(x: x, y: y, width: stickerWidth, height: stickerHeight)
                
                drawFixtureSticker(
                    context: pdfContext,
                    sticker: sticker,
                    fields: fields,
                    projectName: projectName,
                    rect: stickerRect,
                    logoCGImage: logoCGImage
                )
            }
            
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        return pdfData as Data
    }
    
    private func createCGImageFromData(_ data: Data) -> CGImage? {
        guard let dataProvider = CGDataProvider(data: data as CFData),
              let cgImage = CGImage(
                pngDataProviderSource: dataProvider,
                decode: nil,
                shouldInterpolate: true,
                intent: .defaultIntent
              ) else {
            // Falls PNG nicht funktioniert, versuche JPEG
            guard let dataProvider = CGDataProvider(data: data as CFData),
                  let cgImage = CGImage(
                    jpegDataProviderSource: dataProvider,
                    decode: nil,
                    shouldInterpolate: true,
                    intent: .defaultIntent
                  ) else {
                return nil
            }
            return cgImage
        }
        return cgImage
    }
    
    private func drawFixtureSticker(context: CGContext, sticker: FixtureStickerData, fields: [FixtureStickerField], projectName: String, rect: CGRect, logoCGImage: CGImage?) {
        let padding: CGFloat = 1
        let innerRect = rect.insetBy(dx: padding, dy: padding)
        
        // Etikett-Hintergrund
        context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        context.fill(rect)
        
        // Rahmen
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(rect)
        
        // Projektname vertikal GANZ RECHTS (außerhalb der Hauptfläche)
        let projectWidth: CGFloat = 16
        let projectRect = CGRect(x: innerRect.maxX - projectWidth, y: innerRect.minY, width: projectWidth, height: innerRect.height)
        if !projectName.isEmpty {
            drawRotatedText(context: context, text: projectName, rect: projectRect, fontSize: 5.5, bold: true)
        }
        
        // Hauptfläche (ohne Projektname-Bereich)
        let mainRect = CGRect(x: innerRect.minX, y: innerRect.minY, width: innerRect.width - projectWidth, height: innerRect.height)
        
        // Header-Bereich für ID und Logo (vergrößert für ID und Typ)
        let headerHeight: CGFloat = 30
        let headerRect = CGRect(x: mainRect.minX, y: mainRect.maxY - headerHeight, width: mainRect.width, height: headerHeight)
        
        // ID LINKS oben (weitere 2px nach oben und 3px nach rechts verschoben)
        let idRect = CGRect(x: headerRect.minX + 3, y: headerRect.minY + 14, width: headerRect.width * 0.6, height: 15)
        drawText(context: context, text: sticker.mainId, rect: idRect, fontSize: 17.5, bold: true, alignment: .left)
        
        // Typ unter der ID anzeigen (3px nach rechts verschoben)
        let typeValue = getTypeValue(from: sticker, fields: fields)
        if !typeValue.isEmpty {
            let typeRect = CGRect(x: headerRect.minX + 3, y: headerRect.minY + 2, width: headerRect.width * 0.6, height: 10)
            drawText(context: context, text: typeValue, rect: typeRect, fontSize: 8, bold: false, alignment: .left, color: .gray)
        }
        
        // Logo oben rechts
        if let logo = logoCGImage {
            let logoRect = CGRect(x: headerRect.maxX - 60, y: headerRect.minY + 2, width: 58, height: headerHeight - 4)
            let scaledLogoRect = calculateAspectFitRect(imageSize: CGSize(width: logo.width, height: logo.height), containerRect: logoRect)
            context.draw(logo, in: scaledLogoRect)
        }
        
        // 3x3 Grid nimmt den REST der Hauptfläche ein
        let gridRect = CGRect(x: mainRect.minX, y: mainRect.minY, width: mainRect.width, height: mainRect.height - headerHeight)
        
        let cellWidth = gridRect.width / 3
        let cellHeight = gridRect.height / 3
        
        for field in fields {
            let (row, col) = positionToGridCoordinates(field.position)
            
            let cellX = gridRect.minX + CGFloat(col) * cellWidth
            let cellY = gridRect.maxY - CGFloat(row + 1) * cellHeight
            let cellRect = CGRect(x: cellX, y: cellY, width: cellWidth, height: cellHeight)
            
            // Zell-Hintergrund (abwechselnd)
            if (row + col) % 2 == 0 {
                context.setFillColor(red: 0.97, green: 0.97, blue: 0.97, alpha: 1.0)
            } else {
                context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            }
            context.fill(cellRect)
            
            // Zell-Rahmen
            context.setStrokeColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
            context.setLineWidth(0.5)
            context.stroke(cellRect)
            
            let value = sticker.fields[field.title] ?? ""
            
            // Feld-Titel OBEN (4px nach oben verschoben)
            let titleRect = CGRect(x: cellX + 2, y: cellY + cellHeight - 8, width: cellWidth - 4, height: 10)
            drawText(context: context, text: field.title + ":", rect: titleRect, fontSize: 5.0, bold: false, alignment: .left, color: .gray)
            
            // Feld-Wert UNTEN (0.5 Punkte größer)
            let valueRect = CGRect(x: cellX + 2, y: cellY + 7, width: cellWidth - 4, height: cellHeight - 16)
            drawText(context: context, text: value, rect: valueRect, fontSize: 8.0, bold: true, alignment: .center)
        }
    }
    
    private func getTypeValue(from sticker: FixtureStickerData, fields: [FixtureStickerField]) -> String {
        // Verwende den Typ-Wert direkt aus den Sticker-Daten
        return sticker.type
    }
    
    private func drawRotatedText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        context.saveGState()
        
        // Hintergrund für Projektname (hellgrau)
        context.setFillColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1.0)
        context.fill(rect)
        
        // Rahmen
        context.setStrokeColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(rect)
        
        // Text als ganzes um 90 Grad gedreht
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        let textBounds = CTLineGetBoundsWithOptions(line, .useOpticalBounds)
        
        // Rotationszentrum setzen
        let centerX = rect.midX
        let centerY = rect.midY
        
        // Transformationsmatrix für 90-Grad-Rotation
        context.translateBy(x: centerX, y: centerY)
        context.rotate(by: .pi / 2) // 90 Grad im Uhrzeigersinn
        
        // Text zentriert positionieren
        let textX = -textBounds.width / 2
        let textY = -textBounds.height / 2
        
        context.textPosition = CGPoint(x: textX, y: textY)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        
        context.restoreGState()
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool, alignment: NSTextAlignment = .left, color: NSColor = .black) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: color
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        
        let textBounds = CTLineGetBoundsWithOptions(line, .useOpticalBounds)
        var textPosition = CGPoint(x: rect.minX, y: rect.minY)
        
        // Horizontale Ausrichtung
        if alignment == .center {
            textPosition.x = rect.midX - textBounds.width / 2
        } else if alignment == .right {
            textPosition.x = rect.maxX - textBounds.width
        }
        
        // Vertikale Zentrierung
        textPosition.y = rect.minY + (rect.height - textBounds.height) / 2
        
        context.textPosition = textPosition
        
        // Setze Textfarbe
        if color == .gray {
            context.setFillColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1.0)
        } else {
            context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        }
        
        CTLineDraw(line, context)
        context.restoreGState()
    }
    
    private func positionToGridCoordinates(_ position: FieldPosition) -> (row: Int, col: Int) {
        switch position {
        case .topLeft: return (0, 0)
        case .topCenter: return (0, 1)
        case .topRight: return (0, 2)
        case .middleLeft: return (1, 0)
        case .middleCenter: return (1, 1)
        case .middleRight: return (1, 2)
        case .bottomLeft: return (2, 0)
        case .bottomCenter: return (2, 1)
        case .bottomRight: return (2, 2)
        }
    }
    
    private func calculateAspectFitRect(imageSize: CGSize, containerRect: CGRect) -> CGRect {
        let imageAspectRatio = imageSize.width / imageSize.height
        let containerAspectRatio = containerRect.width / containerRect.height
        
        var resultRect = containerRect
        
        if imageAspectRatio > containerAspectRatio {
            resultRect.size.height = containerRect.width / imageAspectRatio
            resultRect.origin.y = containerRect.origin.y + (containerRect.height - resultRect.height) / 2
        } else {
            resultRect.size.width = containerRect.height * imageAspectRatio
            resultRect.origin.x = containerRect.origin.x + (containerRect.width - resultRect.width) / 2
        }
        
        return resultRect
    }
}