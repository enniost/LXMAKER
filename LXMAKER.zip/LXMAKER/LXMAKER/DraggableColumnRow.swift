import SwiftUI

struct DraggableColumnRow: View {
    let column: String
    let index: Int
    @Binding var selectedColumns: [String]
    @State private var isDragging = false
    
    var body: some View {
        HStack(spacing: 12) {
            // Drag Handle
            Image(systemName: "line.3.horizontal")
                .font(.body)
                .foregroundColor(.gray)
                .padding(.leading, 4)
            
            // Positions-Nummer
            Text("\(index + 1)")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
                .frame(width: 25)
            
            // Spalten-Name
            Text(column)
                .font(.body)
                .foregroundColor(.primary)
            
            Spacer()
            
            // Entfernen-Button
            Button(action: {
                selectedColumns.remove(at: index)
            }) {
                Image(systemName: "minus.circle.fill")
                    .font(.body)
                    .foregroundColor(.red)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(isDragging ? Color.blue.opacity(0.2) : Color.blue.opacity(0.1))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.blue.opacity(0.3), lineWidth: 1)
        )
        .scaleEffect(isDragging ? 1.05 : 1.0)
        .shadow(color: isDragging ? .black.opacity(0.3) : .clear, radius: isDragging ? 8 : 0)
        .animation(.easeInOut(duration: 0.2), value: isDragging)
        .onDrag {
            isDragging = true
            return NSItemProvider(object: "\(index)" as NSString)
        }
        .onDrop(of: [.text], isTargeted: nil) { providers in
            handleDrop(providers: providers)
        }
        .onChange(of: isDragging) { _, newValue in
            if !newValue {
                // Drag ended, reset visual state
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    isDragging = false
                }
            }
        }
    }
    
    private func handleDrop(providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first else { return false }
        
        provider.loadObject(ofClass: NSString.self) { (object, error) in
            DispatchQueue.main.async {
                if let draggedIndexString = object as? String,
                   let draggedIndex = Int(draggedIndexString),
                   draggedIndex != index,
                   draggedIndex >= 0,
                   draggedIndex < selectedColumns.count {
                    
                    // Perform the move
                    let draggedColumn = selectedColumns[draggedIndex]
                    selectedColumns.remove(at: draggedIndex)
                    
                    // Calculate new insertion index
                    let newIndex = draggedIndex < index ? index - 1 : index
                    if newIndex >= 0 && newIndex <= selectedColumns.count {
                        selectedColumns.insert(draggedColumn, at: newIndex)
                    }
                }
                isDragging = false
            }
        }
        return true
    }
}