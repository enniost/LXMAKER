import SwiftUI
import SwiftData

@main
struct LXMAKERApp: App {
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            Project.self,
            LightFixture.self
        ])
        
        // Try persistent storage first
        let modelConfiguration = ModelConfiguration(
            schema: schema,
            isStoredInMemoryOnly: false  // Changed to false for persistent storage
        )
        
        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            // If persistent storage fails, fall back to in-memory and try to clean up
            print("Failed to create persistent ModelContainer: \(error)")
            print("Attempting to clean up and create new persistent storage...")
            
            // Try to clear any existing data files
            do {
                let url = modelConfiguration.url
                try FileManager.default.removeItem(at: url)
                print("Removed existing data file at: \(url)")
            } catch {
                print("Could not remove existing data file: \(error)")
            }
            
            // Try persistent storage again
            do {
                let cleanConfiguration = ModelConfiguration(
                    schema: schema,
                    isStoredInMemoryOnly: false
                )
                return try ModelContainer(for: schema, configurations: [cleanConfiguration])
            } catch {
                print("Still failed to create persistent storage: \(error)")
                print("Falling back to in-memory storage...")
                
                // Final fallback: in-memory storage
                let fallbackConfiguration = ModelConfiguration(
                    schema: schema,
                    isStoredInMemoryOnly: true
                )
                
                do {
                    return try ModelContainer(for: schema, configurations: [fallbackConfiguration])
                } catch {
                    fatalError("Could not create any ModelContainer: \(error)")
                }
            }
        }
    }()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(sharedModelContainer)
    }
}