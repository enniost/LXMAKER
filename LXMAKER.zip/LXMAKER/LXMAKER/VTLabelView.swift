import SwiftUI
import SwiftData
import AppKit
import CoreText

// MARK: - VT Label View

struct VTLabelView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var plugboxColumn = ""
    @State private var channelColumn = ""
    @State private var idColumn = ""
    @State private var customOrder = ""
    @State private var showPreview = false
    @State private var labelData: [VTLabelData] = []
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canGenerate: Bool {
        !plugboxColumn.isEmpty && !channelColumn.isEmpty && !idColumn.isEmpty
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    headerView
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // Column Configuration
                            columnConfigurationView
                            
                            // Order Configuration
                            orderConfigurationView
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Preview
                        VStack(alignment: .leading, spacing: 15) {
                            Text("Vorschau:")
                                .font(.headline)
                                .fontWeight(.medium)
                            
                            if showPreview && !labelData.isEmpty {
                                labelPreviewView
                            } else {
                                Text("Klicken Sie auf 'Vorschau anzeigen' um die VT-Etiketten zu sehen")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .multilineTextAlignment(.center)
                                    .frame(maxWidth: .infinity, maxHeight: 200)
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Action Buttons
                    actionButtonsView
                }
                .padding(20)
            }
            .navigationTitle("VT Label")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1200, minHeight: 900)
            .onAppear {
                autoAssignColumns()
            }
        }
    }
    
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("🏷️ VT Label Generator")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Erstellen Sie Etiketten für Plugboxen im Herma 4426 Format (8 Etiketten pro A4-Seite)")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            if availableColumns.isEmpty {
                Text("⚠️ Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                    .font(.caption)
                    .foregroundColor(.red)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private var columnConfigurationView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Spalten-Zuordnung:")
                .font(.headline)
                .fontWeight(.medium)
            
            Text("Wählen Sie die entsprechenden CSV-Spalten aus:")
                .font(.caption)
                .foregroundColor(.secondary)
            
            VStack(spacing: 12) {
                HStack {
                    Text("Plugbox:")
                        .frame(width: 80, alignment: .leading)
                    
                    Picker("Plugbox", selection: $plugboxColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Channel:")
                        .frame(width: 80, alignment: .leading)
                    
                    Picker("Channel", selection: $channelColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("ID:")
                        .frame(width: 80, alignment: .leading)
                    
                    Picker("ID", selection: $idColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
            }
        }
        .padding(15)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var orderConfigurationView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Reihenfolge der Plugboxen:")
                .font(.headline)
                .fontWeight(.medium)
            
            Text("Geben Sie die gewünschte Reihenfolge der Plugboxen ein (kommagetrennt):")
                .font(.caption)
                .foregroundColor(.secondary)
            
            VStack(spacing: 8) {
                TextField("z.B. Plugbox3,Plugbox1,Plugbox5", text: $customOrder)
                    .textFieldStyle(.roundedBorder)
                
                Text("Leer lassen für alphabetische Sortierung")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(15)
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var labelPreviewView: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("VT-Etiketten Vorschau (erste 4 Etiketten):")
                .font(.subheadline)
                .fontWeight(.medium)
            
            ScrollView {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 5), count: 2), spacing: 5) {
                    ForEach(Array(labelData.prefix(4).enumerated()), id: \.offset) { index, label in
                        VTLabelPreview(labelData: label)
                            .frame(width: 180, height: 120)
                            .border(Color.gray, width: 1)
                    }
                }
            }
            .frame(maxHeight: 300)
            
            Text("Gesamt: \(labelData.count) Etiketten")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
    
    private var actionButtonsView: some View {
        HStack(spacing: 25) {
            Button("Vorschau anzeigen") {
                generateLabelData()
            }
            .disabled(!canGenerate)
            .buttonStyle(.bordered)
            .controlSize(.large)
            
            Button("PDF erstellen") {
                generateLabelData()
                exportVTLabelPDF()
            }
            .disabled(!canGenerate)
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .padding(.bottom, 20)
    }
    
    private func autoAssignColumns() {
        let keywordMappings = [
            "plugbox": ["plugbox", "box", "steckdose"],
            "channel": ["channel", "kanal", "ch"],
            "id": ["id", "nummer", "number"]
        ]
        
        for column in availableColumns {
            let columnLower = column.lowercased()
            
            if plugboxColumn.isEmpty {
                if let keywords = keywordMappings["plugbox"],
                   keywords.contains(where: { columnLower.contains($0) }) {
                    plugboxColumn = column
                }
            }
            
            if channelColumn.isEmpty {
                if let keywords = keywordMappings["channel"],
                   keywords.contains(where: { columnLower.contains($0) }) {
                    channelColumn = column
                }
            }
            
            if idColumn.isEmpty {
                if let keywords = keywordMappings["id"],
                   keywords.contains(where: { columnLower.contains($0) }) {
                    idColumn = column
                }
            }
        }
    }
    
    private func generateLabelData() {
        var grouped: [String: [Int: [String]]] = [:]
        
        // Group data by plugbox and channel
        for fixture in project.fixtures {
            guard let plugbox = fixture.rawData[plugboxColumn],
                  let channelStr = fixture.rawData[channelColumn],
                  let channel = Int(channelStr),
                  let id = fixture.rawData[idColumn],
                  channel >= 1 && channel <= 6 else { continue }
            
            if grouped[plugbox] == nil {
                grouped[plugbox] = [:]
            }
            
            if grouped[plugbox]![channel] == nil {
                grouped[plugbox]![channel] = []
            }
            
            grouped[plugbox]![channel]!.append(id)
        }
        
        // Sort IDs within each channel
        for plugbox in grouped.keys {
            for channel in grouped[plugbox]!.keys {
                grouped[plugbox]![channel]!.sort()
            }
        }
        
        // Determine order of plugboxes
        var plugboxOrder: [String] = []
        if !customOrder.isEmpty {
            plugboxOrder = customOrder.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
            plugboxOrder = plugboxOrder.filter { grouped.keys.contains($0) }
        } else {
            plugboxOrder = Array(grouped.keys).sorted()
        }
        
        // Create label data
        labelData = plugboxOrder.compactMap { plugbox in
            guard let channels = grouped[plugbox] else { return nil }
            return VTLabelData(plugbox: plugbox, channels: channels)
        }
        
        showPreview = true
    }
    
    private func exportVTLabelPDF() {
        let pdfCreator = VTLabelPDFCreator()
        let pdfData = pdfCreator.createPDF(
            labelData: labelData,
            projectName: project.name
        )
        
        let filename = "VT_Etiketten_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die VT-Etiketten wurden erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
}

// MARK: - VT Label Preview

struct VTLabelPreview: View {
    let labelData: VTLabelData
    
    var body: some View {
        VStack(spacing: 0) {
            // Title
            Text(labelData.plugbox)
                .font(.system(size: 10, weight: .bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 4)
                .background(Color(red: 0.85, green: 0.77, blue: 0.54)) // Similar to #d8c48a
                .foregroundColor(.black)
            
            // Channel Grid
            HStack(spacing: 0) {
                ForEach(1...6, id: \.self) { channel in
                    VStack(spacing: 2) {
                        // Channel header
                        Text("CH \(channel)")
                            .font(.system(size: 8, weight: .bold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 2)
                            .background(Color.gray.opacity(0.3))
                            .overlay(
                                Rectangle()
                                    .stroke(Color.black, lineWidth: 0.5)
                            )
                        
                        // Channel content
                        VStack(spacing: 1) {
                            if let ids = labelData.channels[channel] {
                                ForEach(ids.prefix(8), id: \.self) { id in
                                    Text(id)
                                        .font(.system(size: 6))
                                        .frame(maxWidth: .infinity)
                                        .multilineTextAlignment(.center)
                                }
                            }
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.white)
                        .overlay(
                            Rectangle()
                                .stroke(Color.black, lineWidth: 0.5)
                        )
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(maxHeight: .infinity)
        }
        .background(Color.white)
        .overlay(
            Rectangle()
                .stroke(Color.black, lineWidth: 1)
        )
    }
}

// MARK: - Data Models

struct VTLabelData {
    let plugbox: String
    let channels: [Int: [String]]
}

// MARK: - PDF Creator

class VTLabelPDFCreator {
    private let pageWidth: CGFloat = 595.2   // A4 width in points (210mm)
    private let pageHeight: CGFloat = 841.8  // A4 height in points (297mm)
    private let scaleFactor: CGFloat = 3.0   // High resolution scaling factor
    
    // HERMA 4426 exact specifications
    private let labelWidth: CGFloat = 297.6  // 105mm in points
    private let labelHeight: CGFloat = 198.4 // 70mm in points
    
    // HERMA 4426 margins (8.5mm top/bottom, 0mm left/right)
    private let topMargin: CGFloat = 24.09   // 8.5mm in points
    private let bottomMargin: CGFloat = 24.09 // 8.5mm in points
    private let leftMargin: CGFloat = 0      // 0mm (labels fit exactly in width)
    private let rightMargin: CGFloat = 0     // 0mm
    
    func createPDF(labelData: [VTLabelData], projectName: String) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        // Create high-resolution context
        let scaledPageWidth = pageWidth * scaleFactor
        let scaledPageHeight = pageHeight * scaleFactor
        let pageRect = CGRect(x: 0, y: 0, width: scaledPageWidth, height: scaledPageHeight)
        var mediaBox = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight) // Keep original media box
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        // Set high-quality rendering
        pdfContext.interpolationQuality = .high
        pdfContext.setAllowsAntialiasing(true)
        pdfContext.setShouldAntialias(true)
        
        // Scale the entire context for high resolution
        pdfContext.scaleBy(x: scaleFactor, y: scaleFactor)
        
        let labelsPerPage = 8
        let totalPages = (labelData.count + labelsPerPage - 1) / labelsPerPage
        
        for pageIndex in 0..<totalPages {
            pdfContext.beginPDFPage(nil)
            
            let startIndex = pageIndex * labelsPerPage
            let endIndex = min(startIndex + labelsPerPage, labelData.count)
            let pageLabels = Array(labelData[startIndex..<endIndex])
            
            drawPage(
                context: pdfContext,
                pageLabels: pageLabels,
                pageRect: CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight) // Use original dimensions
            )
            
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        return pdfData as Data
    }
    
    private func drawPage(context: CGContext, pageLabels: [VTLabelData], pageRect: CGRect) {
        context.saveGState()
        
        // Draw labels in HERMA 4426 layout: 2 columns, 4 rows
        for (index, labelData) in pageLabels.enumerated() {
            let row = index / 2        // 0, 1, 2, 3
            let col = index % 2        // 0, 1
            
            // Calculate exact position according to HERMA 4426 layout
            let x = leftMargin + CGFloat(col) * labelWidth
            let y = pageRect.height - topMargin - CGFloat(row + 1) * labelHeight
            
            let labelRect = CGRect(x: x, y: y, width: labelWidth, height: labelHeight)
            
            drawLabel(context: context, labelData: labelData, rect: labelRect)
        }
        
        context.restoreGState()
    }
    
    private func drawLabel(context: CGContext, labelData: VTLabelData, rect: CGRect) {
        context.saveGState()
        
        // Set high-quality rendering for this label
        context.interpolationQuality = .high
        context.setAllowsAntialiasing(true)
        context.setShouldAntialias(true)
        
        // Label border (optional - remove for final printing)
        context.setStrokeColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(rect)
        
        let padding: CGFloat = 8.5 // 3mm padding inside label
        let contentRect = rect.insetBy(dx: padding, dy: padding)
        
        // Title background (golden yellow like HTML)
        let titleHeight: CGFloat = 40
        let titleRect = CGRect(x: contentRect.minX, y: contentRect.maxY - titleHeight, width: contentRect.width, height: titleHeight)
        
        context.setFillColor(red: 0.85, green: 0.77, blue: 0.54, alpha: 1.0) // #d8c48a
        context.fill(titleRect)
        
        // Title border
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(titleRect)
        
        // Title text
        drawHighQualityText(context: context, text: labelData.plugbox, rect: titleRect, fontSize: 18, bold: true, centered: true)
        
        // Channel grid
        let gridRect = CGRect(x: contentRect.minX, y: contentRect.minY, width: contentRect.width, height: contentRect.height - titleHeight - 4)
        let channelWidth = gridRect.width / 6
        
        for channel in 1...6 {
            let channelRect = CGRect(
                x: gridRect.minX + CGFloat(channel - 1) * channelWidth,
                y: gridRect.minY,
                width: channelWidth,
                height: gridRect.height
            )
            
            drawChannel(context: context, channel: channel, ids: labelData.channels[channel] ?? [], rect: channelRect)
        }
        
        context.restoreGState()
    }
    
    private func drawChannel(context: CGContext, channel: Int, ids: [String], rect: CGRect) {
        // Channel border
        context.setStrokeColor(red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(rect)
        
        // Channel header
        let headerHeight: CGFloat = 20
        let headerRect = CGRect(x: rect.minX, y: rect.maxY - headerHeight, width: rect.width, height: headerHeight)
        
        // Header background
        context.setFillColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1.0)
        context.fill(headerRect)
        
        // Header border
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(headerRect)
        
        // Header text
        drawHighQualityText(context: context, text: "CH \(channel)", rect: headerRect, fontSize: 10, bold: true, centered: true)
        
        // Content area
        let contentRect = CGRect(x: rect.minX, y: rect.minY, width: rect.width, height: rect.height - headerHeight)
        
        // Content background
        context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        context.fill(contentRect)
        
        // Draw IDs
        let idHeight: CGFloat = 12
        let maxIds = Int(contentRect.height / idHeight)
        
        for (index, id) in ids.prefix(maxIds).enumerated() {
            let idRect = CGRect(
                x: contentRect.minX + 2,
                y: contentRect.maxY - CGFloat(index + 1) * idHeight,
                width: contentRect.width - 4,
                height: idHeight
            )
            
            drawHighQualityText(context: context, text: id, rect: idRect, fontSize: 9.5, bold: false, centered: true)
        }
    }
    
    private func drawHighQualityText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool, centered: Bool) {
        context.saveGState()
        
        // Set ultra-high-quality rendering options
        context.setAllowsAntialiasing(true)
        context.setShouldAntialias(true)
        context.interpolationQuality = .high
        context.setRenderingIntent(.defaultIntent)
        context.setShouldSubpixelPositionFonts(true)
        context.setShouldSubpixelQuantizeFonts(true)
        
        // Create font with higher resolution
        let actualFontSize = fontSize * 1.5  // Increase font size for better quality
        let fontName = bold ? "Helvetica-Bold" : "Helvetica"
        let font = CTFontCreateWithName(fontName as CFString, actualFontSize, nil)
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = centered ? .center : .left
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black,
            .paragraphStyle: paragraphStyle
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        
        // Create CTLine for Core Text rendering
        let line = CTLineCreateWithAttributedString(attributedString)
        
        // Calculate text metrics
        let textBounds = CTLineGetBoundsWithOptions(line, .useOpticalBounds)
        let textWidth = textBounds.width
        let textHeight = textBounds.height
        
        // Calculate position based on alignment
        var x = rect.minX + 4
        if centered {
            x = rect.minX + (rect.width - textWidth) / 2
        }
        
        let y = rect.minY + (rect.height - textHeight) / 2
        
        // Set text position correctly for PDF coordinate system
        context.textMatrix = .identity
        context.textPosition = CGPoint(x: x, y: y)
        
        // Draw the text with Core Text for maximum quality
        CTLineDraw(line, context)
        
        context.restoreGState()
    }
}