import SwiftUI
import SwiftData
import UniformTypeIdentifiers
import AppKit

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Project.updatedAt, order: .reverse) private var projects: [Project]
    @State private var selectedProject: Project?
    @State private var isImporting: Bool = false
    @State private var showNewProjectSheet: Bool = false
    @State private var newProjectName: String = ""
    @State private var showError = false
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationSplitView {
            List(projects, selection: $selectedProject) { project in
                NavigationLink(value: project) {
                    VStack(alignment: .leading) {
                        Text(project.name)
                            .font(.headline)
                        Text("Updated: \(project.updatedAt.formatted())")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        if !project.fixtures.isEmpty {
                            Text("\(project.fixtures.count) Fixtures")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .swipeActions(allowsFullSwipe: false) {
                    Button(role: .destructive) {
                        deleteProject(project)
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
            }
            .navigationTitle("Projects")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button(action: { showNewProjectSheet = true }) {
                        Label("New Project", systemImage: "plus")
                    }
                }
            }
        } detail: {
            if let project = selectedProject {
                ProjectView(project: project, modelContext: modelContext)
            } else {
                Text("Select a project")
            }
        }
        .sheet(isPresented: $showNewProjectSheet) {
            NavigationStack {
                Form {
                    TextField("Project Name", text: $newProjectName)
                }
                .navigationTitle("New Project")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") {
                            showNewProjectSheet = false
                            newProjectName = ""
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Create") {
                            createProject()
                            showNewProjectSheet = false
                        }
                        .disabled(newProjectName.isEmpty)
                    }
                }
            }
        }
        .alert("Error", isPresented: $showError) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
    
    private func createProject() {
        let project = Project(name: newProjectName)
        modelContext.insert(project)
        do {
            try modelContext.save()
            selectedProject = project
            newProjectName = ""
        } catch {
            errorMessage = "Fehler beim Speichern: \(error.localizedDescription)"
            showError = true
        }
    }
    
    private func deleteProject(_ project: Project) {
        modelContext.delete(project)
        do {
            try modelContext.save()
            if selectedProject == project {
                selectedProject = nil
            }
        } catch {
            errorMessage = "Fehler beim Löschen: \(error.localizedDescription)"
            showError = true
        }
    }
}

struct ProjectView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @State private var searchText = ""
    @State private var isImporting: Bool = false
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var showPowerCalculation = false
    @State private var showDMXAnalyzer = false
    @State private var showVTLabel = false
    @State private var showNetwork = false
    @State private var showPatchList = false
    @State private var showFixtureSticker = false
    @State private var importedFileName = ""

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                TextField("Suchen...", text: $searchText)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 300)
                Spacer()
                Text("\(project.fixtures.count) Fixtures")
                    .foregroundColor(.secondary)
                    .font(.caption)
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            
            Divider()
            
            if project.fixtures.isEmpty {
                VStack(spacing: 20) {
                    Text("Keine Fixtures vorhanden")
                        .foregroundColor(.secondary)
                    Button(action: { isImporting = true }) {
                        Label("CSV importieren", systemImage: "square.and.arrow.down")
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                VStack(spacing: 0) {
                    TableToolbar(project: project, modelContext: modelContext, importedFileName: importedFileName)
                    
                    Divider()
                    
                    ResizableFixtureListView(
                        project: project,
                        fixtures: project.fixtures,
                        columnOrder: project.columnOrder,
                        searchText: searchText,
                        modelContext: modelContext
                    )
                }
            }
        }
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button(action: { showFixtureSticker = true }) {
                    Label("Fixture Sticker", systemImage: "rectangle.on.rectangle")
                }
                
                Button(action: { showPatchList = true }) {
                    Label("Patch Liste", systemImage: "list.clipboard")
                }
                
                Button(action: { showNetwork = true }) {
                    Label("Netzwerk", systemImage: "network")
                }
                
                Button(action: { showVTLabel = true }) {
                    Label("VT Label", systemImage: "tag.fill")
                }
                
                Button(action: { showDMXAnalyzer = true }) {
                    Label("DMX Analyse", systemImage: "waveform")
                }
                
                Button(action: { showPowerCalculation = true }) {
                    Label("Stromberechnung", systemImage: "bolt.fill")
                }
                
                Button(action: { isImporting = true }) {
                    Label("Import CSV", systemImage: "square.and.arrow.down")
                }
            }
        }
        .fileImporter(
            isPresented: $isImporting,
            allowedContentTypes: [.commaSeparatedText],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let files):
                guard let file = files.first else { return }
                
                do {
                    let securityScopedFile = file.startAccessingSecurityScopedResource()
                    defer {
                        if securityScopedFile {
                            file.stopAccessingSecurityScopedResource()
                        }
                    }
                    
                    // Store the imported file name
                    importedFileName = file.lastPathComponent
                    
                    let content = try String(contentsOf: file, encoding: .utf8)
                    let csvData = try CSVParser.parse(csvString: content)
                    let fixtures = try CSVParser.convertToFixtures(csvData: csvData)
                    
                    // Clear existing fixtures first (overwrite instead of append)
                    for fixture in project.fixtures {
                        modelContext.delete(fixture)
                    }
                    project.fixtures.removeAll()
                    
                    // Store the column order from new CSV
                    project.columnOrder = csvData.headers
                    
                    // Add new fixtures
                    project.fixtures.append(contentsOf: fixtures)
                    project.updatedAt = Date()
                    
                    try modelContext.save()
                    
                } catch CSVError.invalidFormat {
                    errorMessage = "Ungültiges CSV-Format. Bitte stellen Sie sicher, dass die Datei Semikolon-getrennt ist."
                    showError = true
                } catch CSVError.invalidData {
                    errorMessage = "Ungültige Daten in der CSV-Datei. Bitte überprüfen Sie die Spalten."
                    showError = true
                } catch {
                    errorMessage = "Fehler beim Importieren der Datei: \(error.localizedDescription)"
                    showError = true
                }
                
            case .failure(let error):
                errorMessage = "Fehler beim Öffnen der Datei: \(error.localizedDescription)"
                showError = true
            }
        }
        .sheet(isPresented: $showFixtureSticker) {
            FixtureStickerView(project: project, modelContext: modelContext)
        }
        .sheet(isPresented: $showPatchList) {
            PatchListView(project: project, modelContext: modelContext)
        }
        .sheet(isPresented: $showNetwork) {
            NetworkView(project: project, modelContext: modelContext)
        }
        .sheet(isPresented: $showVTLabel) {
            VTLabelView(project: project, modelContext: modelContext)
        }
        .sheet(isPresented: $showPowerCalculation) {
            PowerCalculationView(project: project, modelContext: modelContext)
        }
        .sheet(isPresented: $showDMXAnalyzer) {
            DMXUniverseView(project: project, modelContext: modelContext)
        }
        .alert("Fehler", isPresented: $showError) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
}

struct ResizableFixtureListView: View {
    @Bindable var project: Project
    let fixtures: [LightFixture]
    let columnOrder: [String]
    let searchText: String
    let modelContext: ModelContext
    
    @State private var sortColumn: String = ""
    @State private var sortAscending: Bool = true
    @State private var editingCell: String? = nil
    @State private var editingValue: String = ""
    
    private var columnHeaders: [String] {
        if !columnOrder.isEmpty {
            return columnOrder
        }
        
        var headers = Set<String>()
        for fixture in fixtures {
            headers.formUnion(fixture.rawData.keys)
        }
        return Array(headers).sorted()
    }
    
    var filteredAndSortedFixtures: [LightFixture] {
        var result = fixtures
        
        // Apply search filter
        if !searchText.isEmpty {
            result = result.filter { fixture in
                fixture.rawData.values.contains { value in
                    value.localizedCaseInsensitiveContains(searchText)
                }
            }
        }
        
        // Apply sorting
        if !sortColumn.isEmpty {
            result = result.sorted { fixture1, fixture2 in
                let value1 = fixture1.rawData[sortColumn] ?? ""
                let value2 = fixture2.rawData[sortColumn] ?? ""
                
                // Try to sort numerically if both values are numbers
                if let num1 = Int(value1), let num2 = Int(value2) {
                    return sortAscending ? num1 < num2 : num1 > num2
                } else if let num1 = Double(value1), let num2 = Double(value2) {
                    return sortAscending ? num1 < num2 : num1 > num2
                } else {
                    // Sort alphabetically
                    return sortAscending ? value1.localizedCaseInsensitiveCompare(value2) == .orderedAscending : value1.localizedCaseInsensitiveCompare(value2) == .orderedDescending
                }
            }
        }
        
        return result
    }
    
    var body: some View {
        ScrollView([.horizontal, .vertical]) {
            VStack(alignment: .leading, spacing: 0) {
                // Headers with resize handles and sort functionality
                HStack(spacing: 0) {
                    ForEach(Array(columnHeaders.enumerated()), id: \.offset) { index, header in
                        HStack(spacing: 0) {
                            Button(action: {
                                if sortColumn == header {
                                    sortAscending.toggle()
                                } else {
                                    sortColumn = header
                                    sortAscending = true
                                }
                            }) {
                                HStack(spacing: 4) {
                                    Text(header)
                                        .font(.headline)
                                        .foregroundColor(.primary)
                                    
                                    if sortColumn == header {
                                        Image(systemName: sortAscending ? "chevron.up" : "chevron.down")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                }
                                .frame(width: project.getColumnWidth(for: header), alignment: .leading)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 2)
                                .background(Color.gray.opacity(0.1))
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(PlainButtonStyle())
                            .overlay(
                                Rectangle()
                                    .stroke(Color.black)
                            )
                            
                            if index < columnHeaders.count - 1 {
                                ResizeHandle(
                                    column: header,
                                    project: project,
                                    modelContext: modelContext
                                )
                            }
                        }
                    }
                }
                .frame(height: 40)
                
                // Data rows
                ForEach(filteredAndSortedFixtures) { fixture in
                    HStack(spacing: 0) {
                        ForEach(Array(columnHeaders.enumerated()), id: \.offset) { index, header in
                            HStack(spacing: 0) {
                                EditableCellSimple(
                                    fixture: fixture,
                                    column: header,
                                    width: project.getColumnWidth(for: header),
                                    editingCell: $editingCell,
                                    editingValue: $editingValue,
                                    modelContext: modelContext
                                )
                                
                                if index < columnHeaders.count - 1 {
                                    Rectangle()
                                        .fill(Color.clear)
                                        .frame(width: 4)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

struct EditableCellSimple: View {
    @Bindable var fixture: LightFixture
    let column: String
    let width: CGFloat
    @Binding var editingCell: String?
    @Binding var editingValue: String
    let modelContext: ModelContext
    
    @FocusState private var isFocused: Bool
    
    private var cellValue: String {
        fixture.rawData[column] ?? ""
    }
    
    private var cellKey: String {
        "\(fixture.id)-\(column)"
    }
    
    private var isEditing: Bool {
        editingCell == cellKey
    }
    
    var body: some View {
        Group {
            if isEditing {
                TextField("", text: $editingValue)
                    .textFieldStyle(PlainTextFieldStyle())
                    .focused($isFocused)
                    .onAppear {
                        isFocused = true
                    }
                    .onSubmit {
                        saveValue()
                    }
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(2)
            } else {
                Text(cellValue)
                    .onTapGesture {
                        startEditing()
                    }
                    .contextMenu {
                        Button("Bearbeiten") {
                            startEditing()
                        }
                        Button("Kopieren") {
                            NSPasteboard.general.clearContents()
                            NSPasteboard.general.setString(cellValue, forType: .string)
                        }
                        Button("Einfügen") {
                            if let pastedText = NSPasteboard.general.string(forType: .string) {
                                fixture.rawData[column] = pastedText
                                saveChanges()
                            }
                        }
                    }
            }
        }
        .frame(width: width, alignment: .leading)
        .padding(.horizontal, 8)
        .border(Color.black)
        .onChange(of: isFocused) { _, focused in
            if !focused && isEditing {
                saveValue()
            }
        }
    }
    
    private func startEditing() {
        editingValue = cellValue
        editingCell = cellKey
    }
    
    private func saveValue() {
        fixture.rawData[column] = editingValue
        editingCell = nil
        saveChanges()
    }
    
    private func saveChanges() {
        do {
            try modelContext.save()
        } catch {
            print("Failed to save changes: \(error)")
        }
    }
}

struct ResizeHandle: View {
    let column: String
    @Bindable var project: Project
    let modelContext: ModelContext
    @State private var isHovering = false
    
    var body: some View {
        Rectangle()
            .fill(isHovering ? Color.blue.opacity(0.5) : Color.clear)
            .frame(width: 4)
            .contentShape(Rectangle())
            .onHover { hovering in
                isHovering = hovering
            }
            .gesture(
                DragGesture()
                    .onChanged { value in
                        let newWidth = project.getColumnWidth(for: column) + value.translation.width
                        project.setColumnWidth(for: column, width: newWidth)
                    }
                    .onEnded { _ in
                        do {
                            try modelContext.save()
                        } catch {
                            print("Failed to save column width: \(error)")
                        }
                    }
            )
    }
}

// MARK: - Table Views

struct TableToolbar: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    let importedFileName: String
    @State private var showAddColumnDialog = false
    @State private var newColumnName = ""
    @State private var showDeleteRowDialog = false
    @State private var selectedFixture: LightFixture?
    
    var body: some View {
        HStack {
            Button(action: { showAddColumnDialog = true }) {
                Label("Spalte hinzufügen", systemImage: "plus.circle")
            }
            .buttonStyle(.bordered)
            
            Button(action: { addNewRow() }) {
                Label("Zeile hinzufügen", systemImage: "plus.rectangle")
            }
            .buttonStyle(.bordered)
            
            Spacer()
            
            // Show imported file name if available
            if !importedFileName.isEmpty {
                VStack(alignment: .trailing, spacing: 2) {
                    Text("Importierte Datei:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text(importedFileName)
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                }
                .padding(.horizontal, 8)
            }
            
            Button(action: { exportToCSV() }) {
                Label("CSV exportieren", systemImage: "square.and.arrow.up")
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .sheet(isPresented: $showAddColumnDialog) {
            AddColumnDialog(
                columnName: $newColumnName,
                onAdd: { addColumn() },
                onCancel: { showAddColumnDialog = false }
            )
        }
        .alert("Zeile löschen", isPresented: $showDeleteRowDialog) {
            Button("Löschen", role: .destructive) {
                if let fixture = selectedFixture {
                    deleteRow(fixture)
                }
            }
            Button("Abbrechen", role: .cancel) { }
        } message: {
            Text("Möchten Sie diese Zeile wirklich löschen?")
        }
    }
    
    private func addColumn() {
        guard !newColumnName.isEmpty else { return }
        
        // Add column to all fixtures
        for fixture in project.fixtures {
            if fixture.rawData[newColumnName] == nil {
                fixture.rawData[newColumnName] = ""
            }
        }
        
        // Add to column order if not already present
        if !project.columnOrder.contains(newColumnName) {
            project.columnOrder.append(newColumnName)
        }
        
        saveChanges()
        newColumnName = ""
        showAddColumnDialog = false
    }
    
    private func addNewRow() {
        let newFixture = LightFixture(data: [:])
        
        // Initialize with empty values for all columns
        for column in project.columnOrder {
            newFixture.rawData[column] = ""
        }
        
        project.fixtures.append(newFixture)
        modelContext.insert(newFixture)
        saveChanges()
    }
    
    private func deleteRow(_ fixture: LightFixture) {
        if let index = project.fixtures.firstIndex(of: fixture) {
            project.fixtures.remove(at: index)
            modelContext.delete(fixture)
            saveChanges()
        }
    }
    
    private func exportToCSV() {
        let csvString = generateCSVString()
        
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.commaSeparatedText]
        savePanel.nameFieldStringValue = "\(project.name)_export.csv"
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try csvString.write(to: url, atomically: true, encoding: .utf8)
            } catch {
                print("Export failed: \(error)")
            }
        }
    }
    
    private func generateCSVString() -> String {
        var csvLines: [String] = []
        
        // Headers
        csvLines.append(project.columnOrder.joined(separator: ";"))
        
        // Data rows
        for fixture in project.fixtures {
            let rowData = project.columnOrder.map { column in
                let value = fixture.rawData[column] ?? ""
                // Escape semicolons and quotes
                if value.contains(";") || value.contains("\"") {
                    return "\"\(value.replacingOccurrences(of: "\"", with: "\"\""))\""
                }
                return value
            }
            csvLines.append(rowData.joined(separator: ";"))
        }
        
        return csvLines.joined(separator: "\n")
    }
    
    private func saveChanges() {
        do {
            try modelContext.save()
            project.updatedAt = Date()
        } catch {
            print("Failed to save changes: \(error)")
        }
    }
}

struct AddColumnDialog: View {
    @Binding var columnName: String
    let onAdd: () -> Void
    let onCancel: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Neue Spalte hinzufügen")
                .font(.headline)
            
            TextField("Spaltenname", text: $columnName)
                .textFieldStyle(.roundedBorder)
            
            HStack {
                Button("Abbrechen") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                
                Button("Hinzufügen") {
                    onAdd()
                }
                .buttonStyle(.borderedProminent)
                .disabled(columnName.isEmpty)
            }
        }
        .padding()
        .frame(width: 300)
    }
}

// MARK: - Data Models

struct LabelData {
    let plugbox: String
    let channels: [Int: [String]]
}

struct FixtureField: Identifiable {
    let id = UUID()
    var title: String
    var csvColumn: String = ""
    let key: String
    
    init(title: String, key: String) {
        self.title = title
        self.key = key
    }
}

struct FixtureLabelData {
    let fieldData: [String: String]
    let companyName: String
    let projectName: String
    let companyLogo: NSImage?
    
    init(fieldData: [String: String], companyName: String, projectName: String, companyLogo: NSImage? = nil) {
        self.fieldData = fieldData
        self.companyName = companyName
        self.projectName = projectName
        self.companyLogo = companyLogo
    }
}

struct CustomLabelData {
    let data: [String: String]
    let columnOrder: [String]
}

// MARK: - Preview

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .modelContainer(for: [Project.self, LightFixture.self], inMemory: true)
    }
}