import SwiftUI
import SwiftData
import AppKit
import PDFKit

struct NetworkView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var showAddComponentDialog = false
    @State private var editingComponent: NetworkComponent?
    @State private var componentName = ""
    @State private var componentPosition = ""
    @State private var componentIP = ""
    @State private var componentSubnet = "255.255.255.0"
    @State private var componentVLAN = ""
    @State private var selectedLogo: LogoOption = .none
    @State private var customLogoData: Data?
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var showDeleteConfirmation = false
    @State private var componentToDelete: NetworkComponent?
    @State private var showLogoImporter = false
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    var sortedComponents: [NetworkComponent] {
        project.networkComponents.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }
    
    var groupedComponents: [(String, [NetworkComponent])] {
        let grouped = Dictionary(grouping: sortedComponents) { component in
            component.position.isEmpty ? "Unbekannt" : component.position
        }
        return grouped.sorted { $0.key.localizedCaseInsensitiveCompare($1.key) == .orderedAscending }
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                headerView
                
                Divider()
                
                if project.networkComponents.isEmpty {
                    emptyStateView
                } else {
                    networkComponentsList
                }
                
                Spacer()
                
                footerView
            }
            .navigationTitle("Netzwerk-Komponenten")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .primaryAction) {
                    Button("Komponente hinzufügen") {
                        showAddComponentDialog = true
                    }
                }
            }
        }
        .frame(minWidth: 800, minHeight: 600)
        .sheet(isPresented: $showAddComponentDialog) {
            NetworkComponentEditView(
                componentName: $componentName,
                componentPosition: $componentPosition,
                componentIP: $componentIP,
                componentSubnet: $componentSubnet,
                componentVLAN: $componentVLAN,
                isEditing: editingComponent != nil,
                onSave: saveComponent,
                onCancel: cancelEdit
            )
        }
        .fileImporter(
            isPresented: $showLogoImporter,
            allowedContentTypes: [.png, .jpeg, .tiff, .bmp, .pdf],
            allowsMultipleSelection: false
        ) { result in
            handleLogoImport(result: result)
        }
        .alert("Fehler", isPresented: $showError) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
        .alert("Komponente löschen", isPresented: $showDeleteConfirmation) {
            Button("Löschen", role: .destructive) {
                if let component = componentToDelete {
                    deleteComponent(component)
                }
            }
            Button("Abbrechen", role: .cancel) {
                componentToDelete = nil
            }
        } message: {
            Text("Möchten Sie diese Netzwerk-Komponente wirklich löschen?")
        }
    }
    
    private var headerView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Projekt: \(project.name)")
                .font(.headline)
            Text("\(project.networkComponents.count) Netzwerk-Komponenten")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.controlBackgroundColor))
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Image(systemName: "network")
                .font(.system(size: 60))
                .foregroundColor(.secondary)
            
            Text("Keine Netzwerk-Komponenten vorhanden")
                .font(.title2)
                .foregroundColor(.secondary)
            
            Text("Fügen Sie Netzwerk-Komponenten hinzu, um eine Übersicht zu erstellen")
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            Button("Erste Komponente hinzufügen") {
                showAddComponentDialog = true
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(40)
    }
    
    private var networkComponentsList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(sortedComponents, id: \.id) { component in
                    NetworkComponentRow(
                        component: component,
                        onEdit: {
                            editComponent(component)
                        },
                        onDelete: {
                            componentToDelete = component
                            showDeleteConfirmation = true
                        }
                    )
                }
            }
            .padding()
        }
    }
    
    private var footerView: some View {
        VStack(spacing: 16) {
            Divider()
            
            VStack(alignment: .leading, spacing: 12) {
                Text("Logo-Einstellungen:")
                    .font(.headline)
                    .fontWeight(.medium)
                
                VStack(spacing: 12) {
                    Picker("Logo-Option", selection: $selectedLogo) {
                        ForEach(LogoOption.allCases, id: \.self) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .onChange(of: selectedLogo) { _, newValue in
                        handleLogoOptionChange(newValue)
                    }
                    
                    if selectedLogo == .upload {
                        HStack {
                            Button("Logo auswählen") {
                                showLogoImporter = true
                            }
                            .buttonStyle(.bordered)
                            
                            if customLogoData != nil {
                                Button("Logo entfernen") {
                                    customLogoData = nil
                                }
                                .buttonStyle(.bordered)
                                .foregroundColor(.red)
                            }
                        }
                    }
                    
                    if let logoImage = getCurrentLogoImage() {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Logo-Vorschau:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Image(nsImage: logoImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                }
            }
            .padding(.horizontal)
            
            HStack {
                Spacer()
                Button("PDF exportieren") {
                    exportToPDF()
                }
                .buttonStyle(.borderedProminent)
                .disabled(project.networkComponents.isEmpty)
            }
            .padding(.horizontal)
            .padding(.bottom)
        }
        .background(Color(.controlBackgroundColor))
    }
    
    private func getCurrentLogoImage() -> NSImage? {
        switch selectedLogo {
        case .upload:
            if let data = customLogoData {
                return NSImage(data: data)
            }
            return nil
        case .habegger:
            return createHabeggerLogo()
        case .none:
            return nil
        }
    }
    
    private func editComponent(_ component: NetworkComponent) {
        editingComponent = component
        componentName = component.name
        componentPosition = component.position
        componentIP = component.ipAddress
        componentSubnet = component.subnetMask
        componentVLAN = component.vlan
        showAddComponentDialog = true
    }
    
    private func saveComponent() {
        guard !componentName.isEmpty, !componentIP.isEmpty else {
            errorMessage = "Name und IP-Adresse sind Pflichtfelder."
            showError = true
            return
        }
        
        if let existingComponent = editingComponent {
            existingComponent.name = componentName
            existingComponent.position = componentPosition
            existingComponent.ipAddress = componentIP
            existingComponent.subnetMask = componentSubnet
            existingComponent.vlan = componentVLAN
        } else {
            let newComponent = NetworkComponent(
                name: componentName,
                position: componentPosition,
                ipAddress: componentIP,
                subnetMask: componentSubnet,
                vlan: componentVLAN
            )
            project.networkComponents.append(newComponent)
            modelContext.insert(newComponent)
        }
        
        saveChanges()
        cancelEdit()
    }
    
    private func cancelEdit() {
        editingComponent = nil
        componentName = ""
        componentPosition = ""
        componentIP = ""
        componentSubnet = "255.255.255.0"
        componentVLAN = ""
        showAddComponentDialog = false
    }
    
    private func deleteComponent(_ component: NetworkComponent) {
        if let index = project.networkComponents.firstIndex(of: component) {
            project.networkComponents.remove(at: index)
            modelContext.delete(component)
            saveChanges()
        }
        componentToDelete = nil
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                customLogoData = try Data(contentsOf: url)
            } catch {
                errorMessage = "Fehler beim Laden der Logo-Datei: \(error.localizedDescription)"
                showError = true
            }
            
        case .failure(let error):
            errorMessage = "Fehler beim Auswählen des Logos: \(error.localizedDescription)"
            showError = true
        }
    }
    
    private func exportToPDF() {
        let pdfCreator = NetworkPDFCreator()
        
        let selectedLogoImage: NSImage? = {
            switch selectedLogo {
            case .upload:
                if let data = customLogoData {
                    return NSImage(data: data)
                }
                return nil
            case .habegger:
                return createHabeggerLogo()
            case .none:
                return nil
            }
        }()
        
        let pdfData = pdfCreator.createPDF(
            projectName: project.name,
            components: groupedComponents,
            companyLogo: selectedLogoImage
        )
        
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.pdf]
        savePanel.nameFieldStringValue = "\(project.name)_Netzwerk.pdf"
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
            } catch {
                errorMessage = "Fehler beim Speichern der PDF: \(error.localizedDescription)"
                showError = true
            }
        }
    }
    
    private func handleLogoOptionChange(_ option: LogoOption) {
        switch option {
        case .none:
            customLogoData = nil
        case .upload:
            break
        case .habegger:
            customLogoData = nil  
        }
    }
    
    private func createHabeggerLogo() -> NSImage {
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            return assetLogo
        }
        
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        return image
    }
    
    private func saveChanges() {
        do {
            try modelContext.save()
            project.updatedAt = Date()
        } catch {
            errorMessage = "Fehler beim Speichern: \(error.localizedDescription)"
            showError = true
        }
    }
}

struct NetworkComponentRow: View {
    let component: NetworkComponent
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(component.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
                
                HStack(spacing: 8) {
                    Button("Bearbeiten", action: onEdit)
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    
                    Button("Löschen", action: onDelete)
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        .foregroundColor(.red)
                }
            }
            
            HStack(alignment: .top, spacing: 40) {
                VStack(alignment: .leading, spacing: 8) {
                    DetailRow(label: "Position", value: component.position.isEmpty ? "Nicht angegeben" : component.position)
                    DetailRow(label: "IP-Adresse", value: component.ipAddress)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    DetailRow(label: "Subnetzmaske", value: component.subnetMask)
                    if !component.vlan.isEmpty {
                        DetailRow(label: "VLAN", value: component.vlan)
                            .foregroundColor(.blue)
                    }
                }
            }
        }
        .padding()
        .background(Color(.controlBackgroundColor))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(.separatorColor), lineWidth: 1)
        )
    }
}

struct DetailRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text("\(label):")
                .font(.caption)
                .foregroundColor(.secondary)
                .frame(width: 100, alignment: .leading)
            
            Text(value)
                .font(.caption)
                .fontWeight(.medium)
        }
    }
}

struct NetworkComponentEditView: View {
    @Binding var componentName: String
    @Binding var componentPosition: String
    @Binding var componentIP: String
    @Binding var componentSubnet: String
    @Binding var componentVLAN: String
    let isEditing: Bool
    let onSave: () -> Void
    let onCancel: () -> Void
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Grunddaten") {
                    TextField("Name/Typ", text: $componentName)
                        .textFieldStyle(.roundedBorder)
                    
                    TextField("Position", text: $componentPosition)
                        .textFieldStyle(.roundedBorder)
                }
                
                Section("Netzwerk-Konfiguration") {
                    TextField("IP-Adresse", text: $componentIP)
                        .textFieldStyle(.roundedBorder)
                    
                    TextField("Subnetzmaske", text: $componentSubnet)
                        .textFieldStyle(.roundedBorder)
                    
                    TextField("VLAN (optional)", text: $componentVLAN)
                        .textFieldStyle(.roundedBorder)
                }
            }
            .navigationTitle(isEditing ? "Komponente bearbeiten" : "Neue Komponente")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen", action: onCancel)
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern", action: onSave)
                        .disabled(componentName.isEmpty || componentIP.isEmpty)
                }
            }
        }
        .frame(width: 500, height: 400)
    }
}

// MARK: - PDF Creator

class NetworkPDFCreator {
    private let pageWidth: CGFloat = 595.2   // A4 width
    private let pageHeight: CGFloat = 841.8  // A4 height
    private let margin: CGFloat = 40
    
    // Dynamic VLAN color generation
    private func getVLANColor(for vlan: String) -> (red: CGFloat, green: CGFloat, blue: CGFloat) {
        // Create consistent colors based on VLAN name hash
        let hash = abs(vlan.hashValue)
        let hue = CGFloat(hash % 360) / 360.0  // 0-1 range
        
        // Convert HSV to RGB with fixed saturation and brightness for consistent colors
        let saturation: CGFloat = 0.6
        let brightness: CGFloat = 0.9
        
        let c = brightness * saturation
        let x = c * (1 - abs(((hue * 6).truncatingRemainder(dividingBy: 2)) - 1))
        let m = brightness - c
        
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        
        let hueSegment = Int(hue * 6)
        switch hueSegment {
        case 0: r = c; g = x; b = 0
        case 1: r = x; g = c; b = 0
        case 2: r = 0; g = c; b = x
        case 3: r = 0; g = x; b = c
        case 4: r = x; g = 0; b = c
        case 5: r = c; g = 0; b = x
        default: r = 0; g = 0; b = 0
        }
        
        return (red: r + m, green: g + m, blue: b + m)
    }
    
    func createPDF(projectName: String, components: [(String, [NetworkComponent])], companyLogo: NSImage?) -> Data {
        let pdfData = NSMutableData()
        
        guard let consumer = CGDataConsumer(data: pdfData) else {
            return Data()
        }
        
        var mediaBox = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        
        guard let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil) else {
            return Data()
        }
        
        // Set high-quality rendering
        pdfContext.interpolationQuality = .high
        pdfContext.setAllowsAntialiasing(true)
        pdfContext.setShouldAntialias(true)
        
        let pdfInfo: [CFString: Any] = [
            kCGPDFContextCreator: "LXMAKER",
            kCGPDFContextAuthor: "LXMAKER App",
            kCGPDFContextTitle: "\(projectName) - Netzwerk-Dokumentation"
        ]
        
        pdfContext.beginPDFPage(pdfInfo as CFDictionary)
        
        // Header
        drawHeader(context: pdfContext, rect: mediaBox, projectName: projectName, companyLogo: companyLogo)
        
        // Content
        drawContent(context: pdfContext, rect: mediaBox, components: components)
        
        // Footer
        drawFooter(context: pdfContext, rect: mediaBox)
        
        pdfContext.endPDFPage()
        pdfContext.closePDF()
        
        return pdfData as Data
    }
    
    private func drawHeader(context: CGContext, rect: CGRect, projectName: String, companyLogo: NSImage?) {
        let headerHeight: CGFloat = 80
        let headerY = rect.height - headerHeight - margin
        
        // Logo (if available) - corrected rendering
        if let logo = companyLogo {
            let logoHeight: CGFloat = 40
            let logoMaxWidth: CGFloat = 120
            
            // Calculate logo dimensions maintaining aspect ratio
            let logoSize = logo.size
            let logoAspectRatio = logoSize.width / logoSize.height
            
            var logoWidth = logoMaxWidth
            var finalLogoHeight = logoHeight
            
            if logoAspectRatio > (logoMaxWidth / logoHeight) {
                // Logo is wider - fit to width
                finalLogoHeight = logoMaxWidth / logoAspectRatio
            } else {
                // Logo is taller - fit to height
                logoWidth = logoHeight * logoAspectRatio
            }
            
            let logoRect = CGRect(
                x: pageWidth - margin - logoWidth,
                y: headerY + (headerHeight - finalLogoHeight) / 2,
                width: logoWidth,
                height: finalLogoHeight
            )
            
            // Corrected logo rendering without flipping
            context.saveGState()
            
            // Get CGImage
            var cgImage: CGImage?
            
            // Method 1: Direct CGImage
            cgImage = logo.cgImage(forProposedRect: nil, context: nil, hints: nil)
            
            // Method 2: If that fails, try creating from representations
            if cgImage == nil {
                for rep in logo.representations {
                    if let bitmapRep = rep as? NSBitmapImageRep {
                        cgImage = bitmapRep.cgImage
                        break
                    }
                }
            }
            
            // Method 3: Create bitmap representation
            if cgImage == nil {
                let imageData = logo.tiffRepresentation
                if let data = imageData,
                   let imageSource = CGImageSourceCreateWithData(data as CFData, nil),
                   CGImageSourceGetCount(imageSource) > 0 {
                    cgImage = CGImageSourceCreateImageAtIndex(imageSource, 0, nil)
                }
            }
            
            if let finalImage = cgImage {
                // Draw image directly without coordinate system flipping
                // The logo rect is already in the correct PDF coordinate system
                context.draw(finalImage, in: logoRect)
            }
            
            context.restoreGState()
        }
        
        // Title (without frame/border)
        let titleRect = CGRect(x: margin, y: headerY + 35, width: pageWidth - 2 * margin - 130, height: 25)
        drawText(context: context, text: projectName, rect: titleRect, fontSize: 18, bold: true)
        
        // Subtitle
        let subtitleRect = CGRect(x: margin, y: headerY + 10, width: pageWidth - 2 * margin - 130, height: 20)
        drawText(context: context, text: "Netzwerk-Dokumentation", rect: subtitleRect, fontSize: 14, bold: false)
    }
    
    private func drawContent(context: CGContext, rect: CGRect, components: [(String, [NetworkComponent])]) {
        var currentY: CGFloat = rect.height - 150
        
        for (position, positionComponents) in components {
            // Check if we have enough space for this position group
            let neededHeight: CGFloat = 40 + CGFloat(positionComponents.count) * 70 + 20
            if currentY - neededHeight < 100 {
                // Would need new page - for now, just continue
                break
            }
            
            // Position header with pin icon
            drawPositionHeader(context: context, position: position, y: currentY, width: rect.width - 2 * margin)
            currentY -= 50
            
            // Components for this position
            for component in positionComponents {
                drawComponent(context: context, component: component, y: currentY, width: rect.width - 2 * margin)
                currentY -= 70
            }
            
            currentY -= 20  // Extra space between position groups
        }
    }
    
    private func drawPositionHeader(context: CGContext, position: String, y: CGFloat, width: CGFloat) {
        let headerRect = CGRect(x: margin, y: y - 35, width: width, height: 35)
        
        // Background
        context.setFillColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1.0)
        context.fill(headerRect)
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(headerRect)
        
        // Pin icon (simplified circle)
        let iconSize: CGFloat = 12
        let iconRect = CGRect(
            x: headerRect.minX + 15,
            y: headerRect.minY + (headerRect.height - iconSize) / 2,
            width: iconSize,
            height: iconSize
        )
        context.setFillColor(red: 0.8, green: 0.2, blue: 0.2, alpha: 1.0)
        context.fillEllipse(in: iconRect)
        
        // Position text
        let textRect = CGRect(x: headerRect.minX + 35, y: headerRect.minY + 5, width: headerRect.width - 45, height: 25)
        drawText(context: context, text: position, rect: textRect, fontSize: 16, bold: true)
    }
    
    private func drawComponent(context: CGContext, component: NetworkComponent, y: CGFloat, width: CGFloat) {
        let componentRect = CGRect(x: margin + 20, y: y - 60, width: width - 20, height: 60)
        
        // Background
        context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        context.fill(componentRect)
        context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(componentRect)
        
        // Component name
        let nameRect = CGRect(x: componentRect.minX + 15, y: componentRect.maxY - 20, width: componentRect.width * 0.6, height: 15)
        drawText(context: context, text: component.name, rect: nameRect, fontSize: 14, bold: true)
        
        // IP and Subnet
        let ipText = "IP: \(component.ipAddress)"
        let ipRect = CGRect(x: componentRect.minX + 15, y: componentRect.maxY - 40, width: componentRect.width * 0.4, height: 12)
        drawText(context: context, text: ipText, rect: ipRect, fontSize: 10, bold: false)
        
        let subnetText = "Subnet: \(component.subnetMask)"
        let subnetRect = CGRect(x: componentRect.minX + 15, y: componentRect.maxY - 55, width: componentRect.width * 0.4, height: 12)
        drawText(context: context, text: subnetText, rect: subnetRect, fontSize: 10, bold: false)
        
        // VLAN badge (if exists) - with dynamic colors
        if !component.vlan.isEmpty {
            drawVLANBadge(context: context, vlan: component.vlan, rect: componentRect)
        }
    }
    
    private func drawVLANBadge(context: CGContext, vlan: String, rect: CGRect) {
        let badgeWidth: CGFloat = 120
        let badgeHeight: CGFloat = 25
        let badgeRect = CGRect(
            x: rect.maxX - badgeWidth - 15,
            y: rect.minY + (rect.height - badgeHeight) / 2,
            width: badgeWidth,
            height: badgeHeight
        )
        
        // Get dynamic VLAN color
        let vlanColor = getVLANColor(for: vlan)
        
        // Background with the VLAN-specific color
        context.setFillColor(red: vlanColor.red, green: vlanColor.green, blue: vlanColor.blue, alpha: 1.0)
        context.fill(badgeRect)
        context.setStrokeColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(badgeRect)
        
        // Text
        let vlanText = "VLAN: \(vlan)"
        drawText(context: context, text: vlanText, rect: badgeRect.insetBy(dx: 5, dy: 2), fontSize: 10, bold: true, centered: true)
    }
    
    private func drawFooter(context: CGContext, rect: CGRect) {
        let footerY: CGFloat = 30
        
        // Date
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.locale = Locale(identifier: "de_DE")
        let dateString = formatter.string(from: Date())
        
        let dateRect = CGRect(x: margin, y: footerY, width: 200, height: 15)
        drawText(context: context, text: dateString, rect: dateRect, fontSize: 10, bold: false)
        
        // Page number
        let pageString = "Seite 1 von 1"
        let pageRect = CGRect(x: pageWidth / 2 - 40, y: footerY, width: 80, height: 15)
        drawText(context: context, text: pageString, rect: pageRect, fontSize: 10, bold: false, centered: true)
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool, centered: Bool = false) {
        context.saveGState()
        
        // Set high-quality text rendering
        context.setAllowsAntialiasing(true)
        context.setShouldAntialias(true)
        context.setShouldSubpixelPositionFonts(true)
        context.setShouldSubpixelQuantizeFonts(true)
        
        let fontName = bold ? "Helvetica-Bold" : "Helvetica"
        let font = CTFontCreateWithName(fontName as CFString, fontSize, nil)
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        let textBounds = CTLineGetBoundsWithOptions(line, [])
        let xPosition = centered ? rect.minX + (rect.width - textBounds.width) / 2 : rect.minX
        let yPosition = rect.minY + (rect.height - textBounds.height) / 2
        
        context.textPosition = CGPoint(x: xPosition, y: yPosition)
        CTLineDraw(line, context)
        
        context.restoreGState()
    }
}