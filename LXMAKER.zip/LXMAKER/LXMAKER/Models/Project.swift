import Foundation
import SwiftData

@Model
final class NetworkComponent {
    @Attribute(.unique) var id: String
    var name: String
    var position: String
    var ipAddress: String
    var subnetMask: String
    var vlan: String
    var createdAt: Date
    
    init(name: String, position: String, ipAddress: String, subnetMask: String = "255.255.255.0", vlan: String) {
        self.id = UUID().uuidString
        self.name = name
        self.position = position
        self.ipAddress = ipAddress
        self.subnetMask = subnetMask
        self.vlan = vlan
        self.createdAt = Date()
    }
}

@Model
final class Project {
    @Attribute(.unique) var id: String
    var name: String
    var createdAt: Date
    var updatedAt: Date
    @Relationship(deleteRule: .cascade) var fixtures: [LightFixture]
    @Relationship(deleteRule: .cascade) var networkComponents: [NetworkComponent]
    var savedViewsData: String
    var selectedIdentifierColumn: String?
    var columnOrder: [String] // Store the original CSV column order
    var columnWidths: [String: Double] // Store column widths
    
    init(name: String) {
        self.id = UUID().uuidString
        self.name = name
        self.createdAt = Date()
        self.updatedAt = Date()
        self.fixtures = []
        self.networkComponents = []
        self.savedViewsData = "[]"
        self.selectedIdentifierColumn = "ID"
        self.columnOrder = []
        self.columnWidths = [:]
    }
    
    func getColumnWidth(for column: String) -> Double {
        return columnWidths[column] ?? 120.0 // Default width
    }
    
    func setColumnWidth(for column: String, width: Double) {
        columnWidths[column] = max(50.0, min(500.0, width)) // Min 50, Max 500
    }
}