import Foundation
import SwiftData

@Model
final class LightFixture {
    @Attribute(.unique) var id: String
    @Attribute(.externalStorage) var rawData: [String: String]
    
    var displayID: String {
        rawData["ID"] ?? rawData["Fixture ID"] ?? id
    }
    
    init(data: [String: String]) {
        self.id = UUID().uuidString
        self.rawData = data
    }
}
