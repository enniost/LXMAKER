import SwiftUI
import SwiftData
import Charts
import AppKit

// MARK: - DMX Universe Views

struct DMXUniverseView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedUniverseColumn = ""
    @State private var selectedAddressColumn = ""
    @State private var selectedChannelColumn = ""
    @State private var selectedFixtureIDColumn = ""
    @State private var selectedDMXModeColumn = ""
    @State private var showResults = false
    @State private var analysisResults: DMXUniverseResults?
    @State private var companyLogo: NSImage? = nil
    @State private var showLogoImporter = false
    @State private var logoOption: LogoOption = .none
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canAnalyze: Bool {
        !selectedUniverseColumn.isEmpty &&
        !selectedAddressColumn.isEmpty &&
        !selectedChannelColumn.isEmpty &&
        !selectedFixtureIDColumn.isEmpty &&
        !selectedDMXModeColumn.isEmpty
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text(" DMX Universe Analyzer")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Analysieren Sie DMX-Universen, Adressenverteilung und Überlappungen")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        if availableColumns.isEmpty {
                            Text(" Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // Column Mapping
                            columnMappingView
                            
                            // Logo Upload
                            logoUploadView
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Info
                        VStack(alignment: .leading, spacing: 15) {
                            Text("DMX-Informationen:")
                                .font(.headline)
                                .fontWeight(.medium)
                            
                            VStack(alignment: .leading, spacing: 10) {
                                InfoRow(title: "Universum", description: "DMX-Universum (1-32768)")
                                InfoRow(title: "Adresse", description: "DMX-Startadresse (1-512)")
                                InfoRow(title: "Kanäle", description: "Anzahl DMX-Kanäle des Fixtures")
                                InfoRow(title: "Kapazität", description: "512 Kanäle pro Universum")
                            }
                            
                            universumLegendView
                        }
                        .padding(15)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(10)
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Action Buttons
                    HStack(spacing: 25) {
                        Button("Analyse starten") {
                            analyzeDMXUniverses()
                        }
                        .disabled(!canAnalyze)
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                        
                        Button("PDF erzeugen") {
                            analyzeDMXUniverses()
                            exportDMXPDF()
                        }
                        .disabled(!canAnalyze)
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                    }
                    .padding(.bottom, 20)
                    
                    // Results
                    if showResults, let results = analysisResults {
                        DMXResultsView(results: results)
                    }
                }
                .padding(20)
            }
            .navigationTitle("DMX Universe Analyzer")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1200, minHeight: 900)
            .onAppear {
                autoAssignColumns()
            }
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp, .pdf],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
        }
    }
    
    private var columnMappingView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("CSV-Spalten zuordnen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                HStack {
                    Text("Universe:")
                        .frame(width: 120, alignment: .leading)
                    Picker("Universe", selection: $selectedUniverseColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("DMX Adresse:")
                        .frame(width: 120, alignment: .leading)
                    Picker("DMX Adresse", selection: $selectedAddressColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("DMX Channel:")
                        .frame(width: 120, alignment: .leading)
                    Picker("DMX Channel", selection: $selectedChannelColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Fixture ID:")
                        .frame(width: 120, alignment: .leading)
                    Picker("Fixture ID", selection: $selectedFixtureIDColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("DMX Modus:")
                        .frame(width: 120, alignment: .leading)
                    Picker("DMX Modus", selection: $selectedDMXModeColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
            }
        }
        .padding(15)
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var logoUploadView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Logo-Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                // Logo Option Selection
                Picker("Logo-Option", selection: $logoOption) {
                    ForEach(LogoOption.allCases, id: \.self) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: logoOption) { _, newValue in
                    handleLogoOptionChange(newValue)
                }
                
                // Show upload button only if upload option is selected
                if logoOption == .upload {
                    HStack {
                        Button("Logo auswählen") {
                            showLogoImporter = true
                        }
                        .buttonStyle(.bordered)
                        
                        if companyLogo != nil {
                            Button("Logo entfernen") {
                                companyLogo = nil
                            }
                            .buttonStyle(.bordered)
                            .foregroundColor(.red)
                        }
                    }
                }
                
                // Show logo preview
                if let logo = companyLogo {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logo-Vorschau:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Image(nsImage: logo)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 150, height: 50)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                    }
                }
            }
        }
        .padding(15)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var universumLegendView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Auslastungsanzeige:")
                .font(.subheadline)
                .fontWeight(.medium)
            
            VStack(spacing: 4) {
                HStack {
                    Rectangle()
                        .fill(Color.green)
                        .frame(width: 15, height: 15)
                    Text("Niedrig (≤50%)")
                        .font(.caption)
                    Spacer()
                }
                
                HStack {
                    Rectangle()
                        .fill(Color.yellow)
                        .frame(width: 15, height: 15)
                    Text("Mittel (51-80%)")
                        .font(.caption)
                    Spacer()
                }
                
                HStack {
                    Rectangle()
                        .fill(Color.orange)
                        .frame(width: 15, height: 15)
                    Text("Hoch (81-100%)")
                        .font(.caption)
                    Spacer()
                }
                
                HStack {
                    Rectangle()
                        .fill(Color.red)
                        .frame(width: 15, height: 15)
                    Text("Überlastung (>100%)")
                        .font(.caption)
                    Spacer()
                }
            }
        }
        .padding(10)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
    
    private func autoAssignColumns() {
        let keywordMappings = [
            "universe": ["universe", "universum", "univ", "uni"],
            "address": ["address", "adresse", "addr", "dmx", "start"],
            "channel": ["channel", "channels", "kanal", "ch", "cnt"],
            "fixtureID": ["fixture", "id", "name", "label", "bezeichnung", "typ", "type"],
            "dmxMode": ["mode", "modus", "dmx_mode", "dmxmode", "personality", "config"]
        ]
        
        for column in availableColumns {
            let columnLower = column.lowercased()
            
            if selectedUniverseColumn.isEmpty,
               keywordMappings["universe"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedUniverseColumn = column
            }
            
            if selectedAddressColumn.isEmpty,
               keywordMappings["address"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedAddressColumn = column
            }
            
            if selectedChannelColumn.isEmpty,
               keywordMappings["channel"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedChannelColumn = column
            }
            
            if selectedFixtureIDColumn.isEmpty,
               keywordMappings["fixtureID"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedFixtureIDColumn = column
            }
            
            if selectedDMXModeColumn.isEmpty,
               keywordMappings["dmxMode"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedDMXModeColumn = column
            }
        }
    }
    
    private func analyzeDMXUniverses() {
        let analyzer = DMXUniverseAnalyzer(
            fixtures: project.fixtures,
            universeColumn: selectedUniverseColumn,
            addressColumn: selectedAddressColumn,
            channelColumn: selectedChannelColumn,
            fixtureIDColumn: selectedFixtureIDColumn,
            dmxModeColumn: selectedDMXModeColumn
        )
        
        analysisResults = analyzer.analyze()
        showResults = true
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                if let image = NSImage(contentsOf: url) {
                    companyLogo = image
                }
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func exportDMXPDF() {
        guard let results = analysisResults else { return }
        
        let pdfCreator = DMXUniversePDFCreator()
        let selectedLogo: NSImage? = {
            switch logoOption {
            case .upload:
                return companyLogo
            case .habegger:
                return createHabeggerLogo()
            case .none:
                return nil
            }
        }()
        
        let pdfData = pdfCreator.createPDF(
            results: results,
            projectName: project.name,
            companyLogo: selectedLogo
        )
        
        let filename = "DMX_Universe_Analysis_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die DMX Universe Analyse wurde erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
    
    private func handleLogoOptionChange(_ option: LogoOption) {
        switch option {
        case .none:
            companyLogo = nil
        case .upload:
            // Keep current logo if available, otherwise user needs to select one
            break
        case .habegger:
            companyLogo = createHabeggerLogo()
        }
    }
    
    private func createHabeggerLogo() -> NSImage {
        // Use the logo from Assets instead of creating it programmatically
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            return assetLogo
        }
        
        // Fallback to programmatically created logo if asset is not found
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        // Clear background
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        // Draw gold bar
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        // Draw "HABEGGER" text
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        return image
    }
}

struct InfoRow: View {
    let title: String
    let description: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption)
                .fontWeight(.bold)
            Text(description)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
    }
}

struct DMXResultsView: View {
    let results: DMXUniverseResults
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("DMX Universe Analyse")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            // Summary
            summaryView
            
            // Universe Details
            ForEach(results.universes.sorted(by: { $0.key < $1.key }), id: \.key) { universeNumber, universeData in
                UniverseCard(
                    universeNumber: universeNumber,
                    universeData: universeData
                )
            }
            
            // Overlaps - Always at the bottom
            if !results.overlaps.isEmpty {
                overlapView
            }
        }
        .padding()
        .background(Color.black)
        .cornerRadius(12)
    }
    
    private var summaryView: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Zusammenfassung")
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            HStack(spacing: 30) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Gesamt Universen")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text("\(results.universes.count)")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Gesamt Fixtures")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text("\(results.totalFixtures)")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Überlappungen")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text("\(results.overlaps.count)")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(results.overlaps.isEmpty ? .green : .red)
                }
            }
        }
        .padding()
        .background(Color.black)
        .cornerRadius(10)
        .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
    
    private var overlapView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("⚠️ Überlappungen gefunden")
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(.red)
            
            ForEach(results.overlaps, id: \.id) { overlap in
                VStack(alignment: .leading, spacing: 4) {
                    Text("Universe \(overlap.universe)")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                    
                    Text("\(overlap.channelRange.displayText): \(overlap.fixtureIds.joined(separator: ", "))")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                .padding(8)
                .background(Color.red.opacity(0.2))
                .cornerRadius(6)
            }
        }
        .padding()
        .background(Color.black)
        .cornerRadius(10)
        .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
}

struct UniverseCard: View {
    let universeNumber: Int
    let universeData: DMXUniverseData
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            // Universe Header
            HStack {
                Text("Universe \(universeNumber)")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Text("\(universeData.fixtures.count) Fixtures")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            // Usage Statistics
            HStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Verwendete Kanäle")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text("\(universeData.usedChannels)/512")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Auslastung")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text("\(String(format: "%.1f", universeData.usagePercentage))%")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(getUsageColor(universeData.usagePercentage))
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Freie Kanäle")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text("\(512 - universeData.usedChannels)")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                }
            }
            
            // Usage Chart
            Chart {
                BarMark(
                    x: .value("Status", "Verwendet"),
                    y: .value("Kanäle", universeData.usedChannels)
                )
                .foregroundStyle(getUsageColor(universeData.usagePercentage))
                
                BarMark(
                    x: .value("Status", "Frei"),
                    y: .value("Kanäle", 512 - universeData.usedChannels)
                )
                .foregroundStyle(Color.green)
            }
            .frame(height: 120)
            .chartYAxis {
                AxisMarks(position: .leading) { _ in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel()
                }
            }
            .chartXAxis {
                AxisMarks { _ in
                    AxisTick()
                    AxisValueLabel()
                }
            }
        }
        .padding()
        .background(Color.black)
        .cornerRadius(10)
        .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
    
    private func getUsageColor(_ percentage: Double) -> Color {
        if percentage <= 50 {
            return Color.green
        } else if percentage <= 80 {
            return Color.yellow
        } else if percentage <= 100 {
            return Color.orange
        } else {
            return Color.red
        }
    }
}

// MARK: - DMX Universe Data Models

struct DMXUniverseResults {
    let universes: [Int: DMXUniverseData]
    let overlaps: [DMXOverlap]
    let totalFixtures: Int
    let timestamp: Date
}

struct DMXUniverseData {
    let universe: Int
    let fixtures: [DMXFixture]
    let usedChannels: Int
    let usagePercentage: Double
    let addressRanges: [DMXAddressRange]
}

struct DMXFixture {
    let id: String
    let displayID: String
    let universe: Int
    let startAddress: Int
    let channelCount: Int
    let endAddress: Int
    let dmxMode: String
    let rawData: [String: String]
}

struct DMXAddressRange {
    let startAddress: Int
    let endAddress: Int
    let fixtureId: String
    let fixtureDisplayID: String
    let dmxMode: String
}

struct DMXOverlap {
    let id = UUID()
    let universe: Int
    let channelRange: DMXChannelRange
    let fixtureIds: [String]
}

struct DMXChannelRange {
    let startChannel: Int
    let endChannel: Int
    
    var displayText: String {
        if startChannel == endChannel {
            return "Kanal \(startChannel)"
        } else {
            return "Kanäle \(startChannel)-\(endChannel)"
        }
    }
}

// MARK: - DMX Universe Analyzer

class DMXUniverseAnalyzer {
    private let fixtures: [LightFixture]
    private let universeColumn: String
    private let addressColumn: String
    private let channelColumn: String
    private let fixtureIDColumn: String
    private let dmxModeColumn: String
    
    init(fixtures: [LightFixture], universeColumn: String, addressColumn: String, channelColumn: String, fixtureIDColumn: String, dmxModeColumn: String) {
        self.fixtures = fixtures
        self.universeColumn = universeColumn
        self.addressColumn = addressColumn
        self.channelColumn = channelColumn
        self.fixtureIDColumn = fixtureIDColumn
        self.dmxModeColumn = dmxModeColumn
    }
    
    func analyze() -> DMXUniverseResults {
        var universes: [Int: DMXUniverseData] = [:]
        var overlaps: [DMXOverlap] = []
        
        // Parse fixtures into DMX data
        let dmxFixtures = parseDMXFixtures()
        
        // Group by universe
        let universeGroups = Dictionary(grouping: dmxFixtures) { $0.universe }
        
        // Analyze each universe
        for (universeNumber, fixtures) in universeGroups {
            let universeData = analyzeUniverse(universe: universeNumber, fixtures: fixtures)
            universes[universeNumber] = universeData
            
            // Check for overlaps in this universe
            let universeOverlaps = findOverlaps(in: fixtures, universe: universeNumber)
            overlaps.append(contentsOf: universeOverlaps)
        }
        
        return DMXUniverseResults(
            universes: universes,
            overlaps: overlaps,
            totalFixtures: dmxFixtures.count,
            timestamp: Date()
        )
    }
    
    private func parseDMXFixtures() -> [DMXFixture] {
        return fixtures.compactMap { fixture in
            guard let universeString = fixture.rawData[universeColumn],
                  let universe = Int(universeString),
                  let addressString = fixture.rawData[addressColumn],
                  let startAddress = Int(addressString),
                  let channelString = fixture.rawData[channelColumn],
                  let channelCount = Int(channelString) else {
                return nil
            }
            
            let endAddress = startAddress + channelCount - 1
            
            // Use the selected fixture ID column or fallback to fixture.id
            let fixtureDisplayID = fixture.rawData[fixtureIDColumn] ?? fixture.id
            
            // Use the selected DMX mode column or fallback to empty string
            let dmxMode = fixture.rawData[dmxModeColumn] ?? ""
            
            return DMXFixture(
                id: fixture.id,
                displayID: fixtureDisplayID,
                universe: universe,
                startAddress: startAddress,
                channelCount: channelCount,
                endAddress: endAddress,
                dmxMode: dmxMode,
                rawData: fixture.rawData
            )
        }
    }
    
    private func analyzeUniverse(universe: Int, fixtures: [DMXFixture]) -> DMXUniverseData {
        var usedChannels: Set<Int> = []
        var addressRanges: [DMXAddressRange] = []
        
        for fixture in fixtures {
            for channel in fixture.startAddress...fixture.endAddress {
                if channel >= 1 && channel <= 512 {
                    usedChannels.insert(channel)
                }
            }
            
            addressRanges.append(DMXAddressRange(
                startAddress: fixture.startAddress,
                endAddress: fixture.endAddress,
                fixtureId: fixture.id,
                fixtureDisplayID: fixture.displayID,
                dmxMode: fixture.dmxMode
            ))
        }
        
        let usedChannelCount = usedChannels.count
        let usagePercentage = (Double(usedChannelCount) / 512.0) * 100.0
        
        return DMXUniverseData(
            universe: universe,
            fixtures: fixtures,
            usedChannels: usedChannelCount,
            usagePercentage: usagePercentage,
            addressRanges: addressRanges.sorted { $0.startAddress < $1.startAddress }
        )
    }
    
    private func findOverlaps(in fixtures: [DMXFixture], universe: Int) -> [DMXOverlap] {
        var channelMap: [Int: [String]] = [:]
        
        // Build channel map
        for fixture in fixtures {
            for channel in fixture.startAddress...fixture.endAddress {
                if channel >= 1 && channel <= 512 {
                    if channelMap[channel] == nil {
                        channelMap[channel] = []
                    }
                    channelMap[channel]?.append(fixture.displayID)
                }
            }
        }
        
        // Find overlapping channels
        var overlappingChannels: [Int: [String]] = [:]
        for (channel, fixtureIds) in channelMap {
            if fixtureIds.count > 1 {
                overlappingChannels[channel] = fixtureIds.sorted()
            }
        }
        
        // Group consecutive channels with same fixture combinations
        return consolidateOverlaps(overlappingChannels: overlappingChannels, universe: universe)
    }
    
    private func consolidateOverlaps(overlappingChannels: [Int: [String]], universe: Int) -> [DMXOverlap] {
        var consolidatedOverlaps: [DMXOverlap] = []
        
        // Group by fixture combination
        var fixtureGroups: [String: [Int]] = [:]
        
        for (channel, fixtureIds) in overlappingChannels {
            let fixtureKey = fixtureIds.joined(separator: "|")
            if fixtureGroups[fixtureKey] == nil {
                fixtureGroups[fixtureKey] = []
            }
            fixtureGroups[fixtureKey]?.append(channel)
        }
        
        // For each fixture combination, find consecutive channel ranges
        for (fixtureKey, channels) in fixtureGroups {
            let fixtureIds = fixtureKey.components(separatedBy: "|")
            let sortedChannels = channels.sorted()
            
            var ranges: [DMXChannelRange] = []
            var currentStart = sortedChannels[0]
            var currentEnd = sortedChannels[0]
            
            for i in 1..<sortedChannels.count {
                let channel = sortedChannels[i]
                
                if channel == currentEnd + 1 {
                    // Consecutive channel, extend range
                    currentEnd = channel
                } else {
                    // Gap found, create range and start new one
                    ranges.append(DMXChannelRange(startChannel: currentStart, endChannel: currentEnd))
                    currentStart = channel
                    currentEnd = channel
                }
            }
            
            // Add the last range
            ranges.append(DMXChannelRange(startChannel: currentStart, endChannel: currentEnd))
            
            // Create overlaps for each range
            for range in ranges {
                consolidatedOverlaps.append(DMXOverlap(
                    universe: universe,
                    channelRange: range,
                    fixtureIds: fixtureIds
                ))
            }
        }
        
        return consolidatedOverlaps.sorted { $0.channelRange.startChannel < $1.channelRange.startChannel }
    }
}

// MARK: - DMX Universe PDF Creator

class DMXUniversePDFCreator {
    private let pageWidth: CGFloat = 595.2   // A4 width
    private let pageHeight: CGFloat = 841.8  // A4 height
    private let margin: CGFloat = 20
    private let scaleFactor: CGFloat = 3.0   // High resolution scaling factor
    
    func createPDF(results: DMXUniverseResults, projectName: String, companyLogo: NSImage?) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        // Create high-resolution context
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        // Set high-quality rendering
        pdfContext.interpolationQuality = .high
        pdfContext.setAllowsAntialiasing(true)
        pdfContext.setShouldAntialias(true)
        pdfContext.setRenderingIntent(.defaultIntent)
        pdfContext.setShouldSubpixelPositionFonts(true)
        pdfContext.setShouldSubpixelQuantizeFonts(true)
        
        // Scale the entire context for high resolution
        pdfContext.scaleBy(x: scaleFactor, y: scaleFactor)
        
        let universeCount = results.universes.count
        let totalPages = universeCount + 1 // Summary page + one page per universe
        
        var currentPage = 0
        
        // Page 1: Summary
        currentPage += 1
        pdfContext.beginPDFPage(nil)
        drawSummaryPage(
            context: pdfContext,
            results: results,
            projectName: projectName,
            pageRect: pageRect,
            pageNumber: currentPage,
            totalPages: totalPages,
            companyLogo: companyLogo
        )
        pdfContext.endPDFPage()
        
        // Pages 2+: Universe Details
        for (universeNumber, universeData) in results.universes.sorted(by: { $0.key < $1.key }) {
            currentPage += 1
            pdfContext.beginPDFPage(nil)
            drawUniversePage(
                context: pdfContext,
                universeNumber: universeNumber,
                universeData: universeData,
                overlaps: results.overlaps.filter { $0.universe == universeNumber },
                projectName: projectName,
                pageRect: pageRect,
                pageNumber: currentPage,
                totalPages: totalPages,
                companyLogo: companyLogo
            )
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        return pdfData as Data
    }
    
    private func drawSummaryPage(context: CGContext, results: DMXUniverseResults, projectName: String, pageRect: CGRect, pageNumber: Int, totalPages: Int, companyLogo: NSImage?) {
        context.saveGState()
        
        if let logo = companyLogo {
            let logoAreaRect = CGRect(x: pageRect.width - 150, y: pageRect.height - 40, width: 130, height: 30)
            let actualLogoRect = calculateLogoRect(logo: logo, availableRect: logoAreaRect)
            if let cgImage = logo.cgImage(forProposedRect: nil, context: nil, hints: nil) {
                context.draw(cgImage, in: actualLogoRect)
            }
        }
        
        drawHighQualityText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 30, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: true, centered: false)
        
        drawHighQualityText(context: context, text: "DMX Universe Analyse - Zusammenfassung", rect: CGRect(x: margin, y: pageRect.height - 55, width: pageRect.width - 2 * margin, height: 20), fontSize: 16, bold: true, centered: false)
        
        var currentY: CGFloat = pageRect.height - 100
        
        drawHighQualityText(context: context, text: "Gesamt Universen: \(results.universes.count)", rect: CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: false, centered: false)
        currentY -= 20
        
        drawHighQualityText(context: context, text: "Gesamt Fixtures: \(results.totalFixtures)", rect: CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: false, centered: false)
        currentY -= 20
        
        drawHighQualityText(context: context, text: "Überlappungen: \(results.overlaps.count)", rect: CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: false, centered: false)
        currentY -= 20
        
        drawHighQualityText(context: context, text: "Analysiert am: \(results.timestamp.formatted())", rect: CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: false, centered: false)
        currentY -= 40
        
        drawHighQualityText(context: context, text: "Universe Übersicht", rect: CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true, centered: false)
        
        currentY -= 40
        
        let columnWidth = (pageRect.width - 2 * margin) / 5
        let rowHeight: CGFloat = 20
        
        // Table Header
        drawTableCell(context: context, text: "Universe", rect: CGRect(x: margin, y: currentY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Fixtures", rect: CGRect(x: margin + columnWidth, y: currentY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Kanäle", rect: CGRect(x: margin + 2 * columnWidth, y: currentY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Auslastung", rect: CGRect(x: margin + 3 * columnWidth, y: currentY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Status", rect: CGRect(x: margin + 4 * columnWidth, y: currentY, width: columnWidth, height: rowHeight), isHeader: true)
        
        // Table Data
        var rowIndex = 1
        for (universeNumber, universeData) in results.universes.sorted(by: { $0.key < $1.key }) {
            let rowY = currentY - CGFloat(rowIndex) * rowHeight
            let usageColor = getUsageColor(universeData.usagePercentage)
            let statusText = getStatusText(universeData.usagePercentage)
            
            drawTableCell(context: context, text: "\(universeNumber)", rect: CGRect(x: margin, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            drawTableCell(context: context, text: "\(universeData.fixtures.count)", rect: CGRect(x: margin + columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            drawTableCell(context: context, text: "\(universeData.usedChannels)/512", rect: CGRect(x: margin + 2 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            drawTableCell(context: context, text: "\(String(format: "%.1f", universeData.usagePercentage))%", rect: CGRect(x: margin + 3 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false, bgColor: usageColor)
            drawTableCell(context: context, text: statusText, rect: CGRect(x: margin + 4 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false, bgColor: usageColor)
            
            rowIndex += 1
        }
        
        let tableEndY = currentY - CGFloat(rowIndex) * rowHeight
        
        // Overlaps Section
        if !results.overlaps.isEmpty {
            let overlapsStartY = tableEndY - 40
            
            drawHighQualityText(context: context, text: "⚠️ Überlappungen gefunden", rect: CGRect(x: margin, y: overlapsStartY, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true, centered: false)
            
            var overlapY = overlapsStartY - 30
            
            for overlap in results.overlaps.prefix(10) {
                let overlapText = "Universe \(overlap.universe), \(overlap.channelRange.displayText): \(overlap.fixtureIds.joined(separator: ", "))"
                drawHighQualityText(context: context, text: overlapText, rect: CGRect(x: margin, y: overlapY, width: pageRect.width - 2 * margin, height: 15), fontSize: 10, bold: false, centered: false)
                overlapY -= 20
            }
        }
        
        drawHighQualityText(context: context, text: "Seite \(pageNumber) von \(totalPages)", rect: CGRect(x: pageRect.width - 100, y: 20, width: 80, height: 15), fontSize: 10, bold: false, centered: true)
        
        context.restoreGState()
    }
    
    private func drawUniversePage(context: CGContext, universeNumber: Int, universeData: DMXUniverseData, overlaps: [DMXOverlap], projectName: String, pageRect: CGRect, pageNumber: Int, totalPages: Int, companyLogo: NSImage?) {
        context.saveGState()
        
        if let logo = companyLogo {
            let logoAreaRect = CGRect(x: pageRect.width - 150, y: pageRect.height - 40, width: 130, height: 30)
            let actualLogoRect = calculateLogoRect(logo: logo, availableRect: logoAreaRect)
            if let cgImage = logo.cgImage(forProposedRect: nil, context: nil, hints: nil) {
                context.draw(cgImage, in: actualLogoRect)
            }
        }
        
        drawHighQualityText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 30, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: true, centered: false)
        
        drawHighQualityText(context: context, text: "Universe \(universeNumber) - Detailansicht", rect: CGRect(x: margin, y: pageRect.height - 55, width: pageRect.width - 2 * margin, height: 20), fontSize: 16, bold: true, centered: false)
        
        let infoText = "Fixtures: \(universeData.fixtures.count)  •  Kanäle: \(universeData.usedChannels)/512  •  Auslastung: \(String(format: "%.1f", universeData.usagePercentage))%"
        drawHighQualityText(context: context, text: infoText, rect: CGRect(x: margin, y: pageRect.height - 75, width: pageRect.width - 2 * margin, height: 15), fontSize: 10, bold: false, centered: false)
        
        var currentY: CGFloat = pageRect.height - 110
        
        drawHighQualityText(context: context, text: "Adressbereiche", rect: CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true, centered: false)
        
        currentY -= 30
        
        let tableStartY = currentY
        let columnWidth = (pageRect.width - 2 * margin) / 5
        let rowHeight: CGFloat = 20
        
        // Table Header
        drawTableCell(context: context, text: "Fixture ID", rect: CGRect(x: margin, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Start", rect: CGRect(x: margin + columnWidth, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Ende", rect: CGRect(x: margin + 2 * columnWidth, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Kanäle", rect: CGRect(x: margin + 3 * columnWidth, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "DMX Modus", rect: CGRect(x: margin + 4 * columnWidth, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
        
        // Table Data
        var rowIndex = 1
        for range in universeData.addressRanges.prefix(25) {
            let rowY = tableStartY - CGFloat(rowIndex) * rowHeight
            
            drawTableCell(context: context, text: range.fixtureDisplayID, rect: CGRect(x: margin, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            drawTableCell(context: context, text: "\(range.startAddress)", rect: CGRect(x: margin + columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            drawTableCell(context: context, text: "\(range.endAddress)", rect: CGRect(x: margin + 2 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            drawTableCell(context: context, text: "\(range.endAddress - range.startAddress + 1)", rect: CGRect(x: margin + 3 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            drawTableCell(context: context, text: range.dmxMode, rect: CGRect(x: margin + 4 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false)
            
            rowIndex += 1
        }
        
        let tableEndY = tableStartY - CGFloat(rowIndex) * rowHeight
        
        // Overlaps Section
        if !overlaps.isEmpty {
            let overlapsStartY = tableEndY - 40
            
            drawHighQualityText(context: context, text: "⚠️ Überlappungen in diesem Universe", rect: CGRect(x: margin, y: overlapsStartY, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true, centered: false)
            
            var overlapY = overlapsStartY - 30
            
            for overlap in overlaps {
                let overlapText = "\(overlap.channelRange.displayText): \(overlap.fixtureIds.joined(separator: ", "))"
                drawHighQualityText(context: context, text: overlapText, rect: CGRect(x: margin, y: overlapY, width: pageRect.width - 2 * margin, height: 15), fontSize: 10, bold: false, centered: false)
                overlapY -= 20
            }
        }
        
        drawHighQualityText(context: context, text: "Seite \(pageNumber) von \(totalPages)", rect: CGRect(x: pageRect.width - 100, y: 20, width: 80, height: 15), fontSize: 10, bold: false, centered: true)
        
        context.restoreGState()
    }
    
    private func drawTableCell(context: CGContext, text: String, rect: CGRect, isHeader: Bool, bgColor: (red: CGFloat, green: CGFloat, blue: CGFloat) = (0.9, 0.9, 0.9)) {
        let r = bgColor.red
        let g = bgColor.green
        let b = bgColor.blue
        
        context.setFillColor(red: r, green: g, blue: b, alpha: 1.0)
        context.fill(rect)
        
        context.setStrokeColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(rect)
        
        drawHighQualityText(context: context, text: text, rect: rect.insetBy(dx: 4, dy: 2), fontSize: isHeader ? 10 : 9, bold: isHeader, centered: isHeader)
    }
    
    private func drawHighQualityText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool, centered: Bool) {
        context.saveGState()
        
        // Set ultra-high-quality rendering options
        context.setAllowsAntialiasing(true)
        context.setShouldAntialias(true)
        context.interpolationQuality = .high
        context.setRenderingIntent(.defaultIntent)
        context.setShouldSubpixelPositionFonts(true)
        context.setShouldSubpixelQuantizeFonts(true)
        
        // Create font with higher resolution
        let actualFontSize = fontSize * 1.2  // Increase font size for better quality
        let fontName = bold ? "Helvetica-Bold" : "Helvetica"
        let font = CTFontCreateWithName(fontName as CFString, actualFontSize, nil)
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = centered ? .center : .left
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black,
            .paragraphStyle: paragraphStyle
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        
        // Create CTLine for Core Text rendering
        let line = CTLineCreateWithAttributedString(attributedString)
        
        // Calculate text metrics
        let textBounds = CTLineGetBoundsWithOptions(line, .useOpticalBounds)
        let textWidth = textBounds.width
        let textHeight = textBounds.height
        
        // Calculate position based on alignment
        var x = rect.minX + 4
        if centered {
            x = rect.minX + (rect.width - textWidth) / 2
        }
        
        let y = rect.minY + (rect.height - textHeight) / 2
        
        // Set text position correctly for PDF coordinate system
        context.textMatrix = .identity
        context.textPosition = CGPoint(x: x, y: y)
        
        // Draw the text with Core Text for maximum quality
        CTLineDraw(line, context)
        
        context.restoreGState()
    }
    
    private func calculateLogoRect(logo: NSImage, availableRect: CGRect) -> CGRect {
        let logoSize = logo.size
        let logoAspectRatio = logoSize.width / logoSize.height
        let availableAspectRatio = availableRect.width / availableRect.height
        
        var logoRect: CGRect
        
        if logoAspectRatio > availableAspectRatio {
            let scaledHeight = availableRect.width / logoAspectRatio
            logoRect = CGRect(
                x: availableRect.minX,
                y: availableRect.minY + (availableRect.height - scaledHeight) / 2,
                width: availableRect.width,
                height: scaledHeight
            )
        } else {
            let scaledWidth = availableRect.height * logoAspectRatio
            logoRect = CGRect(
                x: availableRect.minX + (availableRect.width - scaledWidth) / 2,
                y: availableRect.minY,
                width: scaledWidth,
                height: availableRect.height
            )
        }
        
        return logoRect
    }
    
    private func getUsageColor(_ percentage: Double) -> (red: CGFloat, green: CGFloat, blue: CGFloat) {
        if percentage <= 50 {
            return (0.9, 0.9, 0.9)
        } else if percentage <= 80 {
            return (1, 1, 0)
        } else if percentage <= 100 {
            return (1, 0.5, 0)
        } else {
            return (1, 0, 0)
        }
    }
    
    private func getStatusText(_ percentage: Double) -> String {
        if percentage <= 50 {
            return "Niedrig"
        } else if percentage <= 80 {
            return "Mittel"
        } else if percentage <= 100 {
            return "Hoch"
        } else {
            return "Überlastung"
        }
    }
}