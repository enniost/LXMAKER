//
//  LXMAKERTests.swift
//  LXMAKERTests
//
//  Created by Ennio Staffiero on 09.07.2025.
//

import Testing
@testable import LXMAKER

struct LXMAKERTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
