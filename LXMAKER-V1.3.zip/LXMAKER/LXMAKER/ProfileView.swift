import SwiftUI
import SwiftData

struct ProfileView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var userProfiles: [UserProfile]
    
    @State private var userProfile: UserProfile
    @Environment(\.dismiss) private var dismiss
    
    init() {
        // Initialisiere mit einem leeren Profil, wird in onAppear aktualisiert
        self._userProfile = State(initialValue: UserProfile())
    }
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Persönliche Informationen") {
                    TextField("Vorname", text: $userProfile.firstName)
                    TextField("Nachname", text: $userProfile.lastName)
                    TextField("E-Mail", text: $userProfile.email)
                    TextField("Telefonnummer", text: $userProfile.phoneNumber)
                }
                
                Section("Profilinformationen") {
                    HStack {
                        Text("Vollständiger Name")
                        Spacer()
                        Text(userProfile.fullName)
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Kontaktinformationen")
                        Spacer()
                        Text(userProfile.contactInfo)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.trailing)
                    }
                }
            }
            .navigationTitle("Benutzerprofil")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        saveProfile()
                        dismiss()
                    }
                }
            }
            .onAppear {
                loadOrCreateProfile()
            }
        }
    }
    
    private func loadOrCreateProfile() {
        if let existingProfile = userProfiles.first {
            // Verwende das vorhandene Profil
            self.userProfile = existingProfile
        } else {
            // Erstelle ein neues Profil
            let newProfile = UserProfile()
            modelContext.insert(newProfile)
            self.userProfile = newProfile
        }
    }
    
    private func saveProfile() {
        userProfile.updatedAt = Date()
        do {
            try modelContext.save()
        } catch {
            print("Fehler beim Speichern des Profils: \(error)")
        }
    }
}