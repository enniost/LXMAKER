import SwiftUI
import AppKit
import CoreImage
import CoreImage.CIFilterBuiltins

struct QRCodeGeneratorView: View {
    @State private var urlString = ""
    @State private var qrCodeImage: NSImage?
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var alertTitle = ""
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("QR-Code Generator")
                    .font(.title)
                    .fontWeight(.bold)
                
                Text("Erstellen Sie einen QR-Code aus einem Link")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("Link eingeben:")
                        .font(.headline)
                    
                    TextField("https://example.com", text: $urlString)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .disabled(qrCodeImage != nil)
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                
                if let image = qrCodeImage {
                    VStack(spacing: 15) {
                        Text("Generierter QR-Code:")
                            .font(.headline)
                        
                        Image(nsImage: image)
                            .resizable()
                            .interpolation(.none)
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                    }
                }
                
                HStack(spacing: 15) {
                    if qrCodeImage != nil {
                        Button("Neuen QR-Code erstellen") {
                            resetGenerator()
                        }
                        .buttonStyle(.bordered)
                        
                        Button("QR-Code exportieren") {
                            exportQRCode()
                        }
                        .buttonStyle(.bordered)
                    } else {
                        Button("QR-Code generieren") {
                            generateQRCode()
                        }
                        .buttonStyle(.bordered)
                        .disabled(urlString.isEmpty || !isValidURL(urlString))
                    }
                }
                .padding(.top, 10)
                
                Spacer()
            }
            .padding()
            .navigationTitle("QR-Code Generator")
            .alert(alertTitle, isPresented: $showAlert) {
                Button("OK") { }
            } message: {
                Text(alertMessage)
            }
        }
    }
    
    private func generateQRCode() {
        guard !urlString.isEmpty else {
            showAlert(message: "Bitte geben Sie einen Link ein.", title: "Kein Link")
            return
        }
        
        guard isValidURL(urlString) else {
            showAlert(message: "Bitte geben Sie eine gültige URL ein.", title: "Ungültiger Link")
            return
        }
        
        guard let qrImage = createQRCode(from: urlString) else {
            showAlert(message: "QR-Code konnte nicht generiert werden.", title: "Fehler")
            return
        }
        
        self.qrCodeImage = qrImage
    }
    
    private func createQRCode(from string: String) -> NSImage? {
        let data = string.data(using: .utf8)
        
        let context = CIContext()
        let filter = CIFilter.qrCodeGenerator()
        filter.setValue(data, forKey: "inputMessage")
        
        guard let outputImage = filter.outputImage else { return nil }
        
        // Skalieren des QR-Codes für bessere Auflösung
        let scaledImage = outputImage.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
        
        guard let cgImage = context.createCGImage(scaledImage, from: scaledImage.extent) else { return nil }
        
        return NSImage(cgImage: cgImage, size: .zero)
    }
    
    private func exportQRCode() {
        guard let image = qrCodeImage else { return }
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = "QR_Code_\(urlString.replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "http://", with: "").components(separatedBy: "/").first ?? "link").png"
        savePanel.allowedContentTypes = [.png]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                // Konvertiere NSImage zu PNG-Daten
                guard let tiffData = image.tiffRepresentation,
                      let bitmapRep = NSBitmapImageRep(data: tiffData),
                      let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
                    showAlert(message: "QR-Code konnte nicht exportiert werden.", title: "Exportfehler")
                    return
                }
                
                try pngData.write(to: url)
                showAlert(message: "QR-Code wurde erfolgreich als PNG-Datei exportiert.", title: "Export erfolgreich")
            } catch {
                showAlert(message: "Fehler beim Exportieren: \(error.localizedDescription)", title: "Exportfehler")
            }
        }
    }
    
    private func resetGenerator() {
        urlString = ""
        qrCodeImage = nil
    }
    
    private func isValidURL(_ string: String) -> Bool {
        let urlRegEx = "^(https?://)?(www\\.)?([a-zA-Z0-9]+(-?[a-zA-Z0-9])*\\.)+[\\w]{2,}(\\/\\S*)?$"
        let urlTest = NSPredicate(format:"SELF MATCHES %@", urlRegEx)
        return urlTest.evaluate(with: string)
    }
    
    private func showAlert(message: String, title: String) {
        alertMessage = message
        alertTitle = title
        showAlert = true
    }
}

struct QRCodeGeneratorView_Previews: PreviewProvider {
    static var previews: some View {
        QRCodeGeneratorView()
    }
}
