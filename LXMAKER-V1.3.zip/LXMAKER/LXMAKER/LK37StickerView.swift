import SwiftUI
import SwiftData
import UniformTypeIdentifiers
import AppKit

struct LK37StickerView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var isImportingCSV = false
    @State private var lk37Data: [[String: String]] = []
    @State private var csvHeaders: [String] = []
    @State private var showError = false
    @State private var errorMessage = ""
    
    // Spalten-Zuordnungen für LK37-Design
    @State private var idColumnSelection = ""
    @State private var nameColumnSelection = ""
    @State private var lengthColumnSelection = ""
    
    // Channel assignments for each LK37 entry
    @State private var channelAssignments: [Int: [Int: String]] = [:] // Entry index -> [Channel number -> Channel name]
    
    // Preview-Einstellungen
    @State private var selectedPreviewIndex = 0
    
    // Available channel options (can be loaded from CSV or predefined)
    @State private var availableChannels: [String] = []
    @State private var channelColumnSelections: [Int: String] = [:] // Channel 1-12 -> CSV column
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 25) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text("LK37 Sticker Generator")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Erstellt LK37-Etiketten im Herma 4426-Format mit XLR-Design")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            csvImportSection
                            
                            if !lk37Data.isEmpty {
                                columnMappingSection
                                exportSection
                            }
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Preview & Channel Assignment
                        VStack(alignment: .leading, spacing: 20) {
                            if !lk37Data.isEmpty && canGenerateStickers {
                                previewSection
                                
                                if selectedPreviewIndex < lk37Data.count {
                                    channelAssignmentSection
                                }
                            } else {
                                instructionSection
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(20)
            }
            .navigationTitle("LK37 Sticker")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        saveSettings()
                        dismiss()
                    }
                }
            }
            .fileImporter(
                isPresented: $isImportingCSV,
                allowedContentTypes: [.commaSeparatedText],
                allowsMultipleSelection: false
            ) { result in
                handleCSVImport(result: result)
            }
            .alert("Fehler", isPresented: $showError) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(errorMessage)
            }
            .onAppear {
                loadSettings()
            }
        }
        .frame(minWidth: 1200, minHeight: 800)
    }
    
    // MARK: - CSV Import Section
    
    private var csvImportSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("1. LK37 CSV-Datei importieren")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                if lk37Data.isEmpty {
                    Button("CSV-Datei auswählen") {
                        isImportingCSV = true
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.large)
                } else {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("✅ CSV-Datei geladen")
                                .foregroundColor(.green)
                                .fontWeight(.medium)
                            
                            Text("\(lk37Data.count) Einträge gefunden")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        Button("Neue Datei laden") {
                            isImportingCSV = true
                        }
                        .buttonStyle(.bordered)
                    }
                }
                
                Text("Die CSV-Datei sollte Spalten für ID, Name und Länge enthalten.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(20)
        .background(Color.blue.opacity(0.05))
        .cornerRadius(12)
    }
    
    // MARK: - Column Mapping Section
    
    private var columnMappingSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("2. Spalten zuordnen")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 15) {
                // ID Column
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("ID-Spalte:")
                            .frame(width: 100, alignment: .leading)
                            .fontWeight(.medium)
                        
                        Picker("ID", selection: $idColumnSelection) {
                            Text("-- Auswählen --").tag("")
                            ForEach(csvHeaders, id: \.self) { header in
                                Text(header).tag(header)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 200)
                    }
                    Text("Für die Nummer im Etikett (z.B. \"1\", \"2\", etc.)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                // Name Column
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Name-Spalte:")
                            .frame(width: 100, alignment: .leading)
                            .fontWeight(.medium)
                        
                        Picker("Name", selection: $nameColumnSelection) {
                            Text("-- Auswählen --").tag("")
                            ForEach(csvHeaders, id: \.self) { header in
                                Text(header).tag(header)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 200)
                    }
                    Text("Für den Namen (z.B. \"LK 1\", \"LK 2\", etc.)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                // Length Column (Optional)
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Länge-Spalte:")
                            .frame(width: 100, alignment: .leading)
                            .fontWeight(.medium)
                        
                        Picker("Länge", selection: $lengthColumnSelection) {
                            Text("-- Optional --").tag("")
                            ForEach(csvHeaders, id: \.self) { header in
                                Text(header).tag(header)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 200)
                    }
                    Text("Optional: Für die Längenangabe")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(20)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(12)
    }
    
    // MARK: - Preview Section
    
    private var previewSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Etikett-Vorschau:")
                .font(.headline)
                .fontWeight(.medium)
            
            // Preview controls
            HStack {
                Text("Eintrag:")
                
                Picker("Preview", selection: $selectedPreviewIndex) {
                    ForEach(0..<min(lk37Data.count, 10), id: \.self) { index in
                        Text("\(index + 1)").tag(index)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .frame(width: 80)
                
                Spacer()
                
                Text("\(lk37Data.count) Etiketten gesamt")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            // Preview of LK37 sticker design
            if selectedPreviewIndex < lk37Data.count {
                LK37StickerPreview(
                    data: createStickerData(from: lk37Data[selectedPreviewIndex])
                )
                .frame(width: 315, height: 210) // Korrektes Seitenverhältnis für 105x70mm (3:2 ratio)
                .border(Color.gray, width: 1)
            }
        }
        .padding(15)
        .background(Color.gray.opacity(0.05))
        .cornerRadius(10)
    }
    
    // MARK: - Export Section
    
    private var exportSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("3. PDF exportieren")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                Button("PDF erstellen (Herma 4426)") {
                    exportToPDF()
                }
                .disabled(!canGenerateStickers)
                .buttonStyle(.bordered)
                .controlSize(.large)
                
                Text("Erstellt ein PDF mit LK37-Etiketten im Herma 4426-Format")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(15)
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }
    
    // MARK: - Instruction Section
    
    private var instructionSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Anleitung:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(alignment: .leading, spacing: 8) {
                Text("• Laden Sie eine CSV-Datei mit LK37-Daten")
                Text("• Ordnen Sie die Spalten für ID und Name zu")
                Text("• Optional: Wählen Sie eine Längen-Spalte")
                Text("• Betrachten Sie die Vorschau")
                Text("• Exportieren Sie als PDF im Herma 4426-Format")
            }
            .font(.subheadline)
            .foregroundColor(.secondary)
            
            Spacer()
        }
        .padding(15)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
    }
    
    // MARK: - Channel Assignment Section
    
    private var channelAssignmentSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Kanal-Zuordnung für Eintrag \(selectedPreviewIndex + 1):")
                .font(.headline)
                .fontWeight(.medium)
            
            Text("Ordnen Sie den 12 Kanälen die entsprechenden Spalten aus der CSV zu:")
                .font(.caption)
                .foregroundColor(.secondary)
            
            ScrollView {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 2), spacing: 10) {
                    ForEach(1...12, id: \.self) { channelNumber in
                        channelAssignmentRow(for: channelNumber)
                    }
                }
                .padding(.vertical)
            }
            .frame(maxHeight: 300)
            
            HStack {
                Button("Auto-Zuordnung") {
                    performAutoChannelAssignment()
                }
                .buttonStyle(.bordered)
                
                Spacer()
                
                Button("Alle löschen") {
                    clearChannelAssignments()
                }
                .buttonStyle(.bordered)
                .foregroundColor(.red)
            }
        }
        .padding(15)
        .background(Color.purple.opacity(0.1))
        .cornerRadius(12)
    }
    
    private func channelAssignmentRow(for channelNumber: Int) -> some View {
        HStack {
            Text("CH \(channelNumber):")
                .font(.system(size: 12, weight: .medium))
                .frame(width: 35, alignment: .leading)
            
            Picker("Channel \(channelNumber)", selection: Binding(
                get: { channelColumnSelections[channelNumber] ?? "" },
                set: { newValue in
                    channelColumnSelections[channelNumber] = newValue
                    updateChannelAssignment(channel: channelNumber, column: newValue)
                }
            )) {
                Text("-- Leer --").tag("")
                ForEach(csvHeaders, id: \.self) { header in
                    Text(header).tag(header)
                }
            }
            .pickerStyle(MenuPickerStyle())
            .font(.system(size: 11))
        }
        .frame(height: 30)
    }
    
    // MARK: - Computed Properties
    
    private var canGenerateStickers: Bool {
        !lk37Data.isEmpty && !idColumnSelection.isEmpty && !nameColumnSelection.isEmpty
    }
    
    // MARK: - Helper Methods
    
    private func updateChannelAssignment(channel: Int, column: String) {
        if channelAssignments[selectedPreviewIndex] == nil {
            channelAssignments[selectedPreviewIndex] = [:]
        }
        
        if column.isEmpty {
            channelAssignments[selectedPreviewIndex]?[channel] = nil
        } else if selectedPreviewIndex < lk37Data.count {
            let channelName = lk37Data[selectedPreviewIndex][column] ?? ""
            channelAssignments[selectedPreviewIndex]?[channel] = channelName.isEmpty ? "CH \(channel)" : channelName
        }
    }
    
    private func performAutoChannelAssignment() {
        // Smart auto-assignment based on column names and numbers
        let channelPatterns = [
            (1, ["ch1", "channel1", "kanal1", "ch 1", "channel 1", "kanal 1", "1"]),
            (2, ["ch2", "channel2", "kanal2", "ch 2", "channel 2", "kanal 2", "2"]),
            (3, ["ch3", "channel3", "kanal3", "ch 3", "channel 3", "kanal 3", "3"]),
            (4, ["ch4", "channel4", "kanal4", "ch 4", "channel 4", "kanal 4", "4"]),
            (5, ["ch5", "channel5", "kanal5", "ch 5", "channel 5", "kanal 5", "5"]),
            (6, ["ch6", "channel6", "kanal6", "ch 6", "channel 6", "kanal 6", "6"]),
            (7, ["ch7", "channel7", "kanal7", "ch 7", "channel 7", "kanal 7", "7"]),
            (8, ["ch8", "channel8", "kanal8", "ch 8", "channel 8", "kanal 8", "8"]),
            (9, ["ch9", "channel9", "kanal9", "ch 9", "channel 9", "kanal 9", "9"]),
            (10, ["ch10", "channel10", "kanal10", "ch 10", "channel 10", "kanal 10", "10"]),
            (11, ["ch11", "channel11", "kanal11", "ch 11", "channel 11", "kanal 11", "11"]),
            (12, ["ch12", "channel12", "kanal12", "ch 12", "channel 12", "kanal 12", "12"])
        ]
        
        // First try exact pattern matching
        for (channelNumber, patterns) in channelPatterns {
            for header in csvHeaders {
                let lowercaseHeader = header.lowercased()
                if patterns.contains(where: { lowercaseHeader.contains($0) }) {
                    channelColumnSelections[channelNumber] = header
                    updateChannelAssignment(channel: channelNumber, column: header)
                    break
                }
            }
        }
        
        // Then try number extraction from column names
        for header in csvHeaders {
            // Extract numbers from column name
            let numbers = extractNumbersFromString(header)
            for number in numbers {
                if number >= 1 && number <= 12 {
                    // Only assign if not already assigned
                    if channelColumnSelections[number] == nil {
                        channelColumnSelections[number] = header
                        updateChannelAssignment(channel: number, column: header)
                    }
                }
            }
        }
    }
    
    private func extractNumbersFromString(_ string: String) -> [Int] {
        var numbers: [Int] = []
        let numberRegex = try! NSRegularExpression(pattern: "\\d+", options: [])
        let matches = numberRegex.matches(in: string, options: [], range: NSRange(location: 0, length: string.count))
        
        for match in matches {
            if let range = Range(match.range, in: string) {
                let numberString = String(string[range])
                if let number = Int(numberString) {
                    numbers.append(number)
                }
            }
        }
        
        return numbers
    }
    
    private func clearChannelAssignments() {
        channelColumnSelections.removeAll()
        channelAssignments[selectedPreviewIndex] = [:]
    }
    
    private func handleCSVImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let files):
            guard let file = files.first else { return }
            
            do {
                let securityScopedFile = file.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        file.stopAccessingSecurityScopedResource()
                    }
                }
                
                let content = try String(contentsOf: file, encoding: .utf8)
                let csvData = try CSVParser.parse(csvString: content)
                
                self.lk37Data = csvData.rows
                self.csvHeaders = csvData.headers
                
                // Store CSV data in project
                project.lk37CSVData = content.data(using: .utf8)
                
                // Reset selections
                idColumnSelection = ""
                nameColumnSelection = ""
                lengthColumnSelection = ""
                selectedPreviewIndex = 0
                channelAssignments.removeAll()
                channelColumnSelections.removeAll()
                
                // Perform auto-assignment for columns
                performAutoColumnAssignment()
                
                try modelContext.save()
                
            } catch CSVError.invalidFormat {
                errorMessage = "Ungültiges CSV-Format. Bitte stellen Sie sicher, dass die Datei Semikolon-getrennt ist."
                showError = true
            } catch CSVError.invalidData {
                errorMessage = "Ungültige Daten in der CSV-Datei."
                showError = true
            } catch {
                errorMessage = "Fehler beim Importieren der Datei: \(error.localizedDescription)"
                showError = true
            }
            
        case .failure(let error):
            errorMessage = "Fehler beim Öffnen der Datei: \(error.localizedDescription)"
            showError = true
        }
    }
    
    private func createStickerData(from rowData: [String: String]) -> LK37StickerData {
        let id = rowData[idColumnSelection] ?? ""
        let name = rowData[nameColumnSelection] ?? ""
        let length = lengthColumnSelection.isEmpty ? nil : rowData[lengthColumnSelection]
        
        // Get channel assignments for this entry
        let assignments = channelAssignments[selectedPreviewIndex] ?? [:]
        
        return LK37StickerData(id: id, name: name, length: length, channelAssignments: assignments)
    }
    
    private func exportToPDF() {
        guard canGenerateStickers else { return }
        
        let stickerDataArray = lk37Data.enumerated().map { (index, rowData) in
            let id = rowData[idColumnSelection] ?? ""
            let name = rowData[nameColumnSelection] ?? ""
            let length = lengthColumnSelection.isEmpty ? nil : rowData[lengthColumnSelection]
            
            // Build channel assignments for this specific entry
            var assignments: [Int: String] = [:]
            for channelNumber in 1...12 {
                if let columnName = channelColumnSelections[channelNumber],
                   !columnName.isEmpty {
                    let channelValue = rowData[columnName] ?? ""
                    if !channelValue.isEmpty {
                        assignments[channelNumber] = channelValue
                    }
                }
            }
            
            return LK37StickerData(id: id, name: name, length: length, channelAssignments: assignments)
        }
        
        let pdfCreator = LK37StickerPDFCreator()
        let pdfData = pdfCreator.createPDF(
            projectName: project.name,
            stickerData: stickerDataArray
        )
        
        let filename = "LK37_Sticker_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die LK37-Etiketten wurden erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                errorMessage = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                showError = true
            }
        }
    }
    
    private func loadSettings() {
        // Load CSV data if available
        if let csvData = project.lk37CSVData,
           let csvString = String(data: csvData, encoding: .utf8) {
            do {
                let parsedData = try CSVParser.parse(csvString: csvString)
                self.lk37Data = parsedData.rows
                self.csvHeaders = parsedData.headers
            } catch {
                print("Error loading saved CSV data: \(error)")
            }
        }
    }
    
    private func performAutoColumnAssignment() {
        // Auto-assign main columns
        for header in csvHeaders {
            let lowercaseHeader = header.lowercased()
            
            // ID column detection
            if idColumnSelection.isEmpty {
                if lowercaseHeader.contains("id") || lowercaseHeader.contains("nummer") || lowercaseHeader.contains("nr") {
                    idColumnSelection = header
                }
            }
            
            // Name column detection  
            if nameColumnSelection.isEmpty {
                if lowercaseHeader.contains("name") || lowercaseHeader.contains("bezeichnung") || lowercaseHeader.contains("title") {
                    nameColumnSelection = header
                }
            }
            
            // Length column detection
            if lengthColumnSelection.isEmpty {
                if lowercaseHeader.contains("länge") || lowercaseHeader.contains("length") || lowercaseHeader.contains("meter") || lowercaseHeader.contains("m") {
                    lengthColumnSelection = header
                }
            }
        }
        
        // Auto-assign channels
        performAutoChannelAssignment()
    }
    
    private func saveSettings() {
        // Settings are automatically saved when CSV is imported
        do {
            try modelContext.save()
        } catch {
            print("Error saving LK37 settings: \(error)")
        }
    }
}

// MARK: - LK37 Sticker Data Model

struct LK37StickerData {
    let id: String
    let name: String
    let length: String?
    var channelAssignments: [Int: String] // Channel number -> Channel name
    
    init(id: String, name: String, length: String? = nil, channelAssignments: [Int: String] = [:]) {
        self.id = id
        self.name = name
        self.length = length
        self.channelAssignments = channelAssignments
    }
}

// MARK: - Channel Assignment Data
struct ChannelAssignment {
    let channelNumber: Int
    let channelName: String
}

// MARK: - LK37 Sticker Preview

struct LK37StickerPreview: View {
    let data: LK37StickerData
    
    var body: some View {
        VStack(spacing: 0) {
            // Header mit Titel (ohne XLR-Symbol)
            HStack {
                VStack(alignment: .leading) {
                    Text("LK37 - DMX 5P")
                        .font(.system(size: 14, weight: .bold))
                    Text(data.id)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.primary)
                }
                
                Spacer()
                
                if let length = data.length, !length.isEmpty {
                    VStack(alignment: .trailing) {
                        Text("Länge")
                            .font(.system(size: 10))
                            .foregroundColor(.secondary)
                        Text(length)
                            .font(.system(size: 12, weight: .medium))
                    }
                }
            }
            .padding(.horizontal, 8)
            .padding(.top, 8)
            
            // Name Section
            HStack {
                Text("\(data.name)")
                    .font(.system(size: 12, weight: .bold))
                Spacer()
            }
            .padding(.horizontal, 8)
            .padding(.top, 4)
            
            // Grid with numbers and names
            VStack(spacing: 1) {
                // Create grid entries from actual channel assignments
                let entries = createPreviewGridEntries()
                
                ForEach(0..<6, id: \.self) { row in
                    HStack(spacing: 1) {
                        // Left column
                        if row * 2 < entries.count {
                            let entry = entries[row * 2]
                            createGridCell(number: entry.number, name: entry.name)
                        } else {
                            createEmptyCell()
                        }
                        
                        // Right column
                        if row * 2 + 1 < entries.count {
                            let entry = entries[row * 2 + 1]
                            createGridCell(number: entry.number, name: entry.name)
                        } else {
                            createEmptyCell()
                        }
                    }
                }
            }
            .padding(.horizontal, 8)
            .padding(.bottom, 8)
        }
        .background(Color.white)
        .overlay(
            RoundedRectangle(cornerRadius: 4)
                .stroke(Color.gray, lineWidth: 1)
        )
    }
    
    private func createPreviewGridEntries() -> [(number: String, name: String)] {
        var entries: [(number: String, name: String)] = []
        
        // Use actual channel assignments from data (not from state)
        for channelNumber in 1...12 {
            if let channelName = data.channelAssignments[channelNumber], !channelName.isEmpty {
                entries.append((number: "\(channelNumber)", name: channelName))
            } else {
                entries.append((number: "\(channelNumber)", name: ""))
            }
        }
        
        return entries
    }
    
    private func createGridCell(number: String, name: String) -> some View {
        HStack(spacing: 0) {
            Text(number)
                .font(.system(size: 10, weight: .bold))
                .frame(width: 15)
                .frame(height: 16)
                .background(Color.gray.opacity(0.3))
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
            
            Text(name)
                .font(.system(size: 9))
                .frame(maxWidth: .infinity, alignment: .leading)
                .frame(height: 16)
                .padding(.leading, 2)
        }
        .background(Color.gray.opacity(0.1))
        .overlay(Rectangle().stroke(Color.black, lineWidth: 0.5))
    }
    
    private func createEmptyCell() -> some View {
        HStack {
            Text("")
                .frame(width: 15)
                .background(Color.gray.opacity(0.3))
            
            Text("")
                .frame(maxWidth: .infinity)
        }
        .frame(height: 16)
        .background(Color.gray.opacity(0.1))
        .overlay(Rectangle().stroke(Color.black, lineWidth: 0.5))
    }
}

// MARK: - LK37 Sticker PDF Creator

class LK37StickerPDFCreator {
    func createPDF(projectName: String, stickerData: [LK37StickerData]) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        // A4 Page dimensions in points
        let pageWidth: CGFloat = 595.28  // A4 width in points (210mm)
        let pageHeight: CGFloat = 841.89 // A4 height in points (297mm)
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        
        // HERMA 4426 specifications: 105 x 70 mm, 8 labels per page (2 columns x 4 rows)
        let stickerWidth: CGFloat = 105 * 2.834   // ~297 points (105mm)
        let stickerHeight: CGFloat = 70 * 2.834   // ~198 points (70mm)
        
        // Calculate margins to center the labels on A4
        let totalWidth = 2 * stickerWidth
        let totalHeight = 4 * stickerHeight
        let leftMargin = (pageWidth - totalWidth) / 2
        let topMargin = (pageHeight - totalHeight) / 2
        
        let columnsPerPage = 2
        let rowsPerPage = 4
        let stickersPerPage = columnsPerPage * rowsPerPage // 8 labels per page
        
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        let totalPages = Int(ceil(Double(stickerData.count) / Double(stickersPerPage)))
        
        for page in 0..<totalPages {
            pdfContext.beginPDFPage(nil)
            
            let startIndex = page * stickersPerPage
            let endIndex = min(startIndex + stickersPerPage, stickerData.count)
            
            for index in startIndex..<endIndex {
                let stickerIndex = index - startIndex
                let row = stickerIndex / columnsPerPage
                let col = stickerIndex % columnsPerPage
                
                let x = leftMargin + CGFloat(col) * stickerWidth
                let y = pageHeight - topMargin - CGFloat(row + 1) * stickerHeight
                
                let stickerRect = CGRect(x: x, y: y, width: stickerWidth, height: stickerHeight)
                
                drawLK37Sticker(
                    context: pdfContext,
                    rect: stickerRect,
                    data: stickerData[index]
                )
            }
            
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        return pdfData as Data
    }
    
    private func drawLK37Sticker(context: CGContext, rect: CGRect, data: LK37StickerData) {
        // Background
        context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        context.fill(rect)
        
        // Border - einheitliche Linienstärke
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(rect)
        
        let margin: CGFloat = 8
        let contentRect = rect.insetBy(dx: margin, dy: margin)
        
        // Header section (top ~25% of sticker)
        let headerHeight = contentRect.height * 0.25
        let headerRect = CGRect(x: contentRect.minX, y: contentRect.maxY - headerHeight, width: contentRect.width, height: headerHeight)
        
        // Header text - ohne XLR-Icon, beginnt am linken Rand
        drawText(context: context, 
                text: "LK37 - DMX 5P", 
                rect: CGRect(x: headerRect.minX, y: headerRect.minY + headerHeight * 0.6, width: headerRect.width - 60, height: headerHeight * 0.4), 
                fontSize: 14, 
                bold: true)
        
        // ID value anzeigen statt nur "ID" Label
        drawText(context: context, 
                text: data.id, 
                rect: CGRect(x: headerRect.minX, y: headerRect.minY + headerHeight * 0.1, width: headerRect.width - 60, height: headerHeight * 0.3), 
                fontSize: 12, 
                bold: true)
        
        // Length (if available) on the right
        if let length = data.length, !length.isEmpty {
            let lengthWidth: CGFloat = 50
            drawText(context: context, 
                    text: "Länge", 
                    rect: CGRect(x: headerRect.maxX - lengthWidth, y: headerRect.minY + headerHeight * 0.6, width: lengthWidth, height: headerHeight * 0.4), 
                    fontSize: 8, 
                    bold: false)
            
            drawText(context: context, 
                    text: length, 
                    rect: CGRect(x: headerRect.maxX - lengthWidth, y: headerRect.minY + headerHeight * 0.1, width: lengthWidth, height: headerHeight * 0.3), 
                    fontSize: 10, 
                    bold: true)
        }
        
        // Name section
        let nameHeight: CGFloat = 20
        let nameRect = CGRect(x: contentRect.minX, y: contentRect.maxY - headerHeight - nameHeight - 4, width: contentRect.width, height: nameHeight)
        
        drawText(context: context, 
                text: data.name, 
                rect: nameRect, 
                fontSize: 12, 
                bold: true)
        
        // Grid section (remaining space) - 2 columns, 6 rows = 12 entries
        let gridRect = CGRect(x: contentRect.minX, y: contentRect.minY, width: contentRect.width, height: contentRect.height - headerHeight - nameHeight - 8)
        
        let gridEntries = createSampleGridEntries(from: data)
        let cellWidth = gridRect.width / 2
        let cellHeight = gridRect.height / 6
        
        for row in 0..<6 {
            for col in 0..<2 {
                let entryIndex = row * 2 + col
                
                let cellRect = CGRect(
                    x: gridRect.minX + CGFloat(col) * cellWidth,
                    y: gridRect.maxY - CGFloat(row + 1) * cellHeight,
                    width: cellWidth,
                    height: cellHeight
                )
                
                // Cell border - einheitliche Linienstärke
                context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                context.setLineWidth(0.5)
                context.stroke(cellRect)
                
                if entryIndex < gridEntries.count {
                    let entry = gridEntries[entryIndex]
                    
                    // Number background (left part of cell)
                    let numberWidth: CGFloat = 25
                    let numberRect = CGRect(x: cellRect.minX, y: cellRect.minY, width: numberWidth, height: cellRect.height)
                    context.setFillColor(red: 0.85, green: 0.85, blue: 0.85, alpha: 1.0)
                    context.fill(numberRect)
                    
                    // Separator line between number and name - einheitliche Linienstärke
                    context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
                    context.setLineWidth(0.5)
                    context.move(to: CGPoint(x: cellRect.minX + numberWidth, y: cellRect.minY))
                    context.addLine(to: CGPoint(x: cellRect.minX + numberWidth, y: cellRect.maxY))
                    context.strokePath()
                    
                    // Number text - zentriert
                    drawTextCentered(context: context, 
                            text: entry.number, 
                            rect: numberRect, 
                            fontSize: 10, 
                            bold: true)
                    
                    // Name text - vertikal zentriert
                    let nameTextRect = CGRect(x: cellRect.minX + numberWidth + 2, y: cellRect.minY, width: cellRect.width - numberWidth - 2, height: cellRect.height)
                    drawTextVerticallyAndHorizontallyCentered(context: context, 
                            text: entry.name, 
                            rect: nameTextRect, 
                            fontSize: 9, 
                            bold: false,
                            alignment: .left)
                }
            }
        }
    }
    
    private func createSampleGridEntries(from data: LK37StickerData) -> [(number: String, name: String)] {
        var entries: [(number: String, name: String)] = []
        
        // Use actual channel assignments
        for channelNumber in 1...12 {
            if let channelName = data.channelAssignments[channelNumber], !channelName.isEmpty {
                entries.append((number: "\(channelNumber)", name: channelName))
            } else {
                entries.append((number: "\(channelNumber)", name: ""))
            }
        }
        
        return entries
    }
    
    private func drawTextCentered(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        // Get text bounds to center it
        let textBounds = CTLineGetBoundsWithOptions(line, [])
        let textWidth = textBounds.width
        let textHeight = textBounds.height
        
        let centeredX = rect.minX + (rect.width - textWidth) / 2
        let centeredY = rect.minY + (rect.height - textHeight) / 2
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: centeredX, y: centeredY)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        context.restoreGState()
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: rect.minX + 0.5, y: rect.minY + 0.5)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        context.restoreGState()
    }
    
    private func drawTextVerticallyAndHorizontallyCentered(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool, alignment: TextAlignment = .center) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        // Get text bounds for centering
        let textBounds = CTLineGetBoundsWithOptions(line, [])
        let textWidth = textBounds.width
        let textHeight = textBounds.height
        
        // Calculate position based on alignment
        let x: CGFloat
        switch alignment {
        case .left:
            x = rect.minX + 2
        case .right:
            x = rect.maxX - textWidth - 2
        case .center:
            x = rect.minX + (rect.width - textWidth) / 2
        }
        
        // Always center vertically
        let centeredY = rect.minY + (rect.height - textHeight) / 2
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: x, y: centeredY)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        context.restoreGState()
    }
    
    enum TextAlignment {
        case left, center, right
    }
}
