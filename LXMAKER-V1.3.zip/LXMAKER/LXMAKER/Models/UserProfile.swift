import Foundation
import SwiftData

@Model
final class UserProfile {
    @Attribute(.unique) var id: String
    var firstName: String
    var lastName: String
    var email: String
    var phoneNumber: String
    var createdAt: Date
    var updatedAt: Date
    
    init() {
        self.id = "default"
        self.firstName = ""
        self.lastName = ""
        self.email = ""
        self.phoneNumber = ""
        self.createdAt = Date()
        self.updatedAt = Date()
    }
    
    var fullName: String {
        let fullName = "\(firstName) \(lastName)".trimmingCharacters(in: .whitespaces)
        return fullName.isEmpty ? "Unbekannter Benutzer" : fullName
    }
    
    var contactInfo: String {
        var infoParts: [String] = []
        
        if !fullName.isEmpty && fullName != "Unbekannter Benutzer" {
            infoParts.append(fullName)
        }
        
        if !email.isEmpty {
            infoParts.append(email)
        }
        
        if !phoneNumber.isEmpty {
            infoParts.append(phoneNumber)
        }
        
        return infoParts.joined(separator: " | ")
    }
}