import Foundation
import SwiftData

@Model
final class NetworkComponent {
    @Attribute(.unique) var id: String
    var name: String
    var position: String
    var ipAddress: String
    var subnetMask: String
    var vlan: String
    var universes: String  // Neue Eigenschaft für DMX-Universen
    var createdAt: Date
    
    init(name: String, position: String, ipAddress: String, subnetMask: String = "255.255.255.0", vlan: String, universes: String = "") {
        self.id = UUID().uuidString
        self.name = name
        self.position = position
        self.ipAddress = ipAddress
        self.subnetMask = subnetMask
        self.vlan = vlan
        self.universes = universes
        self.createdAt = Date()
    }
}

@Model
final class FollowSpot {
    @Attribute(.unique) var id: String
    var name: String
    var filterSlots: String // JSON String for filter assignments
    var createdAt: Date
    
    init(name: String) {
        self.id = UUID().uuidString
        self.name = name
        self.filterSlots = "{}"
        self.createdAt = Date()
    }
    
    // Helper methods for filter slots
    func saveFilterSlots(_ slots: [Int: ColorFilter]) {
        let encodableSlots = slots.mapValues { FilterData(from: $0) }
        if let data = try? JSONEncoder().encode(encodableSlots),
           let jsonString = String(data: data, encoding: .utf8) {
            filterSlots = jsonString
        }
    }
    
    func loadFilterSlots() -> [Int: ColorFilter] {
        guard let data = filterSlots.data(using: .utf8),
              let decodedSlots = try? JSONDecoder().decode([Int: FilterData].self, from: data) else {
            return [:]
        }
        return decodedSlots.mapValues { $0.toColorFilter() }
    }
    
    // Helper struct for JSON encoding
    struct FilterData: Codable {
        let number: String
        let name: String
        let description: String
        let manufacturer: String
        
        init(from filter: ColorFilter) {
            self.number = filter.number
            self.name = filter.name
            self.description = filter.description
            self.manufacturer = filter.manufacturer.rawValue
        }
        
        func toColorFilter() -> ColorFilter {
            let manufacturer = ColorFilter.FilterManufacturer(rawValue: self.manufacturer) ?? .lee
            return ColorFilter(number: number, name: name, description: description, manufacturer: manufacturer)
        }
    }
}

@Model
final class PowerDistributor {
    @Attribute(.unique) var id: String
    var name: String
    var type: String // CEE 16/Schuko, CEE 32/CEE, etc.
    var isCustom: Bool
    var createdAt: Date
    
    init(name: String, type: String, isCustom: Bool = false) {
        self.id = UUID().uuidString
        self.name = name
        self.type = type
        self.isCustom = isCustom
        self.createdAt = Date()
    }
}

@Model
final class CustomPlugbox {
    @Attribute(.unique) var id: String
    var name: String
    var systemName: String
    var channels: Int
    var position: String
    var createdAt: Date
    
    init(name: String, systemName: String, channels: Int, position: String = "") {
        self.id = UUID().uuidString
        self.name = name
        self.systemName = systemName
        self.channels = channels
        self.position = position
        self.createdAt = Date()
    }
}

@Model
final class ElectricalSystem {
    @Attribute(.unique) var id: String
    var name: String
    var position: String
    var powerDistributorId: String?
    var powerDistributorName: String // Fallback für CSV-basierte Systeme
    var createdAt: Date
    
    init(name: String, position: String = "", powerDistributorName: String = "") {
        self.id = UUID().uuidString
        self.name = name
        self.position = position
        self.powerDistributorName = powerDistributorName
        self.createdAt = Date()
    }
}

@Model
final class Project {
    @Attribute(.unique) var id: String
    var name: String
    var projectNumber: String? // Neue Eigenschaft für Projektnummer
    var createdAt: Date
    var updatedAt: Date
    @Relationship(deleteRule: .cascade) var fixtures: [LightFixture]
    @Relationship(deleteRule: .cascade) var networkComponents: [NetworkComponent]
    @Relationship(deleteRule: .cascade) var followSpots: [FollowSpot]
    @Relationship(deleteRule: .cascade) var powerDistributors: [PowerDistributor] // Neue Relationship
    @Relationship(deleteRule: .cascade) var customPlugboxes: [CustomPlugbox] // Neue Relationship  
    @Relationship(deleteRule: .cascade) var electricalSystems: [ElectricalSystem] // Neue Relationship
    var savedViewsData: String
    var selectedIdentifierColumn: String?
    var columnOrder: [String] // Store the original CSV column order
    var columnWidths: [String: Double] // Store column widths
    
    // Power Calculation Settings
    var powerSystemColumn: String?
    var powerPowerColumn: String?
    var powerVoltage: Int = 230
    var powerSimultaneityFactor: Double = 1.0
    var powerSystemLimits: String = "{}" // JSON String for system limits
    var powerChannelLimits: String = "{}" // JSON String for channel limits
    
    // DMX Universe Settings
    var dmxUniverseColumn: String?
    var dmxAddressColumn: String?
    var dmxChannelColumn: String?
    
    // VT Label Settings
    var vtPlugboxColumn: String?
    var vtChannelColumn: String?
    var vtIdColumn: String?
    var vtPlugboxOrder: String?
    
    // Fixture Sticker Settings
    var fixtureFields: String = "[]" // JSON String for fixture fields
    
    // Patch List Settings
    var patchSelectedColumns: String = "[]" // JSON String for selected columns
    var patchSortColumn: String?
    var patchSortOrder: String = "ascending"
    var patchPageOrientation: String = "portrait"
    
    // GrandMA Calculator Settings
    var grandmaChannelColumn: String?
    var grandmaVersion: String = "grandMA3"
    
    // Project Overview Settings
    var overviewTypeColumn: String?
    var overviewModeColumn: String?
    var overviewUniverseColumn: String?
    
    // System Overview Settings
    var systemOverviewSystemColumn: String?
    var systemOverviewPlugboxColumn: String?
    
    init(name: String, projectNumber: String? = nil) {
        self.id = UUID().uuidString
        self.name = name
        self.projectNumber = projectNumber
        self.createdAt = Date()
        self.updatedAt = Date()
        self.fixtures = []
        self.networkComponents = []
        self.followSpots = []
        self.powerDistributors = []
        self.customPlugboxes = []
        self.electricalSystems = []
        self.savedViewsData = "[]"
        self.selectedIdentifierColumn = "ID"
        self.columnOrder = []
        self.columnWidths = [:]
        
        // Initialisiere Standard-Stromverteiler
        initializeDefaultPowerDistributors()
    }
    
    private func initializeDefaultPowerDistributors() {
        let defaultDistributors = [
            ("CEE 16/Schuko", "CEE 16A mit Schuko-Ausgängen"),
            ("CEE 32/CEE", "CEE 32A mit CEE-Ausgängen"), 
            ("CEE 32/ML", "CEE 32A mit Multicore-Ausgängen"),
            ("CEE 63/CEE", "CEE 63A mit CEE-Ausgängen"),
            ("CEE 63/ML", "CEE 63A mit Multicore-Ausgängen"),
            ("CEE 125/CEE", "CEE 125A mit CEE-Ausgängen"),
            ("CEE 125/ML", "CEE 125A mit Multicore-Ausgängen"),
            ("PL400/CEE", "PL400 mit CEE-Ausgängen"),
            ("PL400/ML", "PL400 mit Multicore-Ausgängen")
        ]
        
        for (type, name) in defaultDistributors {
            let distributor = PowerDistributor(name: name, type: type, isCustom: false)
            powerDistributors.append(distributor)
        }
    }
    
    func getColumnWidth(for column: String) -> Double {
        return columnWidths[column] ?? 120.0 // Default width
    }
    
    func setColumnWidth(for column: String, width: Double) {
        columnWidths[column] = max(50.0, min(500.0, width)) // Min 50, Max 500
    }
    
    // Helper methods for JSON serialization
    func savePowerSystemLimits(_ limits: [String: Double]) {
        if let data = try? JSONEncoder().encode(limits),
           let jsonString = String(data: data, encoding: .utf8) {
            powerSystemLimits = jsonString
        }
    }
    
    func loadPowerSystemLimits() -> [String: Double] {
        guard let data = powerSystemLimits.data(using: .utf8),
              let limits = try? JSONDecoder().decode([String: Double].self, from: data) else {
            return [:]
        }
        return limits
    }
    
    func savePowerChannelLimits(_ limits: [String: Double]) {
        if let data = try? JSONEncoder().encode(limits),
           let jsonString = String(data: data, encoding: .utf8) {
            powerChannelLimits = jsonString
        }
    }
    
    func loadPowerChannelLimits() -> [String: Double] {
        guard let data = powerChannelLimits.data(using: .utf8),
              let limits = try? JSONDecoder().decode([String: Double].self, from: data) else {
            return [:]
        }
        return limits
    }
    
    func savePatchSelectedColumns(_ columns: [String]) {
        if let data = try? JSONEncoder().encode(columns),
           let jsonString = String(data: data, encoding: .utf8) {
            patchSelectedColumns = jsonString
        }
    }
    
    func loadPatchSelectedColumns() -> [String] {
        guard let data = patchSelectedColumns.data(using: .utf8),
              let columns = try? JSONDecoder().decode([String].self, from: data) else {
            return []
        }
        return columns
    }
}