import SwiftUI
import SwiftData
import AppKit

struct FollowSpotFilterView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedFollowSpot: FollowSpot?
    @State private var showAddFollowSpotDialog = false
    @State private var newFollowSpotName = ""
    @State private var showDeleteConfirmation = false
    @State private var followSpotToDelete: FollowSpot?
    @State private var logoOption: LogoOption = .none
    @State private var uploadedLogoData: Data? = nil
    @State private var showLogoImporter = false
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    var body: some View {
        NavigationStack {
            HStack(spacing: 0) {
                // Left Side - FollowSpot List
                VStack(spacing: 0) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text("FollowSpot Filter Setup")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Verwalten Sie Filter für mehrere FollowSpots")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    
                    Divider()
                    
                    // FollowSpot List
                    if project.followSpots.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "light.beacon.max")
                                .font(.system(size: 60))
                                .foregroundColor(.secondary)
                            
                            Text("Keine FollowSpots konfiguriert")
                                .font(.title2)
                                .foregroundColor(.secondary)
                            
                            Text("Fügen Sie FollowSpots hinzu, um Filter zu konfigurieren")
                                .font(.body)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                            
                            Button("Ersten FollowSpot hinzufügen") {
                                showAddFollowSpotDialog = true
                            }
                            .buttonStyle(.borderedProminent)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .padding(40)
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 8) {
                                ForEach(project.followSpots, id: \.id) { followSpot in
                                    FollowSpotRow(
                                        followSpot: followSpot,
                                        isSelected: selectedFollowSpot?.id == followSpot.id,
                                        onSelect: {
                                            selectedFollowSpot = followSpot
                                        },
                                        onDelete: {
                                            followSpotToDelete = followSpot
                                            showDeleteConfirmation = true
                                        }
                                    )
                                }
                            }
                            .padding()
                        }
                    }
                    
                    Divider()
                    
                    // Footer with controls
                    HStack {
                        Button("FollowSpot hinzufügen") {
                            showAddFollowSpotDialog = true
                        }
                        .buttonStyle(.bordered)
                        
                        Spacer()
                        
                        Button("Alle als PDF exportieren") {
                            exportAllFollowSpotsPDF()
                        }
                        .disabled(project.followSpots.isEmpty)
                        .buttonStyle(.bordered)
                    }
                    .padding()
                }
                .frame(width: 350)
                
                Divider()
                
                // Right Side - Filter Configuration
                if let followSpot = selectedFollowSpot {
                    FollowSpotDetailView(
                        followSpot: followSpot,
                        modelContext: modelContext
                    )
                } else {
                    VStack(spacing: 20) {
                        Image(systemName: "light.beacon.max")
                            .font(.system(size: 80))
                            .foregroundColor(.secondary)
                        
                        Text("Wählen Sie einen FollowSpot")
                            .font(.title2)
                            .foregroundColor(.secondary)
                        
                        Text("Wählen Sie links einen FollowSpot aus, um Filter zu konfigurieren")
                            .font(.body)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(40)
                }
            }
            .navigationTitle("FollowSpot Filter Setup")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1600, minHeight: 800)
            .sheet(isPresented: $showAddFollowSpotDialog) {
                AddFollowSpotDialog(
                    newFollowSpotName: $newFollowSpotName,
                    onAdd: addFollowSpot,
                    onCancel: { showAddFollowSpotDialog = false }
                )
            }
            .alert("FollowSpot löschen", isPresented: $showDeleteConfirmation) {
                Button("Löschen", role: .destructive) {
                    if let followSpot = followSpotToDelete {
                        deleteFollowSpot(followSpot)
                    }
                }
                Button("Abbrechen", role: .cancel) {
                    followSpotToDelete = nil
                }
            } message: {
                Text("Möchten Sie diesen FollowSpot wirklich löschen?")
            }
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
        }
    }
    
    private func addFollowSpot() {
        guard !newFollowSpotName.isEmpty else { return }
        
        let followSpot = FollowSpot(name: newFollowSpotName)
        project.followSpots.append(followSpot)
        modelContext.insert(followSpot)
        
        do {
            try modelContext.save()
            selectedFollowSpot = followSpot
            newFollowSpotName = ""
            showAddFollowSpotDialog = false
        } catch {
            print("Failed to save new FollowSpot: \(error)")
        }
    }
    
    private func deleteFollowSpot(_ followSpot: FollowSpot) {
        if let index = project.followSpots.firstIndex(of: followSpot) {
            project.followSpots.remove(at: index)
            modelContext.delete(followSpot)
            
            if selectedFollowSpot?.id == followSpot.id {
                selectedFollowSpot = project.followSpots.first
            }
            
            do {
                try modelContext.save()
            } catch {
                print("Failed to delete FollowSpot: \(error)")
            }
        }
        followSpotToDelete = nil
    }
    
    private func exportAllFollowSpotsPDF() {
        guard !project.followSpots.isEmpty else { return }
        
        // Collect all FollowSpot data
        let followSpotsData = project.followSpots.map { followSpot in
            FollowSpotData(
                name: followSpot.name,
                filterSlots: followSpot.loadFilterSlots()
            )
        }
        
        var logoData: Data? = nil
        switch logoOption {
        case .none:
            logoData = nil
        case .upload:
            logoData = uploadedLogoData
        case .habegger:
            logoData = createHabeggerLogoData()
        }
        
        let pdfCreator = FollowSpotFilterPDFCreator()
        let pdfData = pdfCreator.createMultipleFollowSpotsPDF(
            followSpotsData: followSpotsData,
            logoData: logoData
        )
        
        let filename = "FollowSpot_Filter_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Alle FollowSpot Filter-Etiketten wurden erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                uploadedLogoData = try Data(contentsOf: url)
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func createHabeggerLogoData() -> Data? {
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        guard let tiffData = image.tiffRepresentation,
              let bitmapRep = NSBitmapImageRep(data: tiffData),
              let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
            return nil
        }
        
        return pngData
    }
}

struct FollowSpotRow: View {
    let followSpot: FollowSpot
    let isSelected: Bool
    let onSelect: () -> Void
    let onDelete: () -> Void
    
    private var filterCount: Int {
        followSpot.loadFilterSlots().count
    }
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(followSpot.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text("\(filterCount) von 6 Filterslots belegt")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button("Löschen") {
                onDelete()
            }
            .buttonStyle(.bordered)
            .controlSize(.small)
            .foregroundColor(.red)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(isSelected ? Color.blue.opacity(0.1) : Color.clear)
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(isSelected ? Color.blue : Color.gray.opacity(0.3), lineWidth: 1)
        )
        .contentShape(Rectangle())
        .onTapGesture {
            onSelect()
        }
    }
}

struct FollowSpotDetailView: View {
    @Bindable var followSpot: FollowSpot
    let modelContext: ModelContext
    
    @State private var selectedManufacturer: ColorFilter.FilterManufacturer = .lee
    @State private var searchText = ""
    @State private var filterSlots: [Int: ColorFilter] = [:]
    @State private var isEditing = false
    @State private var editedName = ""
    
    private var filteredFilters: [ColorFilter] {
        let filters = selectedManufacturer == .lee ? ColorFilter.leeFilters : ColorFilter.roscoFilters
        
        if searchText.isEmpty {
            return filters
        } else {
            return filters.filter { filter in
                filter.number.localizedCaseInsensitiveContains(searchText) ||
                filter.name.localizedCaseInsensitiveContains(searchText) ||
                filter.description.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header with editable name
            HStack {
                if isEditing {
                    TextField("FollowSpot Name", text: $editedName)
                        .textFieldStyle(.roundedBorder)
                        .onSubmit {
                            saveFollowSpotName()
                        }
                    
                    Button("Speichern") {
                        saveFollowSpotName()
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                    
                    Button("Abbrechen") {
                        cancelEditing()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                } else {
                    Text(followSpot.name)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Spacer()
                    
                    Button("Umbenennen") {
                        startEditing()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
            }
            .padding()
            
            Divider()
            
            HStack(spacing: 0) {
                // Left - Filter Catalog
                VStack(spacing: 15) {
                    // Manufacturer Selection
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Filter-Hersteller:")
                            .font(.headline)
                            .fontWeight(.medium)
                        
                        Picker("Hersteller", selection: $selectedManufacturer) {
                            ForEach(ColorFilter.FilterManufacturer.allCases, id: \.self) { manufacturer in
                                Text(manufacturer.rawValue).tag(manufacturer)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                    
                    // Search
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Filter suchen:")
                            .font(.headline)
                            .fontWeight(.medium)
                        
                        TextField("Nach Nummer, Name oder Beschreibung suchen", text: $searchText)
                            .textFieldStyle(.roundedBorder)
                    }
                    
                    // Filter List
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(filteredFilters, id: \.id) { filter in
                                FilterRow(
                                    filter: filter,
                                    isSelected: filterSlots.values.contains { $0.id == filter.id },
                                    onTap: {
                                        selectSlotForFilter(filter)
                                    }
                                )
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                
                Divider()
                
                // Right - Slot Management
                VStack(spacing: 15) {
                    Text("Filter Slots:")
                        .font(.headline)
                        .fontWeight(.medium)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    VStack(spacing: 10) {
                        ForEach(1...6, id: \.self) { slotNumber in
                            FilterSlotRow(
                                slotNumber: slotNumber,
                                assignedFilter: filterSlots[slotNumber],
                                onRemove: {
                                    filterSlots.removeValue(forKey: slotNumber)
                                    saveFilterSlots()
                                }
                            )
                        }
                    }
                    
                    Spacer()
                }
                .frame(width: 400)
                .padding()
            }
        }
        .onAppear {
            loadFilterSlots()
        }
        .onChange(of: followSpot.id) { _, _ in
            loadFilterSlots()
        }
    }
    
    private func loadFilterSlots() {
        filterSlots = followSpot.loadFilterSlots()
    }
    
    private func saveFilterSlots() {
        followSpot.saveFilterSlots(filterSlots)
        do {
            try modelContext.save()
        } catch {
            print("Failed to save filter slots: \(error)")
        }
    }
    
    private func selectSlotForFilter(_ filter: ColorFilter) {
        // Find empty slot
        for slot in 1...6 {
            if filterSlots[slot] == nil {
                filterSlots[slot] = filter
                saveFilterSlots()
                return
            }
        }
        
        // If all slots are full, show alert
        let alert = NSAlert()
        alert.messageText = "Alle Slots belegt"
        alert.informativeText = "Bitte entfernen Sie zuerst einen Filter aus einem Slot."
        alert.alertStyle = .informational
        alert.runModal()
    }
    
    private func startEditing() {
        editedName = followSpot.name
        isEditing = true
    }
    
    private func saveFollowSpotName() {
        guard !editedName.isEmpty else { return }
        
        followSpot.name = editedName
        do {
            try modelContext.save()
            isEditing = false
        } catch {
            print("Failed to save FollowSpot name: \(error)")
        }
    }
    
    private func cancelEditing() {
        editedName = ""
        isEditing = false
    }
}

struct AddFollowSpotDialog: View {
    @Binding var newFollowSpotName: String
    let onAdd: () -> Void
    let onCancel: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Neuen FollowSpot hinzufügen")
                .font(.headline)
            
            TextField("FollowSpot Name", text: $newFollowSpotName)
                .textFieldStyle(.roundedBorder)
            
            HStack {
                Button("Abbrechen") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                
                Button("Hinzufügen") {
                    onAdd()
                }
                .buttonStyle(.borderedProminent)
                .disabled(newFollowSpotName.isEmpty)
            }
        }
        .padding()
        .frame(width: 300)
    }
}

// MARK: - Components
struct FilterRow: View {
    let filter: ColorFilter
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(filter.number)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text(filter.name)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                }
                
                Text(filter.description)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }
            
            Spacer()
            
            if isSelected {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(.green)
            } else {
                Button("Hinzufügen") {
                    onTap()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(isSelected ? Color.green.opacity(0.1) : Color.clear)
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(isSelected ? Color.green : Color.gray.opacity(0.3), lineWidth: 1)
        )
        .contentShape(Rectangle())
        .onTapGesture {
            if !isSelected {
                onTap()
            }
        }
    }
}

struct FilterSlotRow: View {
    let slotNumber: Int
    let assignedFilter: ColorFilter?
    let onRemove: () -> Void
    
    var body: some View {
        HStack {
            Text("Slot \(slotNumber):")
                .font(.subheadline)
                .fontWeight(.medium)
                .frame(width: 60, alignment: .leading)
            
            if let filter = assignedFilter {
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(filter.number) \(filter.name)")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    Text(filter.manufacturer.rawValue)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Button("Entfernen") {
                    onRemove()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .foregroundColor(.red)
            } else {
                Text("Leer")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .italic()
                
                Spacer()
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(assignedFilter != nil ? Color.blue.opacity(0.05) : Color.gray.opacity(0.05))
        .cornerRadius(6)
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(assignedFilter != nil ? Color.blue.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 1)
        )
    }
}

// MARK: - Data Models
struct ColorFilter: Identifiable, Equatable {
    let id = UUID()
    let number: String
    let name: String
    let description: String
    let manufacturer: FilterManufacturer
    
    enum FilterManufacturer: String, CaseIterable {
        case lee = "Lee Filters"
        case rosco = "Rosco"
    }
    
    static func == (lhs: ColorFilter, rhs: ColorFilter) -> Bool {
        return lhs.id == rhs.id
    }
    
    static let leeFilters: [ColorFilter] = [
        ColorFilter(number: "002", name: "Rose Pink", description: "Strong pink wash, good for cycloramas.", manufacturer: .lee),
        ColorFilter(number: "003", name: "Lavender Tint", description: "Subtle cool wash for stage and studio lighting.", manufacturer: .lee),
        ColorFilter(number: "004", name: "Medium Bastard Amber", description: "Naturally enhances skin tones.", manufacturer: .lee),
        ColorFilter(number: "007", name: "Pale Yellow", description: "Sunlight.", manufacturer: .lee),
        ColorFilter(number: "008", name: "Dark Salmon", description: "Enhances dark skin tones, sunsets, ballroom sets.", manufacturer: .lee),
        ColorFilter(number: "009", name: "Pale Amber Gold", description: "Perfect warm front light for any skin tone.", manufacturer: .lee),
        ColorFilter(number: "010", name: "Medium Yellow", description: "A pure bright yellow. Great for special effects and accents.", manufacturer: .lee),
        ColorFilter(number: "013", name: "Straw Tint", description: "Warmer than other straw colours. A good sunlight effect.", manufacturer: .lee),
        ColorFilter(number: "015", name: "Deep Straw", description: "A warm amber light. Good for effects such as candlelight and fire.", manufacturer: .lee),
        ColorFilter(number: "017", name: "Surprise Peach", description: "Good for skin tones and creating a moody lighting effect.", manufacturer: .lee),
        ColorFilter(number: "019", name: "Fire", description: "A strong red/amber. Great for fire effects.", manufacturer: .lee),
        ColorFilter(number: "020", name: "Medium Amber", description: "Good for afternoon sunlight and candlelight.", manufacturer: .lee),
        ColorFilter(number: "021", name: "Gold Amber", description: "Great for sunsets, cyclorama lighting and fire effects.", manufacturer: .lee),
        ColorFilter(number: "022", name: "Dark Amber", description: "A good backlight.", manufacturer: .lee),
        ColorFilter(number: "024", name: "Scarlet", description: "Great for pantomimes, ballroom sets and fire effects.", manufacturer: .lee),
        ColorFilter(number: "025", name: "Sunset Red", description: "A good warm stage wash, TV studio wash or sunset effect.", manufacturer: .lee),
        ColorFilter(number: "026", name: "Bright Red", description: "A vibrant red, good for cyclorama lighting.", manufacturer: .lee),
        ColorFilter(number: "027", name: "Medium Red", description: "Good for cyclorama lighting, side lighting and footlights.", manufacturer: .lee),
        ColorFilter(number: "035", name: "Light Pink", description: "A warm wash good for musical reviews.", manufacturer: .lee),
        ColorFilter(number: "036", name: "Medium Pink", description: "Good for general washes and side lighting.", manufacturer: .lee),
        ColorFilter(number: "046", name: "Dark Magenta", description: "A very strong pink, good for backlighting.", manufacturer: .lee),
        ColorFilter(number: "048", name: "Rose Purple", description: "Good for emulating evening. Great backlight.", manufacturer: .lee),
        ColorFilter(number: "049", name: "Medium Purple", description: "A strong cheerful glow, good for cycloramas.", manufacturer: .lee),
        ColorFilter(number: "052", name: "Light Lavender", description: "Good for general areas and side lights.", manufacturer: .lee),
        ColorFilter(number: "053", name: "Paler Lavender", description: "A subtle cool wash.", manufacturer: .lee),
        ColorFilter(number: "058", name: "Lavender", description: "An excellent backlight that creates a new dimension.", manufacturer: .lee),
        ColorFilter(number: "061", name: "Mist Blue", description: "A cool wash good for night scenes.", manufacturer: .lee),
        ColorFilter(number: "063", name: "Pale Blue", description: "Cool front light wash, good for creating an overcast look.", manufacturer: .lee),
        ColorFilter(number: "068", name: "Sky Blue", description: "Good for morning skin tones and night skies.", manufacturer: .lee),
        ColorFilter(number: "071", name: "Tokyo Blue", description: "A deep blue, used for midnight scenes.", manufacturer: .lee),
        ColorFilter(number: "075", name: "Evening Blue", description: "Good for night scenes and romantic moonlight.", manufacturer: .lee),
        ColorFilter(number: "079", name: "Just Blue", description: "A good colour mixing blue. Great for cyclorama lighting.", manufacturer: .lee),
        ColorFilter(number: "085", name: "Deeper Blue", description: "A deep warm blue. Good for back and side lighting.", manufacturer: .lee),
        ColorFilter(number: "088", name: "Lime Green", description: "Use with gobos for leafy glades.", manufacturer: .lee),
        ColorFilter(number: "089", name: "Moss Green", description: "Good for cycloramas and creates a great mood effect.", manufacturer: .lee),
        ColorFilter(number: "090", name: "Dark Yellow Green", description: "Highlighting for forest effects.", manufacturer: .lee),
        ColorFilter(number: "100", name: "Spring Yellow", description: "A sunlight wash – use with gobos, disco and dark skin tones.", manufacturer: .lee),
        ColorFilter(number: "101", name: "Yellow", description: "Sunlight and window effect – pleasant in acting areas.", manufacturer: .lee),
        ColorFilter(number: "102", name: "Light Amber", description: "A warm yellow colour. Great for candlelight.", manufacturer: .lee),
        ColorFilter(number: "103", name: "Straw", description: "Pale sunlight through a window and warm winter effect.", manufacturer: .lee),
        ColorFilter(number: "104", name: "Deep Amber", description: "Good for sunlight effect, accents and side light.", manufacturer: .lee),
        ColorFilter(number: "105", name: "Orange", description: "Good for light entertainment. Creates fire effect.", manufacturer: .lee),
        ColorFilter(number: "106", name: "Primary Red", description: "Strong red effect. Good with cyclorama lighting.", manufacturer: .lee),
        ColorFilter(number: "107", name: "Light Rose", description: "Good for general washes and followspots.", manufacturer: .lee),
        ColorFilter(number: "108", name: "English Rose", description: "Warm tint wash. Dark flesh tones and softer skin tones.", manufacturer: .lee),
        ColorFilter(number: "109", name: "Light Salmon", description: "Interesting backlight.", manufacturer: .lee),
        ColorFilter(number: "110", name: "Middle Rose", description: "Pleasing effects for theatrical lighting.", manufacturer: .lee),
        ColorFilter(number: "111", name: "Dark Pink", description: "Good for cyclorama lighting.", manufacturer: .lee),
        ColorFilter(number: "113", name: "Magenta", description: "Very strong – used carefully for small areas on set.", manufacturer: .lee),
        ColorFilter(number: "115", name: "Peacock Blue", description: "A pleasing effect on set. Good for cyclorama.", manufacturer: .lee),
        ColorFilter(number: "116", name: "Medium Blue-Green", description: "A pleasing effect for theatrical lighting.", manufacturer: .lee),
        ColorFilter(number: "117", name: "Steel Blue", description: "Good for cool washes. Great for emulating icy weather.", manufacturer: .lee),
        ColorFilter(number: "118", name: "Light Blue", description: "A strong night effect.", manufacturer: .lee),
        ColorFilter(number: "119", name: "Dark Blue", description: "Good for mood effects created by backlighting.", manufacturer: .lee),
        ColorFilter(number: "120", name: "Deep Blue", description: "A pleasing effect for theatrical lighting.", manufacturer: .lee),
        ColorFilter(number: "121", name: "LEE Green", description: "Good for dense foliage, tropical jungle effect.", manufacturer: .lee),
        ColorFilter(number: "122", name: "Fern Green", description: "Good for cycloramas and creates a great mood effect.", manufacturer: .lee),
        ColorFilter(number: "124", name: "Dark Green", description: "Good for cycloramas and backlighting.", manufacturer: .lee),
        ColorFilter(number: "126", name: "Mauve", description: "Good for backlighting. Dark magenta/purple adds drama.", manufacturer: .lee),
        ColorFilter(number: "127", name: "Smokey Pink", description: "Good for cycloramas, set lighting and discos.", manufacturer: .lee),
        ColorFilter(number: "128", name: "Bright Pink", description: "Created for backlighting and side lighting.", manufacturer: .lee),
        ColorFilter(number: "130", name: "Clear", description: "Used in animation and projection work.", manufacturer: .lee),
        ColorFilter(number: "131", name: "Marine Blue", description: "Good for romantic moonlight. Often used in ballet.", manufacturer: .lee),
        ColorFilter(number: "132", name: "Medium Blue", description: "Deep moonlight. Great for colour mixing.", manufacturer: .lee),
        ColorFilter(number: "134", name: "Golden Amber", description: "Great for emulating a sunset.", manufacturer: .lee),
        ColorFilter(number: "135", name: "Deep Golden Amber", description: "A great fire effect.", manufacturer: .lee),
        ColorFilter(number: "136", name: "Pale Lavender", description: "Great for pantomimes and ballroom sets.", manufacturer: .lee),
        ColorFilter(number: "137", name: "Special Lavender", description: "Good for moonlight and musical/romantic scenes.", manufacturer: .lee),
        ColorFilter(number: "138", name: "Pale Green", description: "Good with gobos for wooded scenes.", manufacturer: .lee),
        ColorFilter(number: "139", name: "Primary Green", description: "Good for set lighting and cyclorama lighting.", manufacturer: .lee),
        ColorFilter(number: "140", name: "Summer Blue", description: "Good for light midday sky. Light blue tinted wash.", manufacturer: .lee),
        ColorFilter(number: "141", name: "Bright Blue", description: "Very dramatic when used as moonlight.", manufacturer: .lee),
        ColorFilter(number: "142", name: "Pale Violet", description: "Great Moonlight effect. Good for cyclorama lighting.", manufacturer: .lee),
        ColorFilter(number: "143", name: "Pale Navy Blue", description: "Great moonlight/night effect.", manufacturer: .lee),
        ColorFilter(number: "144", name: "No Colour Blue", description: "A clean blue with hints of green. Good for moonlight.", manufacturer: .lee),
        ColorFilter(number: "147", name: "Apricot", description: "Good for sunrise, sunset and lamplight effects.", manufacturer: .lee),
        ColorFilter(number: "148", name: "Bright Rose", description: "Great for fire effects and musicals.", manufacturer: .lee)
    ]
    
    static let roscoFilters: [ColorFilter] = [
        // R01-R10 - Amber/Yellow Serie
        ColorFilter(number: "R01", name: "Light Bastard Amber", description: "Warm amber hue that enhances skin tones and mimics natural sunlight.", manufacturer: .rosco),
        ColorFilter(number: "R02", name: "Bastard Amber", description: "Deeper amber tone, suitable for creating mood lighting or simulating sunset effects.", manufacturer: .rosco),
        ColorFilter(number: "R03", name: "Dark Bastard Amber", description: "Even darker amber shade, used for intense warm effects or subtle tinting.", manufacturer: .rosco),
        ColorFilter(number: "R04", name: "Medium Bastard Amber", description: "Popular warm color for enhancing skin tones.", manufacturer: .rosco),
        ColorFilter(number: "R304", name: "Pale Apricot", description: "Light, soft apricot hue suitable for subtle color effects.", manufacturer: .rosco),
        ColorFilter(number: "R05", name: "Rose Tint", description: "Very light pink suitable for subtle warming effects.", manufacturer: .rosco),
        ColorFilter(number: "R305", name: "Rose Gold", description: "Warm golden pink for flattering skin tone enhancement.", manufacturer: .rosco),
        ColorFilter(number: "R06", name: "No Color Straw", description: "Subtle warm tint without noticeable color shift.", manufacturer: .rosco),
        ColorFilter(number: "R07", name: "Pale Yellow", description: "Light yellow for subtle sunlight effects.", manufacturer: .rosco),
        ColorFilter(number: "R08", name: "Pale Gold", description: "Warm gold tint for flattering lighting.", manufacturer: .rosco),
        ColorFilter(number: "R09", name: "Pale Amber Gold", description: "Warm amber for front lighting and skin enhancement.", manufacturer: .rosco),
        ColorFilter(number: "R10", name: "Medium Yellow", description: "Medium intensity yellow for sunlight effects.", manufacturer: .rosco),
        
        // R11-R25 - Straw/Amber Serie
        ColorFilter(number: "R11", name: "Light Straw", description: "Light straw color for warm general lighting.", manufacturer: .rosco),
        ColorFilter(number: "R12", name: "Straw", description: "Classic straw color for warm stage lighting.", manufacturer: .rosco),
        ColorFilter(number: "R312", name: "Canary", description: "Bright canary yellow for special effects.", manufacturer: .rosco),
        ColorFilter(number: "R13", name: "Straw Tint", description: "Very light straw tint for subtle warming.", manufacturer: .rosco),
        ColorFilter(number: "R14", name: "Medium Straw", description: "Medium straw for general warm lighting.", manufacturer: .rosco),
        ColorFilter(number: "R15", name: "Deep Straw", description: "Deep straw for strong warm effects.", manufacturer: .rosco),
        ColorFilter(number: "R16", name: "Light Amber", description: "Light amber for warm general lighting.", manufacturer: .rosco),
        ColorFilter(number: "R316", name: "Gallo Gold", description: "Rich gold color for dramatic warm effects.", manufacturer: .rosco),
        ColorFilter(number: "R17", name: "Light Flame", description: "Light orange-red for flame effects.", manufacturer: .rosco),
        ColorFilter(number: "R317", name: "Apricot", description: "Soft apricot color for warm skin tones.", manufacturer: .rosco),
        ColorFilter(number: "R18", name: "Flame", description: "Orange-red for fire and flame effects.", manufacturer: .rosco),
        ColorFilter(number: "R19", name: "Fire", description: "Deep red-orange for dramatic fire effects.", manufacturer: .rosco),
        ColorFilter(number: "R20", name: "Medium Amber", description: "Medium amber for warm side lighting.", manufacturer: .rosco),
        ColorFilter(number: "R21", name: "Golden Amber", description: "Rich gold for sunset and fire effects.", manufacturer: .rosco),
        ColorFilter(number: "R22", name: "Deep Amber", description: "Deep amber for strong warm backlighting.", manufacturer: .rosco),
        ColorFilter(number: "R23", name: "Orange", description: "Pure orange for special effects.", manufacturer: .rosco),
        ColorFilter(number: "R24", name: "Scarlet", description: "Bright red for strong effects.", manufacturer: .rosco),
        ColorFilter(number: "R25", name: "Orange Red", description: "Orange-red for sunset and fire effects.", manufacturer: .rosco),
        
        // R26-R40 - Red/Pink Serie
        ColorFilter(number: "R26", name: "Light Red", description: "Light red for general red effects.", manufacturer: .rosco),
        ColorFilter(number: "R27", name: "Medium Red", description: "Classic red for general stage use.", manufacturer: .rosco),
        ColorFilter(number: "R30", name: "Light Salmon Pink", description: "Light salmon for subtle pink effects.", manufacturer: .rosco),
        ColorFilter(number: "R31", name: "Salmon Pink", description: "Medium salmon pink for warm effects.", manufacturer: .rosco),
        ColorFilter(number: "R32", name: "Medium Salmon Pink", description: "Deeper salmon for stronger pink effects.", manufacturer: .rosco),
        ColorFilter(number: "R33", name: "No Color Pink", description: "Very subtle pink tint.", manufacturer: .rosco),
        ColorFilter(number: "R34", name: "Flesh Pink", description: "Natural pink for skin tone enhancement.", manufacturer: .rosco),
        ColorFilter(number: "R35", name: "Light Pink", description: "Light pink for musical theater.", manufacturer: .rosco),
        ColorFilter(number: "R36", name: "Medium Pink", description: "Medium pink for general stage use.", manufacturer: .rosco),
        ColorFilter(number: "R37", name: "Pale Rose Pink", description: "Very light rose for subtle effects.", manufacturer: .rosco),
        ColorFilter(number: "R38", name: "Light Rose", description: "Light rose for romantic lighting.", manufacturer: .rosco),
        ColorFilter(number: "R39", name: "Skelton Exotic Sangria", description: "Deep red-purple for dramatic effects.", manufacturer: .rosco),
        ColorFilter(number: "R40", name: "Light Salmon", description: "Light salmon for warm skin tones.", manufacturer: .rosco),
        
        // R41-R50 - Deep Pink/Purple Serie
        ColorFilter(number: "R41", name: "Salmon", description: "Medium salmon for warm general lighting.", manufacturer: .rosco),
        ColorFilter(number: "R42", name: "Deep Salmon", description: "Deep salmon for strong warm effects.", manufacturer: .rosco),
        ColorFilter(number: "R43", name: "Deep Pink", description: "Strong pink for dramatic effects.", manufacturer: .rosco),
        ColorFilter(number: "R44", name: "Middle Rose", description: "Medium rose for general pink effects.", manufacturer: .rosco),
        ColorFilter(number: "R45", name: "Rose", description: "Classic rose color for romantic scenes.", manufacturer: .rosco),
        ColorFilter(number: "R46", name: "Magenta", description: "Pure magenta for strong color effects.", manufacturer: .rosco),
        ColorFilter(number: "R47", name: "Light Rose Purple", description: "Light purple-pink for subtle effects.", manufacturer: .rosco),
        ColorFilter(number: "R48", name: "Rose Purple", description: "Medium purple-pink for mood lighting.", manufacturer: .rosco),
        ColorFilter(number: "R49", name: "Medium Purple", description: "Medium purple for dramatic effects.", manufacturer: .rosco),
        ColorFilter(number: "R50", name: "Mauve", description: "Soft mauve for subtle purple effects.", manufacturer: .rosco),
        
        // R51-R65 - Lavender/Blue Serie
        ColorFilter(number: "R51", name: "Surprise Pink", description: "Bright pink for special effects.", manufacturer: .rosco),
        ColorFilter(number: "R52", name: "Light Lavender", description: "Light purple for general use.", manufacturer: .rosco),
        ColorFilter(number: "R53", name: "Pale Lavender", description: "Very light lavender for subtle effects.", manufacturer: .rosco),
        ColorFilter(number: "R54", name: "Special Lavender", description: "Medium lavender for moonlight effects.", manufacturer: .rosco),
        ColorFilter(number: "R55", name: "Lilac", description: "Soft lilac for romantic lighting.", manufacturer: .rosco),
        ColorFilter(number: "R56", name: "Gypsy Lavender", description: "Deep lavender for dramatic effects.", manufacturer: .rosco),
        ColorFilter(number: "R57", name: "Lavender", description: "Classic lavender for backlighting.", manufacturer: .rosco),
        ColorFilter(number: "R58", name: "Deep Lavender", description: "Strong lavender for dramatic lighting.", manufacturer: .rosco),
        ColorFilter(number: "R59", name: "Indigo", description: "Deep blue-purple for night effects.", manufacturer: .rosco),
        ColorFilter(number: "R60", name: "No Color Blue", description: "Very subtle blue tint.", manufacturer: .rosco),
        ColorFilter(number: "R61", name: "Mist Blue", description: "Light blue for cool effects.", manufacturer: .rosco),
        ColorFilter(number: "R62", name: "Booster Blue", description: "Medium blue for color correction.", manufacturer: .rosco),
        ColorFilter(number: "R63", name: "Pale Blue", description: "Light blue for cool front lighting.", manufacturer: .rosco),
        ColorFilter(number: "R64", name: "Light Steel Blue", description: "Light steel blue for cool effects.", manufacturer: .rosco),
        ColorFilter(number: "R65", name: "Daylight Blue", description: "Blue for daylight color correction.", manufacturer: .rosco),
        
        // R66-R80 - Blue Serie
        ColorFilter(number: "R66", name: "Cool Blue", description: "Medium blue for cooling effects.", manufacturer: .rosco),
        ColorFilter(number: "R67", name: "Light Sky Blue", description: "Light sky blue for natural effects.", manufacturer: .rosco),
        ColorFilter(number: "R68", name: "Sky Blue", description: "Classic sky blue for cycloramas.", manufacturer: .rosco),
        ColorFilter(number: "R69", name: "Brilliant Blue", description: "Bright blue for strong effects.", manufacturer: .rosco),
        ColorFilter(number: "R70", name: "Nile Blue", description: "Medium blue-green for water effects.", manufacturer: .rosco),
        ColorFilter(number: "R71", name: "Sea Blue", description: "Blue-green for underwater effects.", manufacturer: .rosco),
        ColorFilter(number: "R72", name: "Azure Blue", description: "Light azure for sky effects.", manufacturer: .rosco),
        ColorFilter(number: "R73", name: "Peacock Blue", description: "Blue-green for special effects.", manufacturer: .rosco),
        ColorFilter(number: "R74", name: "Night Blue", description: "Dark blue for night scenes.", manufacturer: .rosco),
        ColorFilter(number: "R76", name: "Light Green Blue", description: "Light blue-green for water effects.", manufacturer: .rosco),
        ColorFilter(number: "R77", name: "Green Blue", description: "Medium blue-green for aquatic scenes.", manufacturer: .rosco),
        ColorFilter(number: "R78", name: "Trudy Blue", description: "Deep blue for dramatic night effects.", manufacturer: .rosco),
        ColorFilter(number: "R79", name: "Bright Blue", description: "Vibrant blue for strong effects.", manufacturer: .rosco),
        ColorFilter(number: "R80", name: "Primary Blue", description: "Saturated blue for strong effects.", manufacturer: .rosco),
        
        // R81-R95 - Deep Blue/Green Serie
        ColorFilter(number: "R81", name: "Urban Blue", description: "Cool blue for modern lighting.", manufacturer: .rosco),
        ColorFilter(number: "R82", name: "Surprise Blue", description: "Bright blue for special effects.", manufacturer: .rosco),
        ColorFilter(number: "R83", name: "Medium Blue", description: "Classic medium blue for general use.", manufacturer: .rosco),
        ColorFilter(number: "R84", name: "Zephyr Blue", description: "Light blue for subtle cooling.", manufacturer: .rosco),
        ColorFilter(number: "R85", name: "Deep Blue", description: "Deep blue for dramatic night effects.", manufacturer: .rosco),
        ColorFilter(number: "R86", name: "Pea Green", description: "Yellow-green for foliage effects.", manufacturer: .rosco),
        ColorFilter(number: "R87", name: "Pale Yellow Green", description: "Light green for natural effects.", manufacturer: .rosco),
        ColorFilter(number: "R88", name: "Lime Green", description: "Bright lime green for modern effects.", manufacturer: .rosco),
        ColorFilter(number: "R89", name: "Gaslight Green", description: "Warm green for vintage effects.", manufacturer: .rosco),
        ColorFilter(number: "R90", name: "Dark Yellow Green", description: "Deep green for foliage effects.", manufacturer: .rosco),
        ColorFilter(number: "R91", name: "Primary Green", description: "Pure green for strong effects.", manufacturer: .rosco),
        ColorFilter(number: "R92", name: "Turquoise", description: "Blue-green for water and sky effects.", manufacturer: .rosco),
        ColorFilter(number: "R93", name: "Blue Green", description: "Medium blue-green for general use.", manufacturer: .rosco),
        ColorFilter(number: "R94", name: "Kelly Green", description: "Bright green for special effects.", manufacturer: .rosco),
        ColorFilter(number: "R95", name: "Medium Blue Green", description: "Medium blue-green for aquatic effects.", manufacturer: .rosco),
        
        // R96-R99 - Special Colors
        ColorFilter(number: "R96", name: "Lime", description: "Bright lime green for modern effects.", manufacturer: .rosco),
        ColorFilter(number: "R97", name: "Light Grey", description: "Light neutral grey for diffusion.", manufacturer: .rosco),
        ColorFilter(number: "R98", name: "Medium Grey", description: "Medium grey for neutral effects.", manufacturer: .rosco),
        ColorFilter(number: "R99", name: "Chocolate", description: "Rich brown tint for warm natural effects.", manufacturer: .rosco)
    ]
}

struct FollowSpotData {
    let name: String
    let filterSlots: [Int: ColorFilter]
}

// MARK: - PDF Creator
class FollowSpotFilterPDFCreator {
    func createMultipleFollowSpotsPDF(followSpotsData: [FollowSpotData], logoData: Data?) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        // HERMA 4426 Format: 105mm x 70mm, 8 labels per A4 page
        let pageWidth: CGFloat = 595.2   // A4 width in points
        let pageHeight: CGFloat = 841.8  // A4 height in points
        let labelWidth: CGFloat = 297.6  // 105mm in points
        let labelHeight: CGFloat = 198.4 // 70mm in points
        
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        var logoCGImage: CGImage? = nil
        if let logoData = logoData {
            logoCGImage = createCGImageFromData(logoData)
        }
        
        // Calculate how many pages we need
        let labelsPerPage = 8
        let totalPages = Int(ceil(Double(followSpotsData.count) / Double(labelsPerPage)))
        
        for pageIndex in 0..<totalPages {
            pdfContext.beginPDFPage(nil)
            
            let startIndex = pageIndex * labelsPerPage
            let endIndex = min(startIndex + labelsPerPage, followSpotsData.count)
            let pageFollowSpots = Array(followSpotsData[startIndex..<endIndex])
            
            // Calculate label positions for HERMA 4426 (2x4 grid)
            let horizontalSpacing: CGFloat = (pageWidth - 2 * labelWidth) / 3
            let verticalSpacing: CGFloat = (pageHeight - 4 * labelHeight) / 5
            
            // Draw labels for this page
            for (index, followSpotData) in pageFollowSpots.enumerated() {
                let row = index / 2
                let col = index % 2
                
                let x = horizontalSpacing + CGFloat(col) * (labelWidth + horizontalSpacing)
                let y = pageHeight - verticalSpacing - CGFloat(row + 1) * (labelHeight + verticalSpacing)
                
                let labelRect = CGRect(x: x, y: y, width: labelWidth, height: labelHeight)
                
                drawFollowSpotLabel(
                    context: pdfContext,
                    rect: labelRect,
                    followSpotData: followSpotData,
                    logoCGImage: logoCGImage
                )
            }
            
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        
        return pdfData as Data
    }
    
    private func createCGImageFromData(_ data: Data) -> CGImage? {
        guard let dataProvider = CGDataProvider(data: data as CFData),
              let cgImage = CGImage(
                pngDataProviderSource: dataProvider,
                decode: nil,
                shouldInterpolate: true,
                intent: .defaultIntent
              ) else {
            guard let dataProvider = CGDataProvider(data: data as CFData),
                  let cgImage = CGImage(
                    jpegDataProviderSource: dataProvider,
                    decode: nil,
                    shouldInterpolate: true,
                    intent: .defaultIntent
                  ) else {
                return nil
            }
            return cgImage
        }
        return cgImage
    }
    
    private func drawFollowSpotLabel(context: CGContext, rect: CGRect, followSpotData: FollowSpotData, logoCGImage: CGImage?) {
        let margin: CGFloat = 6
        
        // Border
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(rect)
        
        // Logo (top right)
        if let logo = logoCGImage {
            let logoSize: CGFloat = 25
            let logoRect = CGRect(
                x: rect.maxX - logoSize - margin,
                y: rect.maxY - logoSize - margin,
                width: logoSize,
                height: logoSize
            )
            let scaledLogoRect = calculateAspectFitRect(imageSize: CGSize(width: logo.width, height: logo.height), containerRect: logoRect)
            context.draw(logo, in: scaledLogoRect)
        }
        
        // FollowSpot Name (title) - 2 Punkte größer
        let titleRect = CGRect(x: rect.minX + margin, y: rect.maxY - 22 - margin, width: rect.width - 2 * margin - 35, height: 18)
        drawText(context: context, text: followSpotData.name, rect: titleRect, fontSize: 14, bold: true)
        
        // Filter Slots - 20px kleiner
        let slotHeight: CGFloat = 23
        let slotStartY = rect.maxY - 45 - margin
        
        for slot in 1...6 {
            let slotY = slotStartY - CGFloat(slot - 1) * slotHeight
            let slotRect = CGRect(x: rect.minX + margin, y: slotY - slotHeight, width: rect.width - 2 * margin, height: slotHeight)
            
            // Slot background
            if slot % 2 == 0 {
                context.setFillColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
                context.fill(slotRect)
            }
            
            // Slot border
            context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 0.5)
            context.setLineWidth(0.5)
            context.stroke(slotRect)
            
            // Slot content
            if let filter = followSpotData.filterSlots[slot] {
                let slotText = "Slot \(slot): \(filter.number) \(filter.name)"
                drawText(context: context, text: slotText, rect: slotRect.insetBy(dx: 6, dy: 3), fontSize: 10, bold: false)
            } else {
                let slotText = "Slot \(slot): Leer"
                drawText(context: context, text: slotText, rect: slotRect.insetBy(dx: 6, dy: 3), fontSize: 10, bold: false, color: NSColor.gray)
            }
        }
    }
    
    private func calculateAspectFitRect(imageSize: CGSize, containerRect: CGRect) -> CGRect {
        let imageAspectRatio = imageSize.width / imageSize.height
        let containerAspectRatio = containerRect.width / containerRect.height
        
        var resultRect = containerRect
        
        if imageAspectRatio > containerAspectRatio {
            resultRect.size.height = containerRect.width / imageAspectRatio
            resultRect.origin.y = containerRect.origin.y + (containerRect.height - resultRect.height) / 2
        } else {
            resultRect.size.width = containerRect.height * imageAspectRatio
            resultRect.origin.x = containerRect.origin.x + (containerRect.width - resultRect.width) / 2
        }
        
        return resultRect
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool, color: NSColor = NSColor.black) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: color
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: rect.minX + 2, y: rect.minY + 2)
        
        if color == NSColor.gray {
            context.setFillColor(red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0)
        } else {
            context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        }
        
        CTLineDraw(line, context)
        context.restoreGState()
    }
}
