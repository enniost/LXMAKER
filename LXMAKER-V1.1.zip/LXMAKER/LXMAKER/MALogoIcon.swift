import SwiftUI

struct MALogoIcon: View {
    let size: CGFloat
    
    init(size: CGFloat = 20) {
        self.size = size
    }
    
    var body: some View {
        ZStack {
            // Gray background
            RoundedRectangle(cornerRadius: 2)
                .fill(Color.gray.opacity(0.3))
                .frame(width: size * 1.8, height: size)
            
            // Red M A text
            HStack(spacing: size * 0.1) {
                Text("M")
                    .font(.system(size: size * 0.6, weight: .bold, design: .default))
                    .foregroundColor(.red)
                
                Text("A")
                    .font(.system(size: size * 0.6, weight: .bold, design: .default))
                    .foregroundColor(.red)
            }
        }
    }
}

struct MALogoIcon_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            MALogoIcon(size: 16)
            MALogoIcon(size: 20)
            MALogoIcon(size: 24)
        }
        .padding()
    }
}