import SwiftUI
import SwiftData
import AppKit

struct PatchListView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedColumns: [String] = []
    @State private var sortColumn = ""
    @State private var sortOrder: SortOrder = .ascending
    @State private var pageOrientation: PageOrientation = .portrait
    @State private var patchData: [PatchItem] = []
    @State private var logoOption: LogoOption = .none
    @State private var uploadedLogoData: Data? = nil
    @State private var showLogoImporter = false
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    enum SortOrder: String, CaseIterable {
        case ascending = "Aufsteigend"
        case descending = "Absteigend"
    }
    
    enum PageOrientation: String, CaseIterable {
        case portrait = "Hochformat"
        case landscape = "Querformat"
    }
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canGeneratePatch: Bool {
        !selectedColumns.isEmpty && !sortColumn.isEmpty
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Patch Liste")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Erstelle eine sortierte Patch-Liste als PDF")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        if availableColumns.isEmpty {
                            Text("⚠️ Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // Column Selection
                            columnSelectionView
                            
                            // Sort Settings
                            sortSettingsView
                            
                            // Page Orientation
                            pageOrientationView
                            
                            // Logo Settings
                            logoSettingsView
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Info
                        VStack(alignment: .leading, spacing: 15) {
                            Text("Informationen:")
                                .font(.headline)
                                .fontWeight(.medium)
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text("• Wählen Sie die gewünschten Spalten aus")
                                Text("• Bestimmen Sie die Sortierreihenfolge")
                                Text("• Wählen Sie die Seitenausrichtung")
                                Text("• Optional: Logo hinzufügen")
                                Text("• Klicken Sie auf 'PDF erstellen'")
                            }
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            
                            Spacer()
                        }
                        .padding(15)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(10)
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Action Button
                    Button("PDF erstellen") {
                        generatePatchData()
                        exportPatchPDF()
                    }
                    .disabled(!canGeneratePatch)
                    .buttonStyle(.bordered)
                    .controlSize(.large)
                    .padding(.bottom, 20)
                }
                .padding(20)
            }
            .navigationTitle("Patch Liste")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        saveSettings()
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1200, minHeight: 800)
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
            .onAppear {
                loadSettings()
            }
        }
    }
    
    private var columnSelectionView: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Spalten auswählen:")
                .font(.headline)
                .fontWeight(.medium)
            
            HStack(alignment: .top, spacing: 30) {
                // Linke Seite - Verfügbare Spalten
                VStack(alignment: .leading, spacing: 15) {
                    Text("Verfügbare Spalten:")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    ScrollView {
                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(availableColumns, id: \.self) { column in
                                HStack(spacing: 12) {
                                    Button(action: {
                                        if selectedColumns.contains(column) {
                                            selectedColumns.removeAll { $0 == column }
                                        } else {
                                            selectedColumns.append(column)
                                        }
                                    }) {
                                        Image(systemName: selectedColumns.contains(column) ? "checkmark.square.fill" : "square")
                                            .font(.title3)
                                            .foregroundColor(selectedColumns.contains(column) ? .blue : .gray)
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                    
                                    Text(column)
                                        .font(.body)
                                        .foregroundColor(.primary)
                                    
                                    Spacer()
                                }
                                .padding(.horizontal, 8)
                                .padding(.vertical, 6)
                                .background(
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(selectedColumns.contains(column) ? Color.blue.opacity(0.1) : Color.clear)
                                )
                                .onTapGesture {
                                    if selectedColumns.contains(column) {
                                        selectedColumns.removeAll { $0 == column }
                                    } else {
                                        selectedColumns.append(column)
                                    }
                                }
                            }
                        }
                    }
                    .frame(maxHeight: 300)
                    
                    // Action Buttons
                    HStack(spacing: 8) {
                        Button("Alle auswählen") {
                            selectedColumns = availableColumns
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        
                        Button("Alle abwählen") {
                            selectedColumns.removeAll()
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    }
                }
                .frame(maxWidth: .infinity)
                
                // Rechte Seite - Ausgewählte Spalten mit Drag & Drop
                VStack(alignment: .leading, spacing: 15) {
                    Text("Ausgewählte Spalten (\(selectedColumns.count)) - Drag & Drop zum Sortieren:")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    if selectedColumns.isEmpty {
                        Text("Keine Spalten ausgewählt")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.vertical, 20)
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 4) {
                                ForEach(Array(selectedColumns.enumerated()), id: \.offset) { index, column in
                                    DraggableColumnRow(
                                        column: column,
                                        index: index,
                                        selectedColumns: $selectedColumns
                                    )
                                }
                            }
                        }
                        .frame(maxHeight: 300)
                        
                        // Reihenfolge-Buttons
                        HStack(spacing: 8) {
                            Button("Alphabetisch") {
                                selectedColumns.sort { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
                            }
                            .buttonStyle(.bordered)
                            .controlSize(.small)
                            
                            Button("Umkehren") {
                                selectedColumns.reverse()
                            }
                            .buttonStyle(.bordered)
                            .controlSize(.small)
                        }
                    }
                }
                .frame(maxWidth: .infinity)
            }
        }
        .padding(20)
        .background(Color.blue.opacity(0.05))
        .cornerRadius(12)
    }
    
    private var sortSettingsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Sortierung:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                HStack {
                    Text("Sortieren nach:")
                        .frame(width: 100, alignment: .leading)
                    Picker("Sortieren nach", selection: $sortColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Reihenfolge:")
                        .frame(width: 100, alignment: .leading)
                    Picker("Reihenfolge", selection: $sortOrder) {
                        ForEach(SortOrder.allCases, id: \.self) { order in
                            Text(order.rawValue).tag(order)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
            }
        }
        .padding(15)
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var pageOrientationView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Seitenausrichtung:")
                .font(.headline)
                .fontWeight(.medium)
            
            Picker("Seitenausrichtung", selection: $pageOrientation) {
                Text("Hochformat").tag(PageOrientation.portrait)
                Text("Querformat").tag(PageOrientation.landscape)
            }
            .pickerStyle(SegmentedPickerStyle())
            
            Text(pageOrientation == .portrait ? "Hochformat eignet sich für weniger Spalten" : "Querformat eignet sich für mehr Spalten")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(15)
        .background(Color.purple.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var logoSettingsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Logo-Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                // Logo Option Selection
                Picker("Logo-Option", selection: $logoOption) {
                    ForEach(LogoOption.allCases, id: \.self) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: logoOption) { _, _ in
                    if logoOption != .upload {
                        uploadedLogoData = nil
                    }
                }
                
                // Upload button
                if logoOption == .upload {
                    HStack {
                        Button("Logo auswählen") {
                            showLogoImporter = true
                        }
                        .buttonStyle(.bordered)
                        
                        if uploadedLogoData != nil {
                            Button("Logo entfernen") {
                                uploadedLogoData = nil
                            }
                            .buttonStyle(.bordered)
                            .foregroundColor(.red)
                        }
                    }
                }
                
                // Logo Preview
                if logoOption == .upload {
                    if let logoData = uploadedLogoData, let nsImage = NSImage(data: logoData) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Logo-Vorschau:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                } else if logoOption == .habegger {
                    // Zeige Habegger-Logo-Vorschau
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logo-Vorschau:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        if let logoData = createHabeggerLogoData(), let nsImage = NSImage(data: logoData) {
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        } else {
                            // Fallback: Zeige Text-Version
                            HStack {
                                Rectangle()
                                    .fill(Color(red: 0.8, green: 0.68, blue: 0.4))
                                    .frame(height: 8)
                                    .overlay(
                                        Text("HABEGGER")
                                            .font(.caption)
                                            .fontWeight(.bold)
                                            .foregroundColor(.black)
                                    )
                            }
                            .frame(width: 150, height: 30)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                        }
                    }
                }
            }
        }
        .padding(15)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(10)
    }
    
    private func generatePatchData() {
        var items: [PatchItem] = []
        
        for fixture in project.fixtures {
            var itemData: [String: String] = [:]
            
            for column in selectedColumns {
                itemData[column] = fixture.rawData[column] ?? ""
            }
            
            items.append(PatchItem(data: itemData))
        }
        
        // Sort the data
        items.sort { item1, item2 in
            let value1 = item1.data[sortColumn] ?? ""
            let value2 = item2.data[sortColumn] ?? ""
            
            // Try to sort numerically first
            if let num1 = Int(value1), let num2 = Int(value2) {
                return sortOrder == .ascending ? num1 < num2 : num1 > num2
            } else if let num1 = Double(value1), let num2 = Double(value2) {
                return sortOrder == .ascending ? num1 < num2 : num1 > num2
            } else {
                // Sort alphabetically
                let comparison = value1.localizedCaseInsensitiveCompare(value2)
                return sortOrder == .ascending ? comparison == .orderedAscending : comparison == .orderedDescending
            }
        }
        
        self.patchData = items
    }
    
    private func exportPatchPDF() {
        guard !selectedColumns.isEmpty else {
            let alert = NSAlert()
            alert.messageText = "Keine Spalten ausgewählt"
            alert.informativeText = "Bitte wählen Sie mindestens eine Spalte aus."
            alert.alertStyle = .warning
            alert.runModal()
            return
        }
        
        guard !sortColumn.isEmpty else {
            let alert = NSAlert()
            alert.messageText = "Keine Sortier-Spalte ausgewählt"
            alert.informativeText = "Bitte wählen Sie eine Spalte zum Sortieren aus."
            alert.alertStyle = .warning
            alert.runModal()
            return
        }
        
        // Bereite Logo-Daten vor
        var logoData: Data? = nil
        switch logoOption {
        case .none:
            logoData = nil
        case .upload:
            logoData = uploadedLogoData
        case .habegger:
            logoData = createHabeggerLogoData()
        }
        
        let pdfCreator = PatchListPDFCreator()
        let pdfData = pdfCreator.createPDF(
            patchData: self.patchData,
            selectedColumns: selectedColumns,
            projectName: project.name,
            sortColumn: sortColumn,
            sortOrder: sortOrder,
            pageOrientation: pageOrientation,
            logoData: logoData
        )
        
        let filename = "Patch_Liste_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die Patch-Liste wurde erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                // Lade das Logo als Data
                let logoData = try Data(contentsOf: url)
                uploadedLogoData = logoData
                
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func createHabeggerLogoData() -> Data? {
        // Versuche zuerst das Logo aus den Assets zu laden
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            guard let tiffData = assetLogo.tiffRepresentation,
                  let bitmapRep = NSBitmapImageRep(data: tiffData),
                  let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
                return nil
            }
            return pngData
        }
        
        // Fallback: Erstelle das Logo programmatisch mit dem richtigen Design
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        // Clear background
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        // Draw gold bar (wichtiger Teil des Habegger-Logos)
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        // Draw "HABEGGER" text in bold
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        // Konvertiere zu PNG Data
        guard let tiffData = image.tiffRepresentation,
              let bitmapRep = NSBitmapImageRep(data: tiffData),
              let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
            return nil
        }
        
        return pngData
    }
    
    private func loadSettings() {
        // Load saved settings from project
        selectedColumns = project.loadPatchSelectedColumns()
        sortColumn = project.patchSortColumn ?? ""
        sortOrder = SortOrder(rawValue: project.patchSortOrder) ?? .ascending
        pageOrientation = PageOrientation(rawValue: project.patchPageOrientation) ?? .portrait
    }
    
    private func saveSettings() {
        // Save current settings to project
        project.savePatchSelectedColumns(selectedColumns)
        project.patchSortColumn = sortColumn.isEmpty ? nil : sortColumn
        project.patchSortOrder = sortOrder.rawValue
        project.patchPageOrientation = pageOrientation.rawValue
        project.updatedAt = Date()
        
        do {
            try modelContext.save()
        } catch {
            print("Failed to save Patch List settings: \(error)")
        }
    }
}

class PatchListPDFCreator {
    func createPDF(patchData: [PatchItem], selectedColumns: [String], projectName: String, sortColumn: String, sortOrder: PatchListView.SortOrder, pageOrientation: PatchListView.PageOrientation, logoData: Data?) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        let (pageWidth, pageHeight): (CGFloat, CGFloat) = {
            switch pageOrientation {
            case .portrait:
                return (595.2, 841.8)
            case .landscape:
                return (841.8, 595.2)
            }
        }()
        
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        // Konvertiere Logo-Data zu CGImage falls vorhanden
        var logoCGImage: CGImage? = nil
        if let logoData = logoData {
            logoCGImage = createCGImageFromData(logoData)
        }
        
        let margin: CGFloat = 20
        let rowHeight: CGFloat = 20
        let headerHeight: CGFloat = 30
        let titleHeight: CGFloat = 80
        let availableHeight = pageHeight - titleHeight - margin * 2
        let maxRowsPerPage = Int((availableHeight - headerHeight) / rowHeight)
        
        let totalPages = Int(ceil(Double(patchData.count) / Double(maxRowsPerPage)))
        
        for page in 0..<totalPages {
            pdfContext.beginPDFPage(nil)
            
            let startIndex = page * maxRowsPerPage
            let endIndex = min(startIndex + maxRowsPerPage, patchData.count)
            let pageData = Array(patchData[startIndex..<endIndex])
            
            drawPatchPage(
                context: pdfContext,
                pageData: pageData,
                selectedColumns: selectedColumns,
                projectName: projectName,
                sortColumn: sortColumn,
                sortOrder: sortOrder,
                pageRect: pageRect,
                pageNumber: page + 1,
                totalPages: totalPages,
                logoCGImage: logoCGImage
            )
            
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        return pdfData as Data
    }
    
    private func createCGImageFromData(_ data: Data) -> CGImage? {
        guard let dataProvider = CGDataProvider(data: data as CFData),
              let cgImage = CGImage(
                pngDataProviderSource: dataProvider,
                decode: nil,
                shouldInterpolate: true,
                intent: .defaultIntent
              ) else {
            // Falls PNG nicht funktioniert, versuche JPEG
            guard let dataProvider = CGDataProvider(data: data as CFData),
                  let cgImage = CGImage(
                    jpegDataProviderSource: dataProvider,
                    decode: nil,
                    shouldInterpolate: true,
                    intent: .defaultIntent
                  ) else {
                return nil
            }
            return cgImage
        }
        return cgImage
    }
    
    private func drawPatchPage(context: CGContext, pageData: [PatchItem], selectedColumns: [String], projectName: String, sortColumn: String, sortOrder: PatchListView.SortOrder, pageRect: CGRect, pageNumber: Int, totalPages: Int, logoCGImage: CGImage?) {
        let margin: CGFloat = 20
        
        // Logo zeichnen falls vorhanden
        if let logo = logoCGImage {
            let logoRect = CGRect(x: pageRect.width - 120, y: pageRect.height - 50, width: 90, height: 30)
            let scaledLogoRect = calculateAspectFitRect(imageSize: CGSize(width: logo.width, height: logo.height), containerRect: logoRect)
            context.draw(logo, in: scaledLogoRect)
        }
        
        // Title
        drawText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 40, width: pageRect.width - 2 * margin, height: 25), fontSize: 18, bold: true)
        
        drawText(context: context, text: "Patch Liste", rect: CGRect(x: margin, y: pageRect.height - 65, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true)
        
        let sortInfo = "Sortiert nach: \(sortColumn) (\(sortOrder.rawValue))"
        drawText(context: context, text: sortInfo, rect: CGRect(x: margin, y: pageRect.height - 85, width: pageRect.width - 2 * margin, height: 15), fontSize: 10, bold: false)
        
        // Table
        let totalTableWidth = pageRect.width - 2 * margin
        let columnWidth = totalTableWidth / CGFloat(selectedColumns.count)
        
        // Header
        let headerY = pageRect.height - 120
        for (index, column) in selectedColumns.enumerated() {
            let cellRect = CGRect(x: margin + CGFloat(index) * columnWidth, y: headerY, width: columnWidth, height: 25)
            drawTableCell(context: context, text: column, rect: cellRect, isHeader: true)
        }
        
        // Data rows
        for (rowIndex, item) in pageData.enumerated() {
            let rowY = headerY - CGFloat(rowIndex + 1) * 20
            for (columnIndex, column) in selectedColumns.enumerated() {
                let cellRect = CGRect(x: margin + CGFloat(columnIndex) * columnWidth, y: rowY, width: columnWidth, height: 20)
                let cellValue = item.data[column] ?? ""
                drawTableCell(context: context, text: cellValue, rect: cellRect, isHeader: false, isAlternate: rowIndex % 2 == 1)
            }
        }
        
        // Footer mit Datum, Seitenzahl
        let footerY: CGFloat = 20
        
        // Aktuelles Datum links
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.locale = Locale(identifier: "de_DE")
        let currentDate = dateFormatter.string(from: Date())
        
        drawText(context: context, text: " \(currentDate)", rect: CGRect(x: margin, y: footerY, width: 200, height: 15), fontSize: 10, bold: false)
        
        // Seitenzahl rechts
        drawText(context: context, text: "Seite \(pageNumber) von \(totalPages)", rect: CGRect(x: pageRect.width - 150, y: footerY, width: 130, height: 15), fontSize: 10, bold: false)
    }
    
    private func calculateAspectFitRect(imageSize: CGSize, containerRect: CGRect) -> CGRect {
        let imageAspectRatio = imageSize.width / imageSize.height
        let containerAspectRatio = containerRect.width / containerRect.height
        
        var resultRect = containerRect
        
        if imageAspectRatio > containerAspectRatio {
            // Image is wider than container
            resultRect.size.height = containerRect.width / imageAspectRatio
            resultRect.origin.y = containerRect.origin.y + (containerRect.height - resultRect.height) / 2
        } else {
            // Image is taller than container
            resultRect.size.width = containerRect.height * imageAspectRatio
            resultRect.origin.x = containerRect.origin.x + (containerRect.width - resultRect.width) / 2
        }
        
        return resultRect
    }
    
    private func drawTableCell(context: CGContext, text: String, rect: CGRect, isHeader: Bool, isAlternate: Bool = false) {
        // Background
        if isHeader {
            context.setFillColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1.0)
        } else if isAlternate {
            context.setFillColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
        } else {
            context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        }
        context.fill(rect)
        
        // Border
        context.setStrokeColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(rect)
        
        // Text
        let textRect = rect.insetBy(dx: 4, dy: 2)
        drawText(context: context, text: text, rect: textRect, fontSize: isHeader ? 10 : 9, bold: isHeader)
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: rect.minX + 2, y: rect.minY + 2)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        context.restoreGState()
    }
}

// MARK: - Data Models
struct PatchItem: Identifiable {
    let id = UUID()
    let data: [String: String]
}
