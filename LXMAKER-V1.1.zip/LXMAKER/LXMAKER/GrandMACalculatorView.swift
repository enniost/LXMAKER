import SwiftUI
import SwiftData
import AppKit

struct GrandMACalculatorView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedChannelColumn = ""
    @State private var calculatedChannels = 0
    @State private var recommendedHardware: [GrandMAHardware] = []
    @State private var logoOption: LogoOption = .none
    @State private var uploadedLogoData: Data? = nil
    @State private var showLogoImporter = false
    @State private var selectedVersion: GrandMAVersion = .grandMA3
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    enum GrandMAVersion: String, CaseIterable {
        case grandMA2 = "GrandMA2"
        case grandMA3 = "GrandMA3"
    }
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canCalculate: Bool {
        !selectedChannelColumn.isEmpty && !project.fixtures.isEmpty
    }
    
    private var filteredHardware: [GrandMAHardware] {
        GrandMAHardware.allHardware.filter { $0.version == selectedVersion }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text("GrandMA Parameter Calculator")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Berechnet die benötigten GrandMA3 Parameter für Ihre Fixtures")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        if availableColumns.isEmpty {
                            Text("⚠️ Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // Version Selection
                            versionSelectionView
                            
                            // Channel Column Selection
                            channelColumnSelectionView
                            
                            // Logo Settings
                            logoSettingsView
                            
                            // Calculation Button
                            Button("Parameter berechnen") {
                                calculateChannels()
                            }
                            .disabled(!canCalculate)
                            .buttonStyle(.bordered)
                            .controlSize(.large)
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Results
                        VStack(alignment: .leading, spacing: 20) {
                            if calculatedChannels > 0 {
                                calculationResultsView
                            } else {
                                VStack(alignment: .leading, spacing: 15) {
                                    Text("Anleitung:")
                                        .font(.headline)
                                        .fontWeight(.medium)
                                    
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text("• Wählen Sie die GrandMA Version")
                                        Text("• Wählen Sie die Spalte mit den DMX-Kanälen")
                                        Text("• Klicken Sie auf 'Parameter berechnen'")
                                        Text("• Sehen Sie die Hardware-Empfehlungen")
                                        Text("• Optional: Exportieren Sie als PDF")
                                    }
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                    
                                    Spacer()
                                }
                                .padding(15)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Hardware Overview
                    if calculatedChannels > 0 {
                        hardwareOverviewView
                    }
                    
                    // Export Button
                    if calculatedChannels > 0 {
                        Button("PDF exportieren") {
                            exportPDF()
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                        .padding(.bottom, 20)
                    }
                }
                .padding(20)
            }
            .navigationTitle("GrandMA Parameter Calculator")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        saveSettings()
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1400, minHeight: 900)
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
            .onAppear {
                loadSettings()
            }
        }
    }
    
    private var channelColumnSelectionView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("DMX-Footprint Spalte auswählen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                HStack {
                    Text("")
                        .frame(width: 80, alignment: .leading)
                    Picker("", selection: $selectedChannelColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 250)
                }
            }
            
            Text("Wählen Sie die Spalte aus, die die Anzahl der DMX-Kanäle pro Fixture enthält.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(15)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var calculationResultsView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Berechnungsergebnis:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("Gesamte DMX-Kanäle:")
                        .fontWeight(.medium)
                    Spacer()
                    Text("\(calculatedChannels)")
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.blue.opacity(0.1))
                .cornerRadius(8)
                
                if !recommendedHardware.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Empfohlene Hardware:")
                            .fontWeight(.medium)
                            .foregroundColor(.green)
                        
                        ForEach(recommendedHardware.prefix(3), id: \.id) { hardware in
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(hardware.name)
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                    Text("\(hardware.parameters) Parameter")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                            }
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.green.opacity(0.05))
                            .cornerRadius(6)
                        }
                    }
                }
            }
        }
        .padding(15)
        .background(Color.gray.opacity(0.05))
        .cornerRadius(10)
    }
    
    private var hardwareOverviewView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Alle \(selectedVersion.rawValue) Hardware-Optionen:")
                .font(.headline)
                .fontWeight(.medium)
            
            ScrollView {
                LazyVStack(spacing: 8) {
                    ForEach(filteredHardware, id: \.id) { hardware in
                        HardwareRow(
                            hardware: hardware,
                            isRecommended: recommendedHardware.contains { $0.id == hardware.id },
                            requiredChannels: calculatedChannels
                        )
                    }
                }
            }
            .frame(maxHeight: 400)
        }
        .padding(15)
        .background(Color.gray.opacity(0.05))
        .cornerRadius(10)
    }
    
    private var logoSettingsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Logo-Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                Picker("Logo-Option", selection: $logoOption) {
                    ForEach(LogoOption.allCases, id: \.self) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: logoOption) { _, _ in
                    if logoOption != .upload {
                        uploadedLogoData = nil
                    }
                }
                
                if logoOption == .upload {
                    HStack {
                        Button("Logo auswählen") {
                            showLogoImporter = true
                        }
                        .buttonStyle(.bordered)
                        
                        if uploadedLogoData != nil {
                            Button("Logo entfernen") {
                                uploadedLogoData = nil
                            }
                            .buttonStyle(.bordered)
                            .foregroundColor(.red)
                        }
                    }
                }
                
                // Logo Preview
                if logoOption == .upload {
                    if let logoData = uploadedLogoData, let nsImage = NSImage(data: logoData) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Logo-Vorschau:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                } else if logoOption == .habegger {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logo-Vorschau:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        if let logoData = createHabeggerLogoData(), let nsImage = NSImage(data: logoData) {
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        } else {
                            HStack {
                                Rectangle()
                                    .fill(Color(red: 0.8, green: 0.68, blue: 0.4))
                                    .frame(height: 8)
                                    .overlay(
                                        Text("HABEGGER")
                                            .font(.caption)
                                            .fontWeight(.bold)
                                            .foregroundColor(.black)
                                    )
                            }
                            .frame(width: 150, height: 30)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                        }
                    }
                }
            }
        }
        .padding(15)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var versionSelectionView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("GrandMA Version auswählen:")
                .font(.headline)
                .fontWeight(.medium)
            
            Picker("Version", selection: $selectedVersion) {
                ForEach(GrandMAVersion.allCases, id: \.self) { version in
                    Text(version.rawValue).tag(version)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .onChange(of: selectedVersion) { _, _ in
                calculatedChannels = 0
                recommendedHardware = []
            }
            
            Text(selectedVersion == .grandMA2 ? "Parameter für GrandMA2 Hardware" : "Parameter für GrandMA3 Hardware (Software 1.7+)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(15)
        .background(Color.purple.opacity(0.1))
        .cornerRadius(10)
    }
    
    private func calculateChannels() {
        guard !selectedChannelColumn.isEmpty else { return }
        
        var totalChannels = 0
        
        for fixture in project.fixtures {
            if let channelValue = fixture.rawData[selectedChannelColumn],
               let channels = Int(channelValue) {
                totalChannels += channels
            }
        }
        
        calculatedChannels = totalChannels
        
        recommendedHardware = filteredHardware
            .filter { $0.parameters >= totalChannels }
            .sorted { $0.parameters < $1.parameters }
    }
    
    private func exportPDF() {
        guard calculatedChannels > 0 else { return }
        
        var logoData: Data? = nil
        switch logoOption {
        case .none:
            logoData = nil
        case .upload:
            logoData = uploadedLogoData
        case .habegger:
            logoData = createHabeggerLogoData()
        }
        
        let pdfCreator = GrandMACalculatorPDFCreator()
        let pdfData = pdfCreator.createPDF(
            projectName: project.name,
            selectedColumn: selectedChannelColumn,
            totalChannels: calculatedChannels,
            recommendedHardware: recommendedHardware,
            allHardware: filteredHardware,
            selectedVersion: selectedVersion,
            logoData: logoData
        )
        
        let filename = "GrandMA_Parameter_Berechnung_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die GrandMA Parameter-Berechnung wurde erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                uploadedLogoData = try Data(contentsOf: url)
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func createHabeggerLogoData() -> Data? {
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            guard let tiffData = assetLogo.tiffRepresentation,
                  let bitmapRep = NSBitmapImageRep(data: tiffData),
                  let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
                return nil
            }
            return pngData
        }
        
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        guard let tiffData = image.tiffRepresentation,
              let bitmapRep = NSBitmapImageRep(data: tiffData),
              let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
            return nil
        }
        
        return pngData
    }
    
    private func loadSettings() {
        // Load saved settings from project
        selectedChannelColumn = project.grandmaChannelColumn ?? ""
        selectedVersion = GrandMAVersion(rawValue: project.grandmaVersion) ?? .grandMA3
    }
    
    private func saveSettings() {
        // Save current settings to project
        project.grandmaChannelColumn = selectedChannelColumn.isEmpty ? nil : selectedChannelColumn
        project.grandmaVersion = selectedVersion.rawValue
        project.updatedAt = Date()
        
        do {
            try modelContext.save()
        } catch {
            print("Failed to save GrandMA Calculator settings: \(error)")
        }
    }
}

struct HardwareRow: View {
    let hardware: GrandMAHardware
    let isRecommended: Bool
    let requiredChannels: Int
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(hardware.name)
                    .font(.subheadline)
                    .fontWeight(isRecommended ? .bold : .medium)
                Text(hardware.category)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Text("\(hardware.parameters)")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(hardware.parameters >= requiredChannels ? .green : .red)
            
            Text("Parameter")
                .font(.caption)
                .foregroundColor(.secondary)
            
            if isRecommended {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(.green)
            } else if hardware.parameters < requiredChannels {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.red)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(isRecommended ? Color.green.opacity(0.1) : Color.clear)
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(isRecommended ? Color.green : Color.gray.opacity(0.3), lineWidth: 1)
        )
    }
}

// MARK: - Data Models
struct GrandMAHardware: Identifiable {
    let id = UUID()
    let name: String
    let category: String
    let parameters: Int
    let version: GrandMACalculatorView.GrandMAVersion
    
    static let allHardware: [GrandMAHardware] = [
        // GrandMA3 Hardware
        GrandMAHardware(name: "grandMA3 full-size", category: "Console", parameters: 20480, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 full-size CRV", category: "Console", parameters: 20480, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 light", category: "Console", parameters: 16384, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 light CRV", category: "Console", parameters: 16384, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 processing unit XL", category: "Processing Unit", parameters: 16384, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 replay unit", category: "Replay Unit", parameters: 8192, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 compact XT", category: "Console", parameters: 8192, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 compact", category: "Console", parameters: 8192, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 processing unit L", category: "Processing Unit", parameters: 8192, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 processing unit M", category: "Processing Unit", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 onPC command wing XT", category: "onPC", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 onPC command wing", category: "onPC", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 onPC fader wing", category: "onPC", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 onPC rack-unit", category: "onPC", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 onPC 8Port Node 4k", category: "onPC Node", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 onPC 4Port Node 4k", category: "onPC Node", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 onPC 2Port Node 2k", category: "onPC Node", parameters: 4096, version: .grandMA3),
        GrandMAHardware(name: "grandMA3 viz-key", category: "Visualizer", parameters: 512, version: .grandMA3),
        
        // GrandMA2 Hardware
        GrandMAHardware(name: "grandMA2 full-size", category: "Console", parameters: 8192, version: .grandMA2),
        GrandMAHardware(name: "grandMA2 light", category: "Console", parameters: 4096, version: .grandMA2),
        GrandMAHardware(name: "grandMA2 ultra-light", category: "Console", parameters: 4096, version: .grandMA2),
        GrandMAHardware(name: "grandMA2 replay unit", category: "Replay Unit", parameters: 4096, version: .grandMA2),
        GrandMAHardware(name: "MA NPU (Network Processing Unit)", category: "Processing Unit", parameters: 4096, version: .grandMA2),
        GrandMAHardware(name: "MA onPC command wing", category: "onPC", parameters: 2048, version: .grandMA2),
        GrandMAHardware(name: "MA onPC fader wing", category: "onPC", parameters: 2048, version: .grandMA2),
        GrandMAHardware(name: "MA 8Port Node onPC", category: "onPC Node", parameters: 2048, version: .grandMA2),
        GrandMAHardware(name: "MA 4Port Node onPC", category: "onPC Node", parameters: 2048, version: .grandMA2),
        GrandMAHardware(name: "MA NSP (grandMA2 4Port Node mode)", category: "onPC Node", parameters: 2048, version: .grandMA2),
        GrandMAHardware(name: "MA 2Port Node onPC 2K", category: "onPC Node", parameters: 2048, version: .grandMA2),
        GrandMAHardware(name: "MA 2Port Node onPC 1K", category: "onPC Node", parameters: 1024, version: .grandMA2),
        GrandMAHardware(name: "MA 2Port Node onPC Pro (old version)", category: "onPC Node", parameters: 1024, version: .grandMA2),
        GrandMAHardware(name: "MA 2Port Node onPC (old gray version)", category: "onPC Node", parameters: 512, version: .grandMA2)
    ]
}

// MARK: - PDF Creator
class GrandMACalculatorPDFCreator {
    func createPDF(projectName: String, selectedColumn: String, totalChannels: Int, recommendedHardware: [GrandMAHardware], allHardware: [GrandMAHardware], selectedVersion: GrandMACalculatorView.GrandMAVersion, logoData: Data?) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        let pageWidth: CGFloat = 595.2
        let pageHeight: CGFloat = 841.8
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        var logoCGImage: CGImage? = nil
        if let logoData = logoData {
            logoCGImage = createCGImageFromData(logoData)
        }
        
        pdfContext.beginPDFPage(nil)
        
        drawGrandMACalculatorPage(
            context: pdfContext,
            projectName: projectName,
            selectedColumn: selectedColumn,
            totalChannels: totalChannels,
            recommendedHardware: recommendedHardware,
            allHardware: allHardware,
            selectedVersion: selectedVersion,
            pageRect: pageRect,
            logoCGImage: logoCGImage
        )
        
        pdfContext.endPDFPage()
        pdfContext.closePDF()
        
        return pdfData as Data
    }
    
    private func createCGImageFromData(_ data: Data) -> CGImage? {
        guard let dataProvider = CGDataProvider(data: data as CFData),
              let cgImage = CGImage(
                pngDataProviderSource: dataProvider,
                decode: nil,
                shouldInterpolate: true,
                intent: .defaultIntent
              ) else {
            guard let dataProvider = CGDataProvider(data: data as CFData),
                  let cgImage = CGImage(
                    jpegDataProviderSource: dataProvider,
                    decode: nil,
                    shouldInterpolate: true,
                    intent: .defaultIntent
                  ) else {
                return nil
            }
            return cgImage
        }
        return cgImage
    }
    
    private func drawGrandMACalculatorPage(context: CGContext, projectName: String, selectedColumn: String, totalChannels: Int, recommendedHardware: [GrandMAHardware], allHardware: [GrandMAHardware], selectedVersion: GrandMACalculatorView.GrandMAVersion, pageRect: CGRect, logoCGImage: CGImage?) {
        let margin: CGFloat = 40
        
        // Logo
        if let logo = logoCGImage {
            let logoRect = CGRect(x: pageRect.width - 120, y: pageRect.height - 50, width: 90, height: 30)
            let scaledLogoRect = calculateAspectFitRect(imageSize: CGSize(width: logo.width, height: logo.height), containerRect: logoRect)
            context.draw(logo, in: scaledLogoRect)
        }
        
        // Title
        drawText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 50, width: pageRect.width - 2 * margin, height: 25), fontSize: 18, bold: true)
        drawText(context: context, text: "\(selectedVersion.rawValue) Parameter-Berechnung", rect: CGRect(x: margin, y: pageRect.height - 75, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true)
        
        // Results
        var currentY = pageRect.height - 120
        
        // Summary Box
        let summaryRect = CGRect(x: margin, y: currentY - 80, width: pageRect.width - 2 * margin, height: 80)
        context.setFillColor(red: 0.9, green: 0.95, blue: 1.0, alpha: 1.0)
        context.fill(summaryRect)
        context.setStrokeColor(red: 0.2, green: 0.4, blue: 0.8, alpha: 1.0)
        context.setLineWidth(2.0)
        context.stroke(summaryRect)
        
        drawText(context: context, text: "Berechnungsergebnis (\(selectedVersion.rawValue))", rect: CGRect(x: margin + 20, y: currentY - 25, width: 300, height: 15), fontSize: 14, bold: true)
        drawText(context: context, text: "Analysierte Spalte: \(selectedColumn)", rect: CGRect(x: margin + 20, y: currentY - 45, width: 300, height: 12), fontSize: 11, bold: false)
        drawText(context: context, text: "Benötigte DMX-Kanäle: \(totalChannels)", rect: CGRect(x: margin + 20, y: currentY - 60, width: 300, height: 12), fontSize: 11, bold: true)
        
        currentY -= 120
        
        // Recommended Hardware
        if !recommendedHardware.isEmpty {
            drawText(context: context, text: "Empfohlene \(selectedVersion.rawValue) Hardware:", rect: CGRect(x: margin, y: currentY, width: 300, height: 15), fontSize: 14, bold: true)
            currentY -= 25
            
            for (index, hardware) in recommendedHardware.prefix(5).enumerated() {
                let rect = CGRect(x: margin + 20, y: currentY - CGFloat(index) * 20, width: pageRect.width - 2 * margin - 20, height: 18)
                context.setFillColor(red: 0.9, green: 1.0, blue: 0.9, alpha: 1.0)
                context.fill(rect)
                context.setStrokeColor(red: 0.4, green: 0.8, blue: 0.4, alpha: 1.0)
                context.setLineWidth(1.0)
                context.stroke(rect)
                
                drawText(context: context, text: "✓ \(hardware.name) (\(hardware.parameters) Parameter)", rect: rect.insetBy(dx: 8, dy: 2), fontSize: 10, bold: false)
            }
            
            currentY -= CGFloat(min(recommendedHardware.count, 5)) * 20 + 20
        }
        
        // All Hardware Table
        drawText(context: context, text: "Alle verfügbaren \(selectedVersion.rawValue) Hardware-Optionen:", rect: CGRect(x: margin, y: currentY, width: 400, height: 15), fontSize: 14, bold: true)
        currentY -= 30
        
        // Table Headers
        let headerRect = CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20)
        context.setFillColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        context.fill(headerRect)
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(headerRect)
        
        drawText(context: context, text: "Hardware", rect: CGRect(x: margin + 10, y: currentY + 3, width: 300, height: 14), fontSize: 10, bold: true)
        drawText(context: context, text: "Kategorie", rect: CGRect(x: margin + 320, y: currentY + 3, width: 100, height: 14), fontSize: 10, bold: true)
        drawText(context: context, text: "Parameter", rect: CGRect(x: margin + 430, y: currentY + 3, width: 80, height: 14), fontSize: 10, bold: true)
        
        currentY -= 20
        
        // Table Rows
        for (index, hardware) in allHardware.enumerated() {
            let rowRect = CGRect(x: margin, y: currentY - CGFloat(index) * 18, width: pageRect.width - 2 * margin, height: 18)
            
            let isRecommended = recommendedHardware.contains { $0.id == hardware.id }
            let canHandle = hardware.parameters >= totalChannels
            
            if isRecommended {
                context.setFillColor(red: 0.9, green: 1.0, blue: 0.9, alpha: 1.0)
            } else if !canHandle {
                context.setFillColor(red: 1.0, green: 0.9, blue: 0.9, alpha: 1.0)
            } else {
                context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            }
            
            context.fill(rowRect)
            context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
            context.setLineWidth(0.5)
            context.stroke(rowRect)
            
            let statusIcon = isRecommended ? "✓ " : (canHandle ? "" : "✗ ")
            drawText(context: context, text: "\(statusIcon)\(hardware.name)", rect: CGRect(x: margin + 10, y: currentY - CGFloat(index) * 18 + 2, width: 300, height: 14), fontSize: 9, bold: false)
            drawText(context: context, text: hardware.category, rect: CGRect(x: margin + 320, y: currentY - CGFloat(index) * 18 + 2, width: 100, height: 14), fontSize: 9, bold: false)
            drawText(context: context, text: "\(hardware.parameters)", rect: CGRect(x: margin + 430, y: currentY - CGFloat(index) * 18 + 2, width: 80, height: 14), fontSize: 9, bold: false)
        }
        
        // Footer
        let footerY: CGFloat = 30
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.locale = Locale(identifier: "de_DE")
        let currentDate = dateFormatter.string(from: Date())
        
        drawText(context: context, text: "Erstellt am: \(currentDate)", rect: CGRect(x: margin, y: footerY, width: 200, height: 15), fontSize: 10, bold: false)
        drawText(context: context, text: "Seite 1 von 1", rect: CGRect(x: pageRect.width - 150, y: footerY, width: 130, height: 15), fontSize: 10, bold: false)
    }
    
    private func calculateAspectFitRect(imageSize: CGSize, containerRect: CGRect) -> CGRect {
        let imageAspectRatio = imageSize.width / imageSize.height
        let containerAspectRatio = containerRect.width / containerRect.height
        
        var resultRect = containerRect
        
        if imageAspectRatio > containerAspectRatio {
            resultRect.size.height = containerRect.width / imageAspectRatio
            resultRect.origin.y = containerRect.origin.y + (containerRect.height - resultRect.height) / 2
        } else {
            resultRect.size.width = containerRect.height * imageAspectRatio
            resultRect.origin.x = containerRect.origin.x + (containerRect.width - resultRect.width) / 2
        }
        
        return resultRect
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: rect.minX + 2, y: rect.minY + 2)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        context.restoreGState()
    }
}
