import Foundation

enum CSVError: Error {
    case invalidFormat
    case invalidData
    case emptyFile
}

struct CSVData {
    let headers: [String] 
    let rows: [[String: String]]
}

class CSVParser {
    static func parse(csvString: String) throws -> CSVData {
        var rows: [[String: String]] = []
        let lines = csvString.components(separatedBy: .newlines)
            .filter { !$0.isEmpty }
        
        guard !lines.isEmpty else { throw CSVError.emptyFile }
        
        let headers = lines[0].components(separatedBy: ";")
            .map { $0.trimmingCharacters(in: .whitespaces) }
        
        let uniqueHeaders = Set(headers)
        if uniqueHeaders.count != headers.count {
            print("Warnung: Doppelte Spaltenüberschriften gefunden")
        }
        
        for line in lines.dropFirst() {
            let fields = line.components(separatedBy: ";")
                .map { $0.trimmingCharacters(in: .whitespaces) }
            
            guard fields.count == headers.count else {
                print("Warnung: Zeile hat nicht die gleiche Anzahl Felder wie der Header")
                continue
            }
            
            var row: [String: String] = [:]
            for (index, header) in headers.enumerated() {
                row[header] = fields[index]
            }
            rows.append(row)
        }
        
        return CSVData(headers: headers, rows: rows)
    }
    
    static func convertToFixtures(csvData: CSVData) throws -> [LightFixture] {
        guard !csvData.rows.isEmpty else { throw CSVError.invalidData }
        return csvData.rows.map { LightFixture(data: $0) }
    }
}