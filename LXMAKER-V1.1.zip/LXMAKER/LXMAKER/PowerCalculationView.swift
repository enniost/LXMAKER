import SwiftUI
import SwiftData
import Charts
import AppKit

// MARK: - Power Calculation Views

struct PowerCalculationView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedSystemColumn = ""
    @State private var selectedPlugboxColumn = ""
    @State private var selectedPlugchannelColumn = ""
    @State private var selectedPowerColumn = ""
    @State private var selectedVoltage: Double = 230
    @State private var simultaneityFactor: Double = 1.0
    @State private var systemMaxCurrents: [String: SystemCurrentSettings] = [:]
    @State private var showResults = false
    @State private var calculationResults: PowerCalculationResults?
    @State private var companyLogo: NSImage? = nil
    @State private var showLogoImporter = false
    @State private var logoOption: LogoOption = .none
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canCalculate: Bool {
        !selectedSystemColumn.isEmpty &&
        !selectedPlugboxColumn.isEmpty &&
        !selectedPlugchannelColumn.isEmpty &&
        !selectedPowerColumn.isEmpty
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text("LX Power Tool")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Stromberechnung und Phasenverteilung")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        if availableColumns.isEmpty {
                            Text("⚠️ Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // Column Mapping
                            columnMappingView
                            
                            // Power Settings
                            powerSettingsView
                            
                            // Logo Upload
                            logoUploadView
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - System Settings
                        VStack(alignment: .leading, spacing: 15) {
                            Text("System-Einstellungen:")
                                .font(.headline)
                                .fontWeight(.medium)
                            
                            Text("System- und Channel-spezifische Stromstärken:")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            systemSettingsView
                            
                            warningLegendView
                        }
                        .padding(15)
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(10)
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Action Buttons
                    HStack(spacing: 25) {
                        Button("Vorschau anzeigen") {
                            calculatePower()
                        }
                        .disabled(!canCalculate)
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                        
                        Button("PDF erzeugen") {
                            calculatePower()
                            exportPowerPDF()
                        }
                        .disabled(!canCalculate)
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                    }
                    .padding(.bottom, 20)
                    
                    // Results
                    if showResults, let results = calculationResults {
                        PowerResultsView(
                            results: results,
                            voltage: selectedVoltage,
                            simultaneityFactor: simultaneityFactor
                        )
                    }
                }
                .padding(20)
            }
            .navigationTitle("Stromberechnung")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1200, minHeight: 900)
            .onAppear {
                autoAssignColumns()
            }
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp, .pdf],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
        }
    }
    
    private var columnMappingView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("CSV-Spalten zuordnen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                HStack {
                    Text("System:")
                        .frame(width: 100, alignment: .leading)
                    Picker("System", selection: $selectedSystemColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Plugbox:")
                        .frame(width: 100, alignment: .leading)
                    Picker("Plugbox", selection: $selectedPlugboxColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Plugchannel:")
                        .frame(width: 100, alignment: .leading)
                    Picker("Plugchannel", selection: $selectedPlugchannelColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Power (Watt):")
                        .frame(width: 100, alignment: .leading)
                    Picker("Power", selection: $selectedPowerColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
            }
        }
        .padding(15)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var powerSettingsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Elektrische Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                HStack {
                    Text("Spannung (V):")
                        .frame(width: 100, alignment: .leading)
                    Picker("Spannung", selection: $selectedVoltage) {
                        Text("230 V (Standard)").tag(230.0)
                        Text("400 V (Drehstrom)").tag(400.0)
                        Text("110 V (USA)").tag(110.0)
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Gleichzeitigkeitsfaktor (0–1):")
                        .frame(width: 100, alignment: .leading)
                    Slider(value: $simultaneityFactor, in: 0...1, step: 0.01)
                        .frame(width: 150)
                    Text(String(format: "%.2f", simultaneityFactor))
                        .frame(width: 50)
                }
            }
        }
        .padding(15)
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var logoUploadView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Logo-Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                // Logo Option Selection
                Picker("Logo-Option", selection: $logoOption) {
                    ForEach(LogoOption.allCases, id: \.self) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: logoOption) { _, newValue in
                    handleLogoOptionChange(newValue)
                }
                
                // Show upload button only if upload option is selected
                if logoOption == .upload {
                    HStack {
                        Button("Logo auswählen") {
                            showLogoImporter = true
                        }
                        .buttonStyle(.bordered)
                        
                        if companyLogo != nil {
                            Button("Logo entfernen") {
                                companyLogo = nil
                            }
                            .buttonStyle(.bordered)
                            .foregroundColor(.red)
                        }
                    }
                }
                
                // Show logo preview
                if let logo = companyLogo {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logo-Vorschau:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Image(nsImage: logo)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 150, height: 50)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                    }
                }
            }
        }
        .padding(15)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var systemSettingsView: some View {
        VStack(spacing: 10) {
            if uniqueSystems.isEmpty {
                Text("Keine Systeme gefunden. Bitte wählen Sie zuerst die System-Spalte aus.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            } else {
                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(uniqueSystems, id: \.self) { system in
                            SystemSettingsCardView(
                                system: system,
                                systemMaxCurrents: $systemMaxCurrents
                            )
                        }
                    }
                }
                .frame(maxHeight: 300)
            }
        }
        .onChange(of: selectedSystemColumn) { _, _ in
            initializeSystemSettings()
        }
        .onAppear {
            initializeSystemSettings()
        }
    }
    
    private var warningLegendView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Warnungseinstellungen:")
                .font(.subheadline)
                .fontWeight(.medium)
            
            VStack(spacing: 4) {
                HStack {
                    Rectangle()
                        .fill(Color.green)
                        .frame(width: 15, height: 15)
                    Text("Normal (≤70%)")
                        .font(.caption)
                    Spacer()
                }
                
                HStack {
                    Rectangle()
                        .fill(Color(red: 0.9, green: 0.6, blue: 0.2))
                        .frame(width: 15, height: 15)
                    Text("Hoch (71-90%)")
                        .font(.caption)
                    Spacer()
                }
                
                HStack {
                    Rectangle()
                        .fill(Color.red)
                        .frame(width: 15, height: 15)
                    Text("Kritisch (>90%)")
                        .font(.caption)
                    Spacer()
                }
            }
        }
        .padding(10)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
    
    private var uniqueSystems: [String] {
        guard !selectedSystemColumn.isEmpty else { return [] }
        let systems = project.fixtures.compactMap { $0.rawData[selectedSystemColumn] }
        return Array(Set(systems)).sorted()
    }
    
    private func autoAssignColumns() {
        let keywordMappings = [
            "system": ["system", "sys"],
            "plugbox": ["plugbox", "box", "steckdose"],
            "plugchannel": ["plugchannel", "channel", "kanal", "ch"],
            "power": ["power", "watt", "leistung", "w"]
        ]
        
        for column in availableColumns {
            let columnLower = column.lowercased()
            
            if selectedSystemColumn.isEmpty,
               keywordMappings["system"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedSystemColumn = column
            }
            
            if selectedPlugboxColumn.isEmpty,
               keywordMappings["plugbox"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedPlugboxColumn = column
            }
            
            if selectedPlugchannelColumn.isEmpty,
               keywordMappings["plugchannel"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedPlugchannelColumn = column
            }
            
            if selectedPowerColumn.isEmpty,
               keywordMappings["power"]?.contains(where: { columnLower.contains($0) }) == true {
                selectedPowerColumn = column
            }
        }
    }
    
    private func initializeSystemSettings() {
        // Clear existing settings when system column changes
        systemMaxCurrents.removeAll()
        
        // Initialize settings for each unique system
        for system in uniqueSystems {
            if systemMaxCurrents[system] == nil {
                systemMaxCurrents[system] = SystemCurrentSettings()
            }
        }
    }
    
    private func calculatePower() {
        let calculator = PowerCalculator(
            fixtures: project.fixtures,
            systemColumn: selectedSystemColumn,
            plugboxColumn: selectedPlugboxColumn,
            plugchannelColumn: selectedPlugchannelColumn,
            powerColumn: selectedPowerColumn,
            voltage: selectedVoltage,
            simultaneityFactor: simultaneityFactor,
            systemMaxCurrents: systemMaxCurrents
        )
        
        calculationResults = calculator.calculate()
        showResults = true
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                if let image = NSImage(contentsOf: url) {
                    companyLogo = image
                }
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func exportPowerPDF() {
        guard let results = calculationResults else { return }
        
        let pdfCreator = PowerCalculationPDFCreator()
        let selectedLogo: NSImage? = {
            switch logoOption {
            case .upload:
                return companyLogo
            case .habegger:
                return createHabeggerLogo()
            case .none:
                return nil
            }
        }()
        
        let pdfData = pdfCreator.createPDF(
            results: results,
            projectName: project.name,
            voltage: selectedVoltage,
            simultaneityFactor: simultaneityFactor,
            companyLogo: selectedLogo
        )
        
        let filename = "LX_PowerTool_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die Stromberechnung wurde erfolgreich als PDF gespeichert und ist bereit für den Druck."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
    
    private func handleLogoOptionChange(_ option: LogoOption) {
        switch option {
        case .none:
            companyLogo = nil
        case .upload:
            // Keep current logo if available, otherwise user needs to select one
            break
        case .habegger:
            companyLogo = createHabeggerLogo()
        }
    }
    
    private func createHabeggerLogo() -> NSImage {
        // Use the logo from Assets instead of creating it programmatically
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            return assetLogo
        }
        
        // Fallback to programmatically created logo if asset is not found
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        // Clear background
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        // Draw gold bar
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        // Draw "HABEGGER" text
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        return image
    }
}

struct SystemSettingsCardView: View {
    let system: String
    @Binding var systemMaxCurrents: [String: SystemCurrentSettings]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("System \(system)")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                HStack {
                    Text("System Max. Stromstärke (A):")
                        .frame(width: 180, alignment: .leading)
                    TextField("16", value: Binding(
                        get: { systemMaxCurrents[system]?.systemMaxCurrent ?? 16 },
                        set: { 
                            if systemMaxCurrents[system] == nil {
                                systemMaxCurrents[system] = SystemCurrentSettings()
                            }
                            systemMaxCurrents[system]?.systemMaxCurrent = $0
                        }
                    ), format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 60)
                }
                
                SystemChannelInputsView(
                    system: system,
                    systemMaxCurrents: $systemMaxCurrents
                )
            }
        }
        .padding(10)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
}

struct SystemChannelInputsView: View {
    let system: String
    @Binding var systemMaxCurrents: [String: SystemCurrentSettings]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Channel-spezifische Stromstärken:")
                .font(.caption)
                .foregroundColor(.secondary)
            
            VStack(spacing: 4) {
                HStack(spacing: 8) {
                    ForEach(1...3, id: \.self) { channel in
                        channelInput(channel: channel)
                    }
                }
                
                HStack(spacing: 8) {
                    ForEach(4...6, id: \.self) { channel in
                        channelInput(channel: channel)
                    }
                }
            }
        }
    }
    
    private func channelInput(channel: Int) -> some View {
        HStack {
            Text("Ch \(channel):")
                .font(.caption)
                .frame(width: 35, alignment: .leading)
            TextField("16", value: Binding(
                get: { systemMaxCurrents[system]?.channelMaxCurrents[channel] ?? 16 },
                set: { 
                    if systemMaxCurrents[system] == nil {
                        systemMaxCurrents[system] = SystemCurrentSettings()
                    }
                    systemMaxCurrents[system]?.channelMaxCurrents[channel] = $0
                }
            ), format: .number)
            .textFieldStyle(.roundedBorder)
            .frame(width: 50)
        }
    }
}

struct PowerResultsView: View {
    let results: PowerCalculationResults
    let voltage: Double
    let simultaneityFactor: Double
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Berechnungsergebnisse")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            ForEach(results.systemResults.sorted(by: { $0.key < $1.key }), id: \.key) { systemName, systemResult in
                SystemResultCard(
                    systemName: systemName,
                    systemResult: systemResult,
                    voltage: voltage,
                    simultaneityFactor: simultaneityFactor
                )
            }
        }
        .padding()
        .background(Color.black)
        .cornerRadius(12)
    }
}

struct SystemResultCard: View {
    let systemName: String
    let systemResult: SystemPowerResult
    let voltage: Double
    let simultaneityFactor: Double
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            // System Header
            HStack {
                Text("System \(systemName)")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Text("Max: \(String(format: "%.1f", systemResult.maxCurrent))A")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            // Phase Warning Indicators
            HStack(spacing: 15) {
                ForEach(1...3, id: \.self) { phase in
                    let current = systemResult.phaseTotals[phase] ?? 0
                    let maxCurrent = systemResult.maxCurrent
                    let power = systemResult.phasePowers[phase] ?? 0
                    
                    VStack(spacing: 4) {
                        Text("Phase \(phase)")
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                        
                        Text("\(String(format: "%.2f", current))A")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        Text("\(String(format: "%.0f", power))W")
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Text(getLoadStatusText(current: current, maxCurrent: maxCurrent))
                            .font(.caption2)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                    }
                    .padding(8)
                    .background(getLoadColor(current: current, maxCurrent: maxCurrent))
                    .cornerRadius(6)
                }
            }
            
            // Phase Distribution Chart
            Chart {
                ForEach(1...3, id: \.self) { phase in
                    let power = systemResult.phasePowers[phase] ?? 0
                    let current = systemResult.phaseTotals[phase] ?? 0
                    
                    BarMark(
                        x: .value("Phase", "Phase \(phase)"),
                        y: .value("Power", power)
                    )
                    .foregroundStyle(getLoadColor(
                        current: current,
                        maxCurrent: systemResult.maxCurrent
                    ))
                }
            }
            .frame(height: 200)
            .chartYAxis {
                AxisMarks(position: .leading) { _ in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel()
                }
            }
            .chartXAxis {
                AxisMarks { _ in
                    AxisTick()
                    AxisValueLabel()
                }
            }
        }
        .padding()
        .background(Color.black)
        .cornerRadius(10)
        .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
    }
    
    private func getLoadColor(current: Double, maxCurrent: Double) -> Color {
        let loadPercentage = current / maxCurrent
        if loadPercentage <= 0.7 {
            return Color.green
        } else if loadPercentage <= 0.9 {
            return Color(red: 0.9, green: 0.6, blue: 0.2)
        } else {
            return Color.red
        }
    }
    
    private func getLoadStatusText(current: Double, maxCurrent: Double) -> String {
        let loadPercentage = current / maxCurrent
        if loadPercentage <= 0.7 {
            return "Normal (\(Int(loadPercentage * 100))%)"
        } else if loadPercentage <= 0.9 {
            return "Hoch (\(Int(loadPercentage * 100))%)"
        } else {
            return "KRITISCH (\(Int(loadPercentage * 100))%)"
        }
    }
}

// MARK: - Power Calculation Data Models

struct SystemCurrentSettings {
    var systemMaxCurrent: Double = 16
    var channelMaxCurrents: [Int: Double] = [1: 16, 2: 16, 3: 16, 4: 16, 5: 16, 6: 16]
}

struct PowerCalculationResults {
    let systemResults: [String: SystemPowerResult]
    let totalPower: Double
    let timestamp: Date
}

struct SystemPowerResult {
    let systemName: String
    let plugboxResults: [String: PlugboxPowerResult]
    let phaseTotals: [Int: Double] // Phase -> Total Current
    let phasePowers: [Int: Double] // Phase -> Total Power
    let maxCurrent: Double
    let channelMaxCurrents: [Int: Double]
}

struct PlugboxPowerResult {
    let plugboxName: String
    let channelPowers: [Int: Double] // Channel -> Power
    let channelCurrents: [Int: Double] // Channel -> Current
}

// MARK: - Power Calculator

class PowerCalculator {
    private let fixtures: [LightFixture]
    private let systemColumn: String
    private let plugboxColumn: String
    private let plugchannelColumn: String
    private let powerColumn: String
    private let voltage: Double
    private let simultaneityFactor: Double
    private let systemMaxCurrents: [String: SystemCurrentSettings]
    
    init(fixtures: [LightFixture], systemColumn: String, plugboxColumn: String, plugchannelColumn: String, powerColumn: String, voltage: Double, simultaneityFactor: Double, systemMaxCurrents: [String: SystemCurrentSettings]) {
        self.fixtures = fixtures
        self.systemColumn = systemColumn
        self.plugboxColumn = plugboxColumn
        self.plugchannelColumn = plugchannelColumn
        self.powerColumn = powerColumn
        self.voltage = voltage
        self.simultaneityFactor = simultaneityFactor
        self.systemMaxCurrents = systemMaxCurrents
    }
    
    func calculate() -> PowerCalculationResults {
        var systemResults: [String: SystemPowerResult] = [:]
        var totalPower: Double = 0
        
        // Group fixtures by system
        let systemGroups = Dictionary(grouping: fixtures) { fixture in
            fixture.rawData[systemColumn] ?? "Unknown"
        }
        
        for (systemName, systemFixtures) in systemGroups {
            let systemResult = calculateSystemPower(systemName: systemName, fixtures: systemFixtures)
            systemResults[systemName] = systemResult
            
            // Add to total power
            for (_, power) in systemResult.phasePowers {
                totalPower += power
            }
        }
        
        return PowerCalculationResults(
            systemResults: systemResults,
            totalPower: totalPower,
            timestamp: Date()
        )
    }
    
    private func calculateSystemPower(systemName: String, fixtures: [LightFixture]) -> SystemPowerResult {
        var plugboxResults: [String: PlugboxPowerResult] = [:]
        var phaseTotals: [Int: Double] = [1: 0, 2: 0, 3: 0]
        var phasePowers: [Int: Double] = [1: 0, 2: 0, 3: 0]
        
        // Get system settings
        let systemSettings = systemMaxCurrents[systemName] ?? SystemCurrentSettings()
        
        // Group fixtures by plugbox
        let plugboxGroups = Dictionary(grouping: fixtures) { fixture in
            fixture.rawData[plugboxColumn] ?? "Unknown"
        }
        
        for (plugboxName, plugboxFixtures) in plugboxGroups {
            var channelPowers: [Int: Double] = [:]
            var channelCurrents: [Int: Double] = [:]
            
            // Group by channel
            let channelGroups = Dictionary(grouping: plugboxFixtures) { fixture in
                Int(fixture.rawData[plugchannelColumn] ?? "0") ?? 0
            }
            
            for (channel, channelFixtures) in channelGroups {
                guard channel > 0 && channel <= 6 else { continue }
                
                // Calculate total power for this channel
                let totalChannelPower = channelFixtures.reduce(0) { total, fixture in
                    let powerString = fixture.rawData[powerColumn] ?? "0"
                    let power = Double(powerString.replacingOccurrences(of: ",", with: ".")) ?? 0
                    return total + (power * simultaneityFactor)
                }
                
                let current = totalChannelPower / voltage
                
                channelPowers[channel] = totalChannelPower
                channelCurrents[channel] = current
                
                // Map to phases (1,4 -> Phase 1; 2,5 -> Phase 2; 3,6 -> Phase 3)
                let phase = getPhaseForChannel(channel)
                phaseTotals[phase] = (phaseTotals[phase] ?? 0) + current
                phasePowers[phase] = (phasePowers[phase] ?? 0) + totalChannelPower
            }
            
            plugboxResults[plugboxName] = PlugboxPowerResult(
                plugboxName: plugboxName,
                channelPowers: channelPowers,
                channelCurrents: channelCurrents
            )
        }
        
        return SystemPowerResult(
            systemName: systemName,
            plugboxResults: plugboxResults,
            phaseTotals: phaseTotals,
            phasePowers: phasePowers,
            maxCurrent: systemSettings.systemMaxCurrent,
            channelMaxCurrents: systemSettings.channelMaxCurrents
        )
    }
    
    private func getPhaseForChannel(_ channel: Int) -> Int {
        switch channel {
        case 1, 4: return 1
        case 2, 5: return 2
        case 3, 6: return 3
        default: return 1
        }
    }
}

// MARK: - Power Calculation PDF Creator

class PowerCalculationPDFCreator {
    private let pageWidth: CGFloat = 595.2   // A4 width
    private let pageHeight: CGFloat = 841.8  // A4 height
    private let margin: CGFloat = 20
    
    func createPDF(results: PowerCalculationResults, projectName: String, voltage: Double, simultaneityFactor: Double, companyLogo: NSImage?) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        // Create high-resolution context
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        // Set high-quality rendering
        pdfContext.interpolationQuality = .high
        pdfContext.setAllowsAntialiasing(true)
        pdfContext.setShouldAntialias(true)
        pdfContext.setRenderingIntent(.defaultIntent)
        pdfContext.setShouldSubpixelPositionFonts(true)
        pdfContext.setShouldSubpixelQuantizeFonts(true)
        
        // Scale the entire context for high resolution
        pdfContext.scaleBy(x: 3.0, y: 3.0)
        
        // Calculate total pages needed - now 3 pages per system
        let systemCount = results.systemResults.count
        let totalPages = systemCount * 3 // Plugbox tables, Phase distribution, Charts
        
        var currentPage = 0
        
        for (systemName, systemResult) in results.systemResults.sorted(by: { $0.key < $1.key }) {
            currentPage += 1
            
            // Page 1: Plugbox Tables
            pdfContext.beginPDFPage(nil)
            drawSystemPlugboxTablesPage(
                context: pdfContext,
                systemName: systemName,
                systemResult: systemResult,
                projectName: projectName,
                voltage: voltage,
                simultaneityFactor: simultaneityFactor,
                pageRect: pageRect,
                pageNumber: currentPage,
                totalPages: totalPages,
                companyLogo: companyLogo
            )
            pdfContext.endPDFPage()
            
            currentPage += 1
            
            // Page 2: Phase Distribution Table
            pdfContext.beginPDFPage(nil)
            drawSystemPhaseDistributionPage(
                context: pdfContext,
                systemName: systemName,
                systemResult: systemResult,
                projectName: projectName,
                voltage: voltage,
                simultaneityFactor: simultaneityFactor,
                pageRect: pageRect,
                pageNumber: currentPage,
                totalPages: totalPages,
                companyLogo: companyLogo
            )
            pdfContext.endPDFPage()
            
            currentPage += 1
            
            // Page 3: Charts
            pdfContext.beginPDFPage(nil)
            drawSystemChartPage(
                context: pdfContext,
                systemName: systemName,
                systemResult: systemResult,
                projectName: projectName,
                voltage: voltage,
                pageRect: pageRect,
                pageNumber: currentPage,
                totalPages: totalPages,
                companyLogo: companyLogo
            )
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        return pdfData as Data
    }
    
    private func drawSystemPlugboxTablesPage(context: CGContext, systemName: String, systemResult: SystemPowerResult, projectName: String, voltage: Double, simultaneityFactor: Double, pageRect: CGRect, pageNumber: Int, totalPages: Int, companyLogo: NSImage?) {
        context.saveGState()
        
        // Logo
        if let logo = companyLogo {
            let logoAreaRect = CGRect(x: pageRect.width - 150, y: pageRect.height - 40, width: 130, height: 30)
            let actualLogoRect = calculateLogoRect(logo: logo, availableRect: logoAreaRect)
            if let cgImage = logo.cgImage(forProposedRect: nil, context: nil, hints: nil) {
                context.draw(cgImage, in: actualLogoRect)
            }
        }
        
        // Header
        drawHighQualityText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 30, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: true, centered: false)
        
        drawHighQualityText(context: context, text: "System \(systemName) - Plugbox Tabellen", rect: CGRect(x: margin, y: pageRect.height - 55, width: pageRect.width - 2 * margin, height: 20), fontSize: 16, bold: true, centered: false)
        
        let infoText = "Spannung: \(String(format: "%.0f", voltage)) V  •  Gleichzeitigkeitsfaktor: \(String(format: "%.2f", simultaneityFactor))  •  Max. Strom: \(String(format: "%.1f", systemResult.maxCurrent))A"
        drawHighQualityText(context: context, text: infoText, rect: CGRect(x: margin, y: pageRect.height - 75, width: pageRect.width - 2 * margin, height: 15), fontSize: 10, bold: false, centered: false)
        
        var currentY: CGFloat = pageRect.height - 100
        
        // Plugbox tables
        let sortedPlugboxes = systemResult.plugboxResults.sorted(by: { $0.key < $1.key })
        
        for (plugboxName, plugboxResult) in sortedPlugboxes {
            // Check if we have enough space for this plugbox table
            let tableHeight: CGFloat = 180
            if currentY - tableHeight < margin + 50 {
                // Add continuation note if not all plugboxes fit
                if plugboxName != sortedPlugboxes.last?.key {
                    drawHighQualityText(context: context, text: "", rect: CGRect(x: margin, y: currentY - 20, width: pageRect.width - 2 * margin, height: 15), fontSize: 10, bold: false, centered: false)
                }
                break
            }
            
            // Plugbox header with more spacing
            drawHighQualityText(context: context, text: "Plugbox \(plugboxName)", rect: CGRect(x: margin, y: currentY - 30, width: pageRect.width - 2 * margin, height: 15), fontSize: 12, bold: true, centered: false)
            
            // Table header - increased spacing from 40 to 60
            let tableStartY = currentY - 60
            let columnWidth = (pageRect.width - 2 * margin) / 4
            let rowHeight: CGFloat = 20
            
            // Header row
            drawTableCell(context: context, text: "Channel", rect: CGRect(x: margin, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
            drawTableCell(context: context, text: "Leistung (W)", rect: CGRect(x: margin + columnWidth, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
            drawTableCell(context: context, text: "Strom (A)", rect: CGRect(x: margin + 2 * columnWidth, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
            drawTableCell(context: context, text: "Status", rect: CGRect(x: margin + 3 * columnWidth, y: tableStartY, width: columnWidth, height: rowHeight), isHeader: true)
            
            // Data rows
            for channel in 1...6 {
                let power = plugboxResult.channelPowers[channel] ?? 0
                let current = plugboxResult.channelCurrents[channel] ?? 0
                let maxChannelCurrent = systemResult.channelMaxCurrents[channel] ?? 16
                
                let rowY = tableStartY - CGFloat(channel) * rowHeight
                
                let loadPercentage = current / maxChannelCurrent
                var statusText = "Normal"
                var cellColor: (red: CGFloat, green: CGFloat, blue: CGFloat) = (0.95, 0.95, 0.95)
                
                if power > 0 {
                    if loadPercentage > 0.9 {
                        statusText = "KRITISCH"
                        cellColor = (1.0, 0.8, 0.8)  // Red for critical
                    } else if loadPercentage > 0.7 {
                        statusText = "Hoch"
                        cellColor = (1.0, 0.9, 0.8)  // Orange for high
                    } else {
                        cellColor = (0.85, 0.95, 0.85)  // Green for normal
                    }
                }
                
                drawTableCell(context: context, text: "Ch.\(channel)", rect: CGRect(x: margin, y: rowY, width: columnWidth, height: rowHeight), isHeader: false, bgColor: cellColor)
                drawTableCell(context: context, text: "\(String(format: "%.2f", power)) W", rect: CGRect(x: margin + columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false, bgColor: cellColor)
                drawTableCell(context: context, text: "\(String(format: "%.2f", current)) A", rect: CGRect(x: margin + 2 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false, bgColor: cellColor)
                drawTableCell(context: context, text: statusText, rect: CGRect(x: margin + 3 * columnWidth, y: rowY, width: columnWidth, height: rowHeight), isHeader: false, bgColor: cellColor)
            }
            
            // Increased spacing between tables from 200 to 220
            currentY -= 220
        }
        
        // Page number
        drawHighQualityText(context: context, text: "Seite \(pageNumber) von \(totalPages)", rect: CGRect(x: pageRect.width - 100, y: 20, width: 80, height: 15), fontSize: 10, bold: false, centered: true)
        
        context.restoreGState()
    }
    
    private func drawSystemPhaseDistributionPage(context: CGContext, systemName: String, systemResult: SystemPowerResult, projectName: String, voltage: Double, simultaneityFactor: Double, pageRect: CGRect, pageNumber: Int, totalPages: Int, companyLogo: NSImage?) {
        context.saveGState()
        
        // Logo
        if let logo = companyLogo {
            let logoAreaRect = CGRect(x: pageRect.width - 150, y: pageRect.height - 40, width: 130, height: 30)
            let actualLogoRect = calculateLogoRect(logo: logo, availableRect: logoAreaRect)
            if let cgImage = logo.cgImage(forProposedRect: nil, context: nil, hints: nil) {
                context.draw(cgImage, in: actualLogoRect)
            }
        }
        
        // Header
        drawHighQualityText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 30, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: true, centered: false)
        
        drawHighQualityText(context: context, text: "System \(systemName) - Phasenverteilung", rect: CGRect(x: margin, y: pageRect.height - 55, width: pageRect.width - 2 * margin, height: 20), fontSize: 16, bold: true, centered: false)
        
        let infoText = "Spannung: \(String(format: "%.0f", voltage)) V  •  Gleichzeitigkeitsfaktor: \(String(format: "%.2f", simultaneityFactor))  •  Max. Strom: \(String(format: "%.1f", systemResult.maxCurrent))A"
        drawHighQualityText(context: context, text: infoText, rect: CGRect(x: margin, y: pageRect.height - 75, width: pageRect.width - 2 * margin, height: 15), fontSize: 10, bold: false, centered: false)
        
        // Phase Distribution Table - moved up more to center it better
        let tableStartY = pageRect.height - 200
        let phaseColumnWidth = (pageRect.width - 2 * margin) / 3
        let rowHeight: CGFloat = 35
        
        // Table Title - moved up
        drawHighQualityText(context: context, text: "Phasenverteilung", rect: CGRect(x: margin, y: tableStartY + 60, width: pageRect.width - 2 * margin, height: 30), fontSize: 20, bold: true, centered: true)
        
        // Header row
        drawTableCell(context: context, text: "Phase", rect: CGRect(x: margin, y: tableStartY, width: phaseColumnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Gesamtleistung (W)", rect: CGRect(x: margin + phaseColumnWidth, y: tableStartY, width: phaseColumnWidth, height: rowHeight), isHeader: true)
        drawTableCell(context: context, text: "Strom (A)", rect: CGRect(x: margin + 2 * phaseColumnWidth, y: tableStartY, width: phaseColumnWidth, height: rowHeight), isHeader: true)
        
        // Data rows
        for phase in 1...3 {
            let power = systemResult.phasePowers[phase] ?? 0
            let current = systemResult.phaseTotals[phase] ?? 0
            let rowY = tableStartY - CGFloat(phase) * rowHeight
            
            let loadPercentage = current / systemResult.maxCurrent
            var cellColor: (red: CGFloat, green: CGFloat, blue: CGFloat) = (0.9, 0.9, 0.9)
            
            if loadPercentage > 0.9 {
                cellColor = (1.0, 0.8, 0.8)  
            } else if loadPercentage > 0.7 {
                cellColor = (1.0, 0.9, 0.8)  
            } else if power > 0 {
                cellColor = (0.85, 0.95, 0.85)  
            }
            
            let phaseText = "Phase \(phase) (Ch.\(phase == 1 ? "1 & 4" : phase == 2 ? "2 & 5" : "3 & 6"))"
            drawTableCell(context: context, text: phaseText, rect: CGRect(x: margin, y: rowY, width: phaseColumnWidth, height: rowHeight), isHeader: false, bgColor: cellColor)
            drawTableCell(context: context, text: "\(String(format: "%.2f", power)) W", rect: CGRect(x: margin + phaseColumnWidth, y: rowY, width: phaseColumnWidth, height: rowHeight), isHeader: false, bgColor: cellColor)
            drawTableCell(context: context, text: "\(String(format: "%.2f", current)) A", rect: CGRect(x: margin + 2 * phaseColumnWidth, y: rowY, width: phaseColumnWidth, height: rowHeight), isHeader: false, bgColor: cellColor)
        }
        
        // Status Legend - moved much further down to avoid overlap
        let legendStartY = tableStartY - 4 * rowHeight - 80
        drawHighQualityText(context: context, text: "", rect: CGRect(x: margin, y: legendStartY, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true, centered: false)
        
        let legendY = legendStartY - 40
        
        // Draw color indicator for each phase with more spacing
        for phase in 1...3 {
            let current = systemResult.phaseTotals[phase] ?? 0
            let power = systemResult.phasePowers[phase] ?? 0
            let loadPercentage = current / systemResult.maxCurrent
            
            var fillColor = (red: 0.2, green: 0.8, blue: 0.2) // Green
            var statusText = "Normal (\(Int(loadPercentage * 100))%)"
            
            if loadPercentage > 0.9 {
                fillColor = (red: 0.9, green: 0.2, blue: 0.2) // Red
                statusText = "KRITISCH (\(Int(loadPercentage * 100))%)"
            } else if loadPercentage > 0.7 {
                fillColor = (red: 0.9, green: 0.6, blue: 0.2) // Orange
                statusText = "Hoch (\(Int(loadPercentage * 100))%)"
            }
            
            let warningText = current > systemResult.maxCurrent ? " ⚠️ ÜBERLAST" : ""
            
            // Draw color indicator with the correct color
            let colorRect = CGRect(x: margin, y: legendY + CGFloat(phase-1)*30, width: 20, height: 20)
            context.setFillColor(red: fillColor.red, green: fillColor.green, blue: fillColor.blue, alpha: 1.0)
            context.fill(colorRect)
            context.setStrokeColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1.0)
            context.stroke(colorRect)
            
            // Add text with load status
            let phaseText = "Phase \(phase): \(String(format: "%.2f", current))A (\(String(format: "%.0f", power))W) - \(statusText)\(warningText)"
            drawHighQualityText(context: context, text: phaseText, rect: CGRect(x: margin + 25, y: legendY + CGFloat(phase-1)*30 - 2, width: pageRect.width - margin - 25, height: 20), fontSize: 13, bold: false, centered: false)
        }
        
        // System maximum information - moved down
        let maxInfoY = legendY - 120
        drawHighQualityText(context: context, text: "Maximale Stromstärke: \(String(format: "%.1f", systemResult.maxCurrent))A", rect: CGRect(x: margin, y: maxInfoY, width: pageRect.width - 2 * margin, height: 18), fontSize: 14, bold: true, centered: false)
        
        // Page number
        drawHighQualityText(context: context, text: "Seite \(pageNumber) von \(totalPages)", rect: CGRect(x: pageRect.width - 100, y: 20, width: 80, height: 15), fontSize: 10, bold: false, centered: true)
        
        context.restoreGState()
    }
    
    private func drawSystemChartPage(context: CGContext, systemName: String, systemResult: SystemPowerResult, projectName: String, voltage: Double, pageRect: CGRect, pageNumber: Int, totalPages: Int, companyLogo: NSImage?) {
        context.saveGState()
        
        // Logo
        if let logo = companyLogo {
            let logoAreaRect = CGRect(x: pageRect.width - 150, y: pageRect.height - 40, width: 130, height: 30)
            let actualLogoRect = calculateLogoRect(logo: logo, availableRect: logoAreaRect)
            if let cgImage = logo.cgImage(forProposedRect: nil, context: nil, hints: nil) {
                context.draw(cgImage, in: actualLogoRect)
            }
        }
        
        // Header
        drawHighQualityText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 30, width: pageRect.width - 2 * margin, height: 20), fontSize: 12, bold: true, centered: false)
        
        drawHighQualityText(context: context, text: "System \(systemName) - Phasenverteilung", rect: CGRect(x: margin, y: pageRect.height - 55, width: pageRect.width - 2 * margin, height: 20), fontSize: 16, bold: true, centered: false)
        
        // Maximum current information
        drawHighQualityText(context: context, text: "Maximale Stromstärke: \(String(format: "%.1f", systemResult.maxCurrent))A", rect: CGRect(x: margin, y: pageRect.height - 85, width: pageRect.width - 2 * margin, height: 15), fontSize: 12, bold: true, centered: false)
        
        // Draw a bar chart - moved up to avoid overlap
        let chartRect = CGRect(x: margin + 50, y: pageRect.height - 450, width: pageRect.width - 2 * margin - 100, height: 280)
        drawPhaseChart(context: context, systemResult: systemResult, chartRect: chartRect)
        
        // Legend and status - moved down with more space
        drawChartLegend(context: context, systemResult: systemResult, legendRect: CGRect(x: margin, y: pageRect.height - 650, width: pageRect.width - 2 * margin, height: 120))
        
        // Page number
        drawHighQualityText(context: context, text: "Seite \(pageNumber) von \(totalPages)", rect: CGRect(x: pageRect.width - 100, y: 20, width: 80, height: 15), fontSize: 10, bold: false, centered: true)
        
        context.restoreGState()
    }
    
    private func drawPhaseChart(context: CGContext, systemResult: SystemPowerResult, chartRect: CGRect) {
        // Draw chart background
        context.setFillColor(red: 0.98, green: 0.98, blue: 0.98, alpha: 1.0)
        context.fill(chartRect)
        context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
        context.stroke(chartRect)
        
        // Find max power for scaling
        let maxPower = systemResult.phasePowers.values.max() ?? 1000
        let scaleFactor = chartRect.height * 0.8 / maxPower
        
        // Draw bars
        let barWidth = chartRect.width / 6
        let barSpacing = chartRect.width / 3
        
        for phase in 1...3 {
            let power = systemResult.phasePowers[phase] ?? 0
            let current = systemResult.phaseTotals[phase] ?? 0
            let barHeight = power * scaleFactor
            
            let barX = chartRect.minX + CGFloat(phase - 1) * barSpacing + barSpacing / 2 - barWidth / 2
            let barY = chartRect.minY + 20
            let barRect = CGRect(x: barX, y: barY, width: barWidth, height: barHeight)
            
            // Color based on load
            let loadPercentage = current / systemResult.maxCurrent
            var fillColor: (red: CGFloat, green: CGFloat, blue: CGFloat)
            if loadPercentage > 0.9 {
                fillColor = (red: 0.9, green: 0.2, blue: 0.2) // Red
            } else if loadPercentage > 0.7 {
                fillColor = (red: 0.9, green: 0.6, blue: 0.2) // Orange
            } else {
                fillColor = (red: 0.2, green: 0.8, blue: 0.2) // Green
            }
            
            context.setFillColor(red: fillColor.red, green: fillColor.green, blue: fillColor.blue, alpha: 1.0)
            context.fill(barRect)
            context.setStrokeColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1.0)
            context.stroke(barRect)
            
            // Labels
            drawHighQualityText(context: context, text: "Phase \(phase)", rect: CGRect(x: barX - 20, y: barY - 15, width: barWidth + 40, height: 12), fontSize: 10, bold: false, centered: true)
            drawHighQualityText(context: context, text: "\(String(format: "%.0f", power))W", rect: CGRect(x: barX - 20, y: barY + barHeight + 5, width: barWidth + 40, height: 12), fontSize: 10, bold: true, centered: true)
            drawHighQualityText(context: context, text: "\(String(format: "%.2f", current))A", rect: CGRect(x: barX - 20, y: barY + barHeight + 20, width: barWidth + 40, height: 12), fontSize: 10, bold: false, centered: true)
        }
    }
    
    private func drawChartLegend(context: CGContext, systemResult: SystemPowerResult, legendRect: CGRect) {
        drawHighQualityText(context: context, text: "", rect: CGRect(x: legendRect.minX, y: legendRect.maxY - 25, width: legendRect.width, height: 20), fontSize: 14, bold: true, centered: false)
        
        let legendY = legendRect.maxY - 50
        
        // Draw status indicators for each phase with more spacing
        for phase in 1...3 {
            let current = systemResult.phaseTotals[phase] ?? 0
            let power = systemResult.phasePowers[phase] ?? 0
            let loadPercentage = current / systemResult.maxCurrent
            
            var fillColor = (red: 0.2, green: 0.8, blue: 0.2) // Green
            var statusText = "Normal (\(Int(loadPercentage * 100))%)"
            
            if loadPercentage > 0.9 {
                fillColor = (red: 0.9, green: 0.2, blue: 0.2) // Red
                statusText = "KRITISCH (\(Int(loadPercentage * 100))%)"
            } else if loadPercentage > 0.7 {
                fillColor = (red: 0.9, green: 0.6, blue: 0.2) // Orange
                statusText = "Hoch (\(Int(loadPercentage * 100))%)"
            }
            
            let warningText = current > systemResult.maxCurrent ? " ⚠️ ÜBERLAST" : ""
            
            // Draw color indicator with the correct color
            let colorRect = CGRect(x: legendRect.minX, y: legendY + CGFloat(phase-1)*30, width: 15, height: 15)
            context.setFillColor(red: fillColor.red, green: fillColor.green, blue: fillColor.blue, alpha: 1.0)
            context.fill(colorRect)
            context.setStrokeColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1.0)
            context.stroke(colorRect)
            
            // Add text with load status
            let phaseText = "Phase \(phase): \(String(format: "%.2f", current))A (\(String(format: "%.0f", power))W) - \(statusText)\(warningText)"
            drawHighQualityText(context: context, text: phaseText, rect: CGRect(x: legendRect.minX + 20, y: legendY + CGFloat(phase-1)*30 - 2, width: legendRect.width - 20, height: 15), fontSize: 12, bold: false, centered: false)
        }
    }
    
    private func drawTableCell(context: CGContext, text: String, rect: CGRect, isHeader: Bool, bgColor: (red: CGFloat, green: CGFloat, blue: CGFloat) = (0.9, 0.9, 0.9)) {
        // Background
        if isHeader {
            context.setFillColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1.0)
        } else {
            context.setFillColor(red: bgColor.red, green: bgColor.green, blue: bgColor.blue, alpha: 1.0)
        }
        context.fill(rect)
        
        // Border
        context.setStrokeColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1.0)
        context.setLineWidth(0.5)
        context.stroke(rect)
        
        // Text
        drawHighQualityText(context: context, text: text, rect: rect.insetBy(dx: 4, dy: 2), fontSize: isHeader ? 10 : 9, bold: isHeader, centered: true)
    }
    
    private func drawHighQualityText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool, centered: Bool) {
        context.saveGState()
        
        // Set ultra-high-quality rendering options
        context.setAllowsAntialiasing(true)
        context.setShouldAntialias(true)
        context.interpolationQuality = .high
        context.setRenderingIntent(.defaultIntent)
        context.setShouldSubpixelPositionFonts(true)
        context.setShouldSubpixelQuantizeFonts(true)
        
        // Create font with higher resolution
        let actualFontSize = fontSize * 1.2  // Increase font size for better quality
        let fontName = bold ? "Helvetica-Bold" : "Helvetica"
        let font = CTFontCreateWithName(fontName as CFString, actualFontSize, nil)
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = centered ? .center : .left
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black,
            .paragraphStyle: paragraphStyle
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        
        // Create CTLine for Core Text rendering
        let line = CTLineCreateWithAttributedString(attributedString)
        
        // Calculate text metrics
        let textBounds = CTLineGetBoundsWithOptions(line, .useOpticalBounds)
        let textWidth = textBounds.width
        let textHeight = textBounds.height
        
        // Calculate position based on alignment
        var x = rect.minX + 4
        if centered {
            x = rect.minX + (rect.width - textWidth) / 2
        }
        
        let y = rect.minY + (rect.height - textHeight) / 2
        
        // Set text position correctly for PDF coordinate system
        context.textMatrix = .identity
        context.textPosition = CGPoint(x: x, y: y)
        
        // Draw the text with Core Text for maximum quality
        CTLineDraw(line, context)
        
        context.restoreGState()
    }
    
    private func calculateLogoRect(logo: NSImage, availableRect: CGRect) -> CGRect {
        let logoSize = logo.size
        let logoAspectRatio = logoSize.width / logoSize.height
        let availableAspectRatio = availableRect.width / availableRect.height
        
        var logoRect: CGRect
        
        if logoAspectRatio > availableAspectRatio {
            // Logo is wider than available space - fit to width
            let scaledHeight = availableRect.width / logoAspectRatio
            logoRect = CGRect(
                x: availableRect.minX,
                y: availableRect.minY + (availableRect.height - scaledHeight) / 2,
                width: availableRect.width,
                height: scaledHeight
            )
        } else {
            // Logo is taller than available space - fit to height
            let scaledWidth = availableRect.height * logoAspectRatio
            logoRect = CGRect(
                x: availableRect.minX + (availableRect.width - scaledWidth) / 2,
                y: availableRect.minY,
                width: scaledWidth,
                height: availableRect.height
            )
        }
        
        return logoRect
    }
}
