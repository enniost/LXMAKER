import SwiftUI
import SwiftData
import AppKit

struct SystemOverviewView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedSystemColumn = ""
    @State private var selectedPlugboxColumn = ""
    @State private var selectedChannelColumn = ""
    @State private var logoOption: LogoOption = .none
    @State private var uploadedLogoData: Data? = nil
    @State private var showLogoImporter = false
    @State private var showAddDistributorDialog = false
    @State private var showAddPlugboxDialog = false
    @State private var showSystemManagementDialog = false
    @State private var newDistributorName = ""
    @State private var newDistributorType = ""
    @State private var newPlugboxName = ""
    @State private var newPlugboxSystem = ""
    @State private var newPlugboxPosition = ""
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canGenerate: Bool {
        !selectedSystemColumn.isEmpty && !selectedPlugboxColumn.isEmpty
    }
    
    private var systemData: [String: [PlugboxData]] {
        guard !selectedSystemColumn.isEmpty && !selectedPlugboxColumn.isEmpty else { return [:] }
        
        var systems: [String: [PlugboxData]] = [:]
        
        // CSV-basierte Plugboxen
        for fixture in project.fixtures {
            guard let systemName = fixture.rawData[selectedSystemColumn],
                  let plugboxName = fixture.rawData[selectedPlugboxColumn],
                  !systemName.isEmpty && !plugboxName.isEmpty else { continue }
            
            let channels = 6 // Immer 6 Kanäle als Standard
            let plugboxData = PlugboxData(name: plugboxName, channels: channels, position: "", isCustom: false)
            
            if systems[systemName] == nil {
                systems[systemName] = []
            }
            
            // Nur hinzufügen wenn noch nicht vorhanden
            if !systems[systemName]!.contains(where: { $0.name == plugboxName }) {
                systems[systemName]!.append(plugboxData)
            }
        }
        
        // Custom Plugboxen hinzufügen
        for customPlugbox in project.customPlugboxes {
            let plugboxData = PlugboxData(
                name: customPlugbox.name,
                channels: customPlugbox.channels,
                position: customPlugbox.position,
                isCustom: true
            )
            
            if systems[customPlugbox.systemName] == nil {
                systems[customPlugbox.systemName] = []
            }
            
            if !systems[customPlugbox.systemName]!.contains(where: { $0.name == customPlugbox.name }) {
                systems[customPlugbox.systemName]!.append(plugboxData)
            }
        }
        
        // Sortiere Plugboxen pro System
        for systemName in systems.keys {
            systems[systemName]?.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        }
        
        return systems
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text("System-Übersicht")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Erstellt PDF-Übersichten aller Plugboxen pro elektrisches System")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        if availableColumns.isEmpty {
                            Text("⚠️ Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // CSV Column Selection
                            csvColumnSelectionView
                            
                            // Custom Management
                            customManagementView
                            
                            // Logo Settings
                            logoSettingsView
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Preview
                        VStack(alignment: .leading, spacing: 20) {
                            if !systemData.isEmpty {
                                systemPreviewView
                            } else {
                                VStack(alignment: .leading, spacing: 15) {
                                    Text("Anleitung:")
                                        .font(.headline)
                                        .fontWeight(.medium)
                                    
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text("• Wählen Sie die System-Spalte aus der CSV")
                                        Text("• Wählen Sie die Plugbox-Spalte aus der CSV")
                                        Text("• Optional: Wählen Sie die Kanal-Spalte")
                                        Text("• Verwalten Sie Stromverteiler und Systeme")
                                        Text("• Optional: Fügen Sie eigene Plugboxen hinzu")
                                        Text("• Exportieren Sie als PDF")
                                    }
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                    
                                    Spacer()
                                }
                                .padding(15)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Export Button
                    if canGenerate {
                        Button("PDF exportieren") {
                            exportPDF()
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                        .padding(.bottom, 20)
                    }
                }
                .padding(20)
            }
            .navigationTitle("System-Übersicht")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        saveSettings()
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1400, minHeight: 800)
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
            .sheet(isPresented: $showAddDistributorDialog) {
                AddDistributorDialog(
                    distributorName: $newDistributorName,
                    distributorType: $newDistributorType,
                    onAdd: addCustomDistributor,
                    onCancel: { showAddDistributorDialog = false }
                )
            }
            .sheet(isPresented: $showAddPlugboxDialog) {
                AddPlugboxDialog(
                    plugboxName: $newPlugboxName,
                    systemName: $newPlugboxSystem,
                    position: $newPlugboxPosition,
                    availableSystems: getAllAvailableSystems(),
                    onAdd: addCustomPlugbox,
                    onCancel: { showAddPlugboxDialog = false }
                )
            }
            .sheet(isPresented: $showSystemManagementDialog) {
                SystemManagementDialog(
                    project: project,
                    modelContext: modelContext,
                    systemData: systemData
                )
            }
            .onAppear {
                initializeDefaultPowerDistributors()
                loadSettings()
                autoAssignColumns()
            }
        }
    }
    
    private var csvColumnSelectionView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("CSV-Spalten auswählen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                HStack {
                    Text("System:")
                        .frame(width: 80, alignment: .leading)
                    Picker("", selection: $selectedSystemColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                    .onChange(of: selectedSystemColumn) { _, _ in
                        saveSettings()
                    }
                }
                
                HStack {
                    Text("Plugbox:")
                        .frame(width: 80, alignment: .leading)
                    Picker("", selection: $selectedPlugboxColumn) {
                        Text("-- Auswählen --").tag("")
                        ForEach(availableColumns, id: \.self) { column in
                            Text(column).tag(column)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                    .onChange(of: selectedPlugboxColumn) { _, _ in
                        saveSettings()
                    }
                }
            }
            
            Text("System und Plugbox sind erforderlich.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(15)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var customManagementView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Verwaltung:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 8) {
                Button("Systeme & Stromverteiler verwalten") {
                    showSystemManagementDialog = true
                }
                .buttonStyle(.bordered)
                .frame(maxWidth: .infinity)
                
                Button("Stromverteiler hinzufügen") {
                    showAddDistributorDialog = true
                }
                .buttonStyle(.bordered)
                .frame(maxWidth: .infinity)
                
                Button("Custom Plugbox hinzufügen") {
                    showAddPlugboxDialog = true
                }
                .buttonStyle(.bordered)
                .frame(maxWidth: .infinity)
            }
            
            Text("Verwalten Sie Stromverteiler-Typen und erstellen Sie eigene Plugboxen.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(15)
        .background(Color.green.opacity(0.1))
        .cornerRadius(10)
    }
    
    private var systemPreviewView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Gefundene Systeme:")
                .font(.headline)
                .fontWeight(.medium)
            
            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(Array(systemData.keys).sorted(), id: \.self) { systemName in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(systemName)
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                
                                Spacer()
                                
                                Text("\(systemData[systemName]?.count ?? 0) Plugboxen")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            
                            if let plugboxes = systemData[systemName] {
                                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 4) {
                                    ForEach(plugboxes.prefix(6), id: \.name) { plugbox in
                                        Text(plugbox.name)
                                            .font(.caption)
                                            .padding(.horizontal, 6)
                                            .padding(.vertical, 2)
                                            .background(Color.blue.opacity(0.2))
                                            .cornerRadius(4)
                                    }
                                }
                                
                                if plugboxes.count > 6 {
                                    Text("... und \(plugboxes.count - 6) weitere")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                        .padding(12)
                        .background(Color.gray.opacity(0.05))
                        .cornerRadius(8)
                    }
                }
            }
            .frame(maxHeight: 400)
        }
        .padding(15)
        .background(Color.gray.opacity(0.05))
        .cornerRadius(10)
    }
    
    private var logoSettingsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Logo-Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                Picker("Logo-Option", selection: $logoOption) {
                    ForEach(LogoOption.allCases, id: \.self) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: logoOption) { _, _ in
                    if logoOption != .upload {
                        uploadedLogoData = nil
                    }
                }
                
                if logoOption == .upload {
                    HStack {
                        Button("Logo auswählen") {
                            showLogoImporter = true
                        }
                        .buttonStyle(.bordered)
                        
                        if uploadedLogoData != nil {
                            Button("Logo entfernen") {
                                uploadedLogoData = nil
                            }
                            .buttonStyle(.bordered)
                            .foregroundColor(.red)
                        }
                    }
                }
                
                // Logo Preview
                if logoOption == .upload {
                    if let logoData = uploadedLogoData, let nsImage = NSImage(data: logoData) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Logo-Vorschau:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                } else if logoOption == .habegger {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logo-Vorschau:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        if let logoData = createHabeggerLogoData(), let nsImage = NSImage(data: logoData) {
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                }
            }
        }
        .padding(15)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(10)
    }
    
    private func addCustomDistributor() {
        guard !newDistributorName.isEmpty && !newDistributorType.isEmpty else { return }
        
        let distributor = PowerDistributor(name: newDistributorName, type: newDistributorType, isCustom: true)
        project.powerDistributors.append(distributor)
        modelContext.insert(distributor)
        
        do {
            try modelContext.save()
            newDistributorName = ""
            newDistributorType = ""
            showAddDistributorDialog = false
        } catch {
            print("Failed to save distributor: \(error)")
        }
    }
    
    private func addCustomPlugbox() {
        guard !newPlugboxName.isEmpty && !newPlugboxSystem.isEmpty else { return }
        
        let plugbox = CustomPlugbox(
            name: newPlugboxName,
            systemName: newPlugboxSystem,
            channels: 6, // Fest auf 6 Kanäle
            position: newPlugboxPosition
        )
        project.customPlugboxes.append(plugbox)
        modelContext.insert(plugbox)
        
        do {
            try modelContext.save()
            newPlugboxName = ""
            newPlugboxSystem = ""
            newPlugboxPosition = ""
            showAddPlugboxDialog = false
        } catch {
            print("Failed to save plugbox: \(error)")
        }
    }
    
    private func exportPDF() {
        guard !systemData.isEmpty else { return }
        
        var logoData: Data? = nil
        switch logoOption {
        case .none:
            logoData = nil
        case .upload:
            logoData = uploadedLogoData
        case .habegger:
            logoData = createHabeggerLogoData()
        }
        
        let pdfCreator = SystemOverviewPDFCreator()
        let pdfData = pdfCreator.createSystemOverviewPDF(
            projectName: project.name,
            projectNumber: project.projectNumber,
            systemData: systemData,
            electricalSystems: project.electricalSystems,
            powerDistributors: project.powerDistributors,
            logoData: logoData
        )
        
        let filename = "System_Uebersicht_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die System-Übersicht wurde erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                uploadedLogoData = try Data(contentsOf: url)
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func createHabeggerLogoData() -> Data? {
        // Versuche zuerst das Asset-Logo zu laden
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            guard let tiffData = assetLogo.tiffRepresentation,
                  let bitmapRep = NSBitmapImageRep(data: tiffData),
                  let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
                return nil
            }
            return pngData
        }
        
        // Fallback: Programmatisch erzeugtes Logo
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        guard let tiffData = image.tiffRepresentation,
              let bitmapRep = NSBitmapImageRep(data: tiffData),
              let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
            return nil
        }
        
        return pngData
    }
    
    private func initializeDefaultPowerDistributors() {
        // Prüfe ob bereits Standard-Stromverteiler vorhanden sind
        let hasDefaultDistributors = project.powerDistributors.contains { !$0.isCustom }
        
        if !hasDefaultDistributors {
            let defaultDistributors = [
                ("CEE 16/Schuko", "CEE 16A mit Schuko-Ausgängen"),
                ("CEE 32/CEE", "CEE 32A mit CEE-Ausgängen"), 
                ("CEE 32/ML", "CEE 32A mit Multicore-Ausgängen"),
                ("CEE 63/CEE", "CEE 63A mit CEE-Ausgängen"),
                ("CEE 63/ML", "CEE 63A mit Multicore-Ausgängen"),
                ("CEE 125/CEE", "CEE 125A mit CEE-Ausgängen"),
                ("CEE 125/ML", "CEE 125A mit Multicore-Ausgängen"),
                ("PL400/CEE", "PL400 mit CEE-Ausgängen"),
                ("PL400/ML", "PL400 mit Multicore-Ausgängen")
            ]
            
            for (type, name) in defaultDistributors {
                let distributor = PowerDistributor(name: name, type: type, isCustom: false)
                project.powerDistributors.append(distributor)
                modelContext.insert(distributor)
            }
            
            do {
                try modelContext.save()
            } catch {
                print("Failed to initialize default power distributors: \(error)")
            }
        }
    }
    
    private func loadSettings() {
        selectedSystemColumn = project.systemOverviewSystemColumn ?? ""
        selectedPlugboxColumn = project.systemOverviewPlugboxColumn ?? ""
    }
    
    private func saveSettings() {
        project.systemOverviewSystemColumn = selectedSystemColumn.isEmpty ? nil : selectedSystemColumn
        project.systemOverviewPlugboxColumn = selectedPlugboxColumn.isEmpty ? nil : selectedPlugboxColumn
        project.updatedAt = Date()
        
        do {
            try modelContext.save()
        } catch {
            print("Failed to save System Overview settings: \(error)")
        }
    }
    
    private func autoAssignColumns() {
        guard selectedSystemColumn.isEmpty || selectedPlugboxColumn.isEmpty else { return }
        
        let keywordMappings = [
            "system": ["system", "sys", "gruppe", "group", "circuit", "stromkreis"],
            "plugbox": ["plugbox", "box", "steckdose", "plug", "socket", "dose", "verteiler", "multicore", "mc"]
        ]
        
        for column in availableColumns {
            let columnLower = column.lowercased()
            
            if selectedSystemColumn.isEmpty {
                if let keywords = keywordMappings["system"],
                   keywords.contains(where: { columnLower.contains($0) }) {
                    selectedSystemColumn = column
                }
            }
            
            if selectedPlugboxColumn.isEmpty {
                if let keywords = keywordMappings["plugbox"],
                   keywords.contains(where: { columnLower.contains($0) }) {
                    selectedPlugboxColumn = column
                }
            }
        }
        
        if !selectedSystemColumn.isEmpty || !selectedPlugboxColumn.isEmpty {
            saveSettings()
        }
    }
    
    private func getAllAvailableSystems() -> [String] {
        var allSystems = Set<String>()
        
        allSystems.formUnion(Array(systemData.keys))
        
        for system in project.electricalSystems {
            allSystems.insert(system.name)
        }
        
        return Array(allSystems).sorted()
    }
}

// MARK: - Supporting Views
struct AddDistributorDialog: View {
    @Binding var distributorName: String
    @Binding var distributorType: String
    let onAdd: () -> Void
    let onCancel: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Neuen Stromverteiler hinzufügen")
                .font(.headline)
            
            VStack(spacing: 12) {
                TextField("Name", text: $distributorName)
                    .textFieldStyle(.roundedBorder)
                
                TextField("Typ (z.B. CEE 32/CEE)", text: $distributorType)
                    .textFieldStyle(.roundedBorder)
            }
            
            HStack {
                Button("Abbrechen") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                
                Button("Hinzufügen") {
                    onAdd()
                }
                .buttonStyle(.bordered)
                .disabled(distributorName.isEmpty || distributorType.isEmpty)
            }
        }
        .padding()
        .frame(width: 400)
    }
}

struct AddPlugboxDialog: View {
    @Binding var plugboxName: String
    @Binding var systemName: String
    @Binding var position: String
    let availableSystems: [String]
    let onAdd: () -> Void
    let onCancel: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Neue Plugbox hinzufügen")
                .font(.headline)
            
            VStack(spacing: 12) {
                TextField("Plugbox Name", text: $plugboxName)
                    .textFieldStyle(.roundedBorder)
                
                HStack {
                    Text("System:")
                        .frame(width: 80, alignment: .leading)
                    
                    if availableSystems.isEmpty {
                        TextField("System Name", text: $systemName)
                            .textFieldStyle(.roundedBorder)
                    } else {
                        Menu(systemName.isEmpty ? "System auswählen" : systemName) {
                            ForEach(availableSystems, id: \.self) { system in
                                Button(system) {
                                    systemName = system
                                }
                            }
                            
                            Divider()
                            
                            Button("Neues System...") {
                                systemName = ""
                            }
                        }
                        .frame(maxWidth: .infinity)
                        
                        if systemName.isEmpty || !availableSystems.contains(systemName) {
                            TextField("Neuer System Name", text: $systemName)
                                .textFieldStyle(.roundedBorder)
                        }
                    }
                }
                
                TextField("Position (optional)", text: $position)
                    .textFieldStyle(.roundedBorder)
                
                Text("Alle Plugboxen haben standardmäßig 6 Kanäle")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            HStack {
                Button("Abbrechen") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                
                Button("Hinzufügen") {
                    onAdd()
                }
                .buttonStyle(.bordered)
                .disabled(plugboxName.isEmpty || systemName.isEmpty)
            }
        }
        .padding()
        .frame(width: 400)
    }
}

struct SystemManagementDialog: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    let systemData: [String: [PlugboxData]]
    @Environment(\.dismiss) private var dismiss
    
    @State private var showAddSystemDialog = false
    @State private var newSystemName = ""
    @State private var newSystemPosition = ""
    @State private var selectedDistributorId = ""
    @State private var showDistributorSelectionDialog = false
    @State private var systemForDistributorAssignment: ElectricalSystem?
    @State private var csvSystemForDistributorAssignment: String?
    @State private var showDeleteConfirmation = false
    @State private var systemToDelete: ElectricalSystem?
    @State private var showEditSystemDialog = false
    @State private var systemToEdit: ElectricalSystem?
    @State private var csvSystemToEdit: String?
    @State private var editSystemName = ""
    @State private var editSystemPosition = ""
    @State private var editSelectedDistributorId = ""
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Systems Section
                VStack(alignment: .leading, spacing: 12) {
                    Text("Elektrische Systeme:")
                        .font(.headline)
                        .fontWeight(.medium)
                    
                    if project.electricalSystems.isEmpty && systemData.isEmpty {
                        Text("Keine Systeme vorhanden")
                            .foregroundColor(.secondary)
                            .italic()
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 8) {
                                // Systeme aus CSV-Daten
                                ForEach(Array(systemData.keys).sorted(), id: \.self) { systemName in
                                    if !project.electricalSystems.contains(where: { $0.name == systemName }) {
                                        SystemRow(
                                            systemName: systemName,
                                            position: "",
                                            distributorName: "Nicht zugewiesen",
                                            isFromCSV: true,
                                            onAssignDistributor: { 
                                                csvSystemForDistributorAssignment = systemName
                                                showDistributorSelectionDialog = true
                                            },
                                            onEdit: {
                                                csvSystemToEdit = systemName
                                                editSystemName = systemName
                                                editSystemPosition = ""
                                                editSelectedDistributorId = ""
                                                showEditSystemDialog = true
                                            },
                                            onDelete: { }
                                        )
                                    }
                                }
                                
                                // Explizit erstellte Systeme
                                ForEach(project.electricalSystems, id: \.id) { system in
                                    SystemRow(
                                        systemName: system.name,
                                        position: system.position,
                                        distributorName: getDistributorName(for: system),
                                        isFromCSV: systemData.keys.contains(system.name),
                                        onAssignDistributor: { 
                                            systemForDistributorAssignment = system
                                            showDistributorSelectionDialog = true
                                        },
                                        onEdit: {
                                            systemToEdit = system
                                            editSystemName = system.name
                                            editSystemPosition = system.position
                                            editSelectedDistributorId = system.powerDistributorId ?? ""
                                            showEditSystemDialog = true
                                        },
                                        onDelete: { 
                                            if !systemData.keys.contains(system.name) {
                                                systemToDelete = system
                                                showDeleteConfirmation = true
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        .frame(maxHeight: 300)
                    }
                    
                    Button("System hinzufügen") {
                        showAddSystemDialog = true
                    }
                    .buttonStyle(.bordered)
                }
                
                Divider()
                
                // Power Distributors Section
                VStack(alignment: .leading, spacing: 12) {
                    Text("Stromverteiler:")
                        .font(.headline)
                        .fontWeight(.medium)
                    
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(project.powerDistributors, id: \.id) { distributor in
                                DistributorRow(
                                    distributor: distributor,
                                    onDelete: distributor.isCustom ? { deleteDistributor(distributor) } : nil
                                )
                            }
                        }
                    }
                    .frame(maxHeight: 200)
                }
            }
            .padding()
            .navigationTitle("System-Verwaltung")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Fertig") {
                        dismiss()
                    }
                }
            }
            .frame(width: 600, height: 800)
            .sheet(isPresented: $showAddSystemDialog) {
                AddSystemDialog(
                    systemName: $newSystemName,
                    position: $newSystemPosition,
                    distributorId: $selectedDistributorId,
                    availableDistributors: project.powerDistributors,
                    onAdd: addSystem,
                    onCancel: { showAddSystemDialog = false }
                )
            }
            .sheet(isPresented: $showEditSystemDialog) {
                EditSystemDialog(
                    systemName: $editSystemName,
                    position: $editSystemPosition,
                    distributorId: $editSelectedDistributorId,
                    availableDistributors: project.powerDistributors,
                    isCSVSystem: csvSystemToEdit != nil,
                    onSave: saveEditedSystem,
                    onCancel: { 
                        showEditSystemDialog = false
                        systemToEdit = nil
                        csvSystemToEdit = nil
                    }
                )
            }
            .sheet(isPresented: $showDistributorSelectionDialog) {
                DistributorSelectionDialog(
                    availableDistributors: project.powerDistributors,
                    onSelect: { distributorId in
                        assignDistributor(distributorId: distributorId)
                        showDistributorSelectionDialog = false
                    },
                    onCancel: { 
                        showDistributorSelectionDialog = false
                        systemForDistributorAssignment = nil
                        csvSystemForDistributorAssignment = nil
                    }
                )
            }
            .alert("System löschen", isPresented: $showDeleteConfirmation) {
                Button("Abbrechen", role: .cancel) {
                    systemToDelete = nil
                }
                Button("Löschen", role: .destructive) {
                    if let system = systemToDelete {
                        deleteSystem(system)
                    }
                    systemToDelete = nil
                }
            } message: {
                if let system = systemToDelete {
                    Text("Möchten Sie das System '\(system.name)' wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.")
                }
            }
        }
    }
    
    private func getDistributorName(for system: ElectricalSystem) -> String {
        if let distributorId = system.powerDistributorId,
           let distributor = project.powerDistributors.first(where: { $0.id == distributorId }) {
            return distributor.name
        }
        return system.powerDistributorName.isEmpty ? "Nicht zugewiesen" : system.powerDistributorName
    }
    
    private func assignDistributor(distributorId: String) {
        guard let distributor = project.powerDistributors.first(where: { $0.id == distributorId }) else { return }
        
        if let system = systemForDistributorAssignment {
            system.powerDistributorId = distributor.id
            system.powerDistributorName = distributor.name
        } else if let csvSystemName = csvSystemForDistributorAssignment {
            let system = ElectricalSystem(name: csvSystemName, position: "", powerDistributorName: distributor.name)
            system.powerDistributorId = distributor.id
            project.electricalSystems.append(system)
            modelContext.insert(system)
        }
        
        do {
            try modelContext.save()
        } catch {
            print("Failed to assign distributor: \(error)")
        }
        
        systemForDistributorAssignment = nil
        csvSystemForDistributorAssignment = nil
    }
    
    private func saveEditedSystem() {
        if let system = systemToEdit {
            // Bearbeitung eines existierenden Systems
            system.name = editSystemName
            system.position = editSystemPosition
            
            if !editSelectedDistributorId.isEmpty,
               let distributor = project.powerDistributors.first(where: { $0.id == editSelectedDistributorId }) {
                system.powerDistributorId = distributor.id
                system.powerDistributorName = distributor.name
            } else {
                system.powerDistributorId = nil
                system.powerDistributorName = ""
            }
        } else if let csvSystemName = csvSystemToEdit {
            // Konvertierung eines CSV-Systems zu explizitem System
            let system = ElectricalSystem(name: editSystemName, position: editSystemPosition)
            
            if !editSelectedDistributorId.isEmpty,
               let distributor = project.powerDistributors.first(where: { $0.id == editSelectedDistributorId }) {
                system.powerDistributorId = distributor.id
                system.powerDistributorName = distributor.name
            }
            
            project.electricalSystems.append(system)
            modelContext.insert(system)
        }
        
        do {
            try modelContext.save()
            showEditSystemDialog = false
            systemToEdit = nil
            csvSystemToEdit = nil
        } catch {
            print("Failed to save edited system: \(error)")
        }
    }
    
    private func addSystem() {
        guard !newSystemName.isEmpty else { return }
        
        let system = ElectricalSystem(name: newSystemName, position: newSystemPosition)
        
        if !selectedDistributorId.isEmpty,
           let distributor = project.powerDistributors.first(where: { $0.id == selectedDistributorId }) {
            system.powerDistributorId = distributor.id
            system.powerDistributorName = distributor.name
        }
        
        project.electricalSystems.append(system)
        modelContext.insert(system)
        
        do {
            try modelContext.save()
            newSystemName = ""
            newSystemPosition = ""
            selectedDistributorId = ""
            showAddSystemDialog = false
        } catch {
            print("Failed to save system: \(error)")
        }
    }
    
    private func deleteSystem(_ system: ElectricalSystem) {
        guard !systemData.keys.contains(system.name) else {
            print("Cannot delete CSV-based system")
            return
        }
        
        if let index = project.electricalSystems.firstIndex(of: system) {
            project.electricalSystems.remove(at: index)
            modelContext.delete(system)
            
            do {
                try modelContext.save()
            } catch {
                print("Failed to delete system: \(error)")
            }
        }
    }
    
    private func deleteDistributor(_ distributor: PowerDistributor) {
        if let index = project.powerDistributors.firstIndex(of: distributor) {
            project.powerDistributors.remove(at: index)
            modelContext.delete(distributor)
            
            do {
                try modelContext.save()
            } catch {
                print("Failed to delete distributor: \(error)")
            }
        }
    }
}

struct SystemRow: View {
    let systemName: String
    let position: String
    let distributorName: String
    let isFromCSV: Bool
    let onAssignDistributor: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(systemName)
                        .font(.headline)
                    
                    if isFromCSV {
                        Text("(CSV)")
                            .font(.caption)
                            .foregroundColor(.blue)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(4)
                    } else {
                        Text("(Manuell)")
                            .font(.caption)
                            .foregroundColor(.green)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.green.opacity(0.1))
                            .cornerRadius(4)
                    }
                }
                
                if !position.isEmpty {
                    Text("Position: \(position)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    Text("Position: Nicht angegeben")
                        .font(.caption)
                        .foregroundColor(.orange)
                }
                
                Text("Verteiler: \(distributorName)")
                    .font(.caption)
                    .foregroundColor(distributorName == "Nicht zugewiesen" ? .red : .secondary)
            }
            
            Spacer()
            
            VStack(spacing: 4) {
                Button("Bearbeiten") {
                    onEdit()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                
                Button("Verteiler zuweisen") {
                    onAssignDistributor()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                
                Button("Löschen") {
                    onDelete()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .foregroundColor(.red)
                .disabled(isFromCSV)
            }
        }
        .padding(12)
        .background(Color.gray.opacity(0.05))
        .cornerRadius(8)
    }
}

struct DistributorRow: View {
    let distributor: PowerDistributor
    let onDelete: (() -> Void)?
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(distributor.name)
                    .font(.headline)
                
                Text("Typ: \(distributor.type)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                if distributor.isCustom {
                    Text("Benutzerdefiniert")
                        .font(.caption)
                        .foregroundColor(.green)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.green.opacity(0.1))
                        .cornerRadius(4)
                }
            }
            
            Spacer()
            
            if let onDelete = onDelete {
                Button("Löschen") {
                    onDelete()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .foregroundColor(.red)
            }
        }
        .padding(12)
        .background(Color.gray.opacity(0.05))
        .cornerRadius(8)
    }
}

struct AddSystemDialog: View {
    @Binding var systemName: String
    @Binding var position: String
    @Binding var distributorId: String
    let availableDistributors: [PowerDistributor]
    let onAdd: () -> Void
    let onCancel: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Neues System hinzufügen")
                .font(.headline)
            
            VStack(spacing: 12) {
                TextField("System Name", text: $systemName)
                    .textFieldStyle(.roundedBorder)
                
                TextField("Position (optional)", text: $position)
                    .textFieldStyle(.roundedBorder)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Stromverteiler (optional):")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Picker("Stromverteiler", selection: $distributorId) {
                        Text("-- Nicht zugewiesen --").tag("")
                        ForEach(availableDistributors, id: \.id) { distributor in
                            Text(distributor.name).tag(distributor.id)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                }
            }
            
            HStack {
                Button("Abbrechen") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                
                Button("Hinzufügen") {
                    onAdd()
                }
                .buttonStyle(.bordered)
                .disabled(systemName.isEmpty)
            }
        }
        .padding()
        .frame(width: 400)
    }
}

struct EditSystemDialog: View {
    @Binding var systemName: String
    @Binding var position: String
    @Binding var distributorId: String
    let availableDistributors: [PowerDistributor]
    let isCSVSystem: Bool
    let onSave: () -> Void
    let onCancel: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text(isCSVSystem ? "CSV-System bearbeiten" : "System bearbeiten")
                .font(.headline)
            
            VStack(spacing: 12) {
                if isCSVSystem {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("System Name:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        TextField("System Name", text: $systemName)
                            .textFieldStyle(.roundedBorder)
                            .disabled(true) // CSV-System Name kann nicht geändert werden
                            .foregroundColor(.secondary)
                        
                        Text("Name kann bei CSV-Systemen nicht geändert werden")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                } else {
                    TextField("System Name", text: $systemName)
                        .textFieldStyle(.roundedBorder)
                }
                
                TextField("Position", text: $position)
                    .textFieldStyle(.roundedBorder)
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Stromverteiler:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Picker("Stromverteiler", selection: $distributorId) {
                        Text("-- Nicht zugewiesen --").tag("")
                        ForEach(availableDistributors, id: \.id) { distributor in
                            Text(distributor.name).tag(distributor.id)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                }
            }
            
            HStack {
                Button("Abbrechen") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                
                Button("Speichern") {
                    onSave()
                }
                .buttonStyle(.borderedProminent)
                .disabled(systemName.isEmpty)
            }
        }
        .padding()
        .frame(width: 400)
    }
}

struct DistributorSelectionDialog: View {
    let availableDistributors: [PowerDistributor]
    let onSelect: (String) -> Void
    let onCancel: () -> Void
    
    @State private var selectedDistributorId = ""
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Stromverteiler auswählen")
                .font(.headline)
            
            VStack(alignment: .leading, spacing: 12) {
                Text("Wählen Sie einen Stromverteiler für dieses System:")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(availableDistributors, id: \.id) { distributor in
                            HStack {
                                Button(action: {
                                    selectedDistributorId = distributor.id
                                }) {
                                    HStack {
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(distributor.name)
                                                .font(.headline)
                                                .foregroundColor(.primary)
                                            
                                            Text("Typ: \(distributor.type)")
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                            
                                            if distributor.isCustom {
                                                Text("Benutzerdefiniert")
                                                    .font(.caption)
                                                    .foregroundColor(.green)
                                                    .padding(.horizontal, 6)
                                                    .padding(.vertical, 2)
                                                    .background(Color.green.opacity(0.1))
                                                    .cornerRadius(4)
                                            }
                                        }
                                        
                                        Spacer()
                                        
                                        if selectedDistributorId == distributor.id {
                                            Image(systemName: "checkmark.circle.fill")
                                                .foregroundColor(.blue)
                                        } else {
                                            Image(systemName: "circle")
                                                .foregroundColor(.gray)
                                        }
                                    }
                                    .padding(12)
                                    .background(selectedDistributorId == distributor.id ? Color.blue.opacity(0.1) : Color.gray.opacity(0.05))
                                    .cornerRadius(8)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(selectedDistributorId == distributor.id ? Color.blue : Color.gray.opacity(0.3), lineWidth: 1)
                                    )
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                    }
                }
                .frame(maxHeight: 300)
            }
            
            HStack {
                Button("Abbrechen") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                
                Button("Zuweisen") {
                    onSelect(selectedDistributorId)
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedDistributorId.isEmpty)
            }
        }
        .padding()
        .frame(width: 500, height: 600)
    }
}

// MARK: - Data Models
struct PlugboxData {
    let name: String
    let channels: Int
    let position: String
    let isCustom: Bool
}

// MARK: - PDF Creator
class SystemOverviewPDFCreator {
    func createSystemOverviewPDF(
        projectName: String,
        projectNumber: String?,
        systemData: [String: [PlugboxData]],
        electricalSystems: [ElectricalSystem],
        powerDistributors: [PowerDistributor],
        logoData: Data?
    ) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        let pageWidth: CGFloat = 595.2
        let pageHeight: CGFloat = 841.8
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        var logoCGImage: CGImage? = nil
        if let logoData = logoData {
            logoCGImage = createCGImageFromData(logoData)
        }
        
        let sortedSystems = Array(systemData.keys).sorted()
        
        for (index, systemName) in sortedSystems.enumerated() {
            pdfContext.beginPDFPage(nil)
            
            guard let plugboxes = systemData[systemName] else { continue }
            
            let system = electricalSystems.first { $0.name == systemName }
            let distributor = getDistributor(for: system, from: powerDistributors)
            
            drawSystemPage(
                context: pdfContext,
                pageRect: pageRect,
                projectName: projectName,
                projectNumber: projectNumber,
                systemName: systemName,
                system: system,
                distributor: distributor,
                plugboxes: plugboxes,
                pageNumber: index + 1,
                totalPages: sortedSystems.count,
                logoCGImage: logoCGImage
            )
            
            pdfContext.endPDFPage()
        }
        
        pdfContext.closePDF()
        return pdfData as Data
    }
    
    private func getDistributor(for system: ElectricalSystem?, from distributors: [PowerDistributor]) -> PowerDistributor? {
        guard let system = system,
              let distributorId = system.powerDistributorId else { return nil }
        return distributors.first { $0.id == distributorId }
    }
    
    private func drawSystemPage(
        context: CGContext,
        pageRect: CGRect,
        projectName: String,
        projectNumber: String?,
        systemName: String,
        system: ElectricalSystem?,
        distributor: PowerDistributor?,
        plugboxes: [PlugboxData],
        pageNumber: Int,
        totalPages: Int,
        logoCGImage: CGImage?
    ) {
        let margin: CGFloat = 40
        
        let systemColor = generateSystemColor(for: systemName)
        
        if let logo = logoCGImage {
            let logoRect = CGRect(x: pageRect.width - 120, y: pageRect.height - 50, width: 90, height: 30)
            let scaledLogoRect = calculateAspectFitRect(imageSize: CGSize(width: logo.width, height: logo.height), containerRect: logoRect)
            context.draw(logo, in: scaledLogoRect)
        }
        
        var headerText = projectName
        if let projectNumber = projectNumber, !projectNumber.isEmpty {
            headerText += " (\(projectNumber))"
        }
        drawText(context: context, text: headerText, rect: CGRect(x: margin, y: pageRect.height - 50, width: pageRect.width - 2 * margin, height: 25), fontSize: 18, bold: true)
        drawText(context: context, text: "System-Übersicht", rect: CGRect(x: margin, y: pageRect.height - 75, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true)
        
        var currentY = pageRect.height - 120
        
        let systemInfoRect = CGRect(x: margin, y: currentY - 120, width: pageRect.width - 2 * margin, height: 120)
        context.setFillColor(red: systemColor.red, green: systemColor.green, blue: systemColor.blue, alpha: 0.15)
        context.fill(systemInfoRect)
        context.setStrokeColor(red: systemColor.red, green: systemColor.green, blue: systemColor.blue, alpha: 0.8)
        context.setLineWidth(2.0)
        context.stroke(systemInfoRect)
        
        drawText(context: context, text: "System: \(systemName)", rect: CGRect(x: margin + 20, y: currentY - 25, width: 300, height: 15), fontSize: 16, bold: true)
        
        var infoY = currentY - 45
        
        if let system = system, !system.position.isEmpty {
            drawText(context: context, text: "Position: \(system.position)", rect: CGRect(x: margin + 20, y: infoY, width: 300, height: 12), fontSize: 11, bold: false)
            infoY -= 20
        }
        
        if let distributor = distributor {
            drawText(context: context, text: "Stromverteiler: \(distributor.name)", rect: CGRect(x: margin + 20, y: infoY, width: 400, height: 12), fontSize: 11, bold: false)
            infoY -= 15
            drawText(context: context, text: "Typ: \(distributor.type)", rect: CGRect(x: margin + 20, y: infoY, width: 400, height: 12), fontSize: 11, bold: false)
        } else {
            drawText(context: context, text: "Stromverteiler: Nicht zugewiesen", rect: CGRect(x: margin + 20, y: infoY, width: 400, height: 12), fontSize: 11, bold: false)
        }
        
        currentY -= 150
        
        drawText(context: context, text: "Plugboxen (\(plugboxes.count)):", rect: CGRect(x: margin, y: currentY, width: 300, height: 15), fontSize: 14, bold: true)
        currentY -= 30
        
        // Tabellen-Header (nur "Name" Spalte)
        let tableHeaderRect = CGRect(x: margin, y: currentY, width: pageRect.width - 2 * margin, height: 20)
        context.setFillColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        context.fill(tableHeaderRect)
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(tableHeaderRect)
        
        drawText(context: context, text: "Name", rect: CGRect(x: margin + 10, y: currentY + 3, width: pageRect.width - 2 * margin - 20, height: 14), fontSize: 10, bold: true)
        
        currentY -= 20
        
        // Plugbox Zeilen (nur "Name" Spalte) - Einheitliche Farben
        for (index, plugbox) in plugboxes.enumerated() {
            let rowRect = CGRect(x: margin, y: currentY - CGFloat(index) * 18, width: pageRect.width - 2 * margin, height: 18)
            
            if index % 2 == 0 {
                context.setFillColor(red: 0.98, green: 0.98, blue: 0.98, alpha: 1.0)
            } else {
                context.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            }
            
            context.fill(rowRect)
            context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
            context.setLineWidth(0.5)
            context.stroke(rowRect)
            
            drawText(context: context, text: plugbox.name, rect: CGRect(x: margin + 10, y: currentY - CGFloat(index) * 18 + 2, width: pageRect.width - 2 * margin - 20, height: 14), fontSize: 9, bold: false)
        }
        
        // Footer
        let footerY: CGFloat = 30
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.locale = Locale(identifier: "de_DE")
        let currentDate = dateFormatter.string(from: Date())
        
        drawText(context: context, text: " \(currentDate)", rect: CGRect(x: margin, y: footerY, width: 200, height: 15), fontSize: 10, bold: false)
        drawText(context: context, text: "Seite \(pageNumber) von \(totalPages)", rect: CGRect(x: pageRect.width - 150, y: footerY, width: 130, height: 15), fontSize: 10, bold: false)
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: rect.minX + 2, y: rect.minY + 2)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        context.restoreGState()
    }
    
    private func createCGImageFromData(_ data: Data) -> CGImage? {
        guard let dataProvider = CGDataProvider(data: data as CFData),
              let cgImage = CGImage(
                pngDataProviderSource: dataProvider,
                decode: nil,
                shouldInterpolate: true,
                intent: .defaultIntent
              ) else {
            guard let dataProvider = CGDataProvider(data: data as CFData),
                  let cgImage = CGImage(
                    jpegDataProviderSource: dataProvider,
                    decode: nil,
                    shouldInterpolate: true,
                    intent: .defaultIntent
                  ) else {
                return nil
            }
            return cgImage
        }
        return cgImage
    }
    
    private func calculateAspectFitRect(imageSize: CGSize, containerRect: CGRect) -> CGRect {
        let imageAspectRatio = imageSize.width / imageSize.height
        let containerAspectRatio = containerRect.width / containerRect.height
        
        var resultRect = containerRect
        
        if imageAspectRatio > containerAspectRatio {
            resultRect.size.height = containerRect.width / imageAspectRatio
            resultRect.origin.y = containerRect.origin.y + (containerRect.height - resultRect.height) / 2
        } else {
            resultRect.size.width = containerRect.height * imageAspectRatio
            resultRect.origin.x = containerRect.origin.x + (containerRect.width - resultRect.width) / 2
        }
        
        return resultRect
    }
    
    private func generateSystemColor(for systemName: String) -> (red: CGFloat, green: CGFloat, blue: CGFloat) {
        let hash = abs(systemName.hashValue)
        
        let predefinedColors: [(CGFloat, CGFloat, CGFloat)] = [
            (0.2, 0.4, 0.8), 
            (0.8, 0.2, 0.4), 
            (0.2, 0.8, 0.4), 
            (0.8, 0.6, 0.2), 
            (0.6, 0.2, 0.8), 
            (0.2, 0.8, 0.8), 
            (0.8, 0.8, 0.2), 
            (0.8, 0.4, 0.6), 
            (0.4, 0.6, 0.8), 
            (0.6, 0.8, 0.4)  
        ]
        
        let colorIndex = hash % predefinedColors.count
        let color = predefinedColors[colorIndex]
        
        return (red: color.0, green: color.1, blue: color.2)
    }
}
