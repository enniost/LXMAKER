import SwiftUI
import SwiftData
import AppKit

struct ProjectOverviewView: View {
    @Bindable var project: Project
    let modelContext: ModelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedTypeColumn = ""
    @State private var selectedModeColumn = ""
    @State private var selectedUniverseColumn = ""
    @State private var analysisResults: ProjectAnalysisResults?
    @State private var logoOption: LogoOption = .none
    @State private var uploadedLogoData: Data? = nil
    @State private var showLogoImporter = false
    
    enum LogoOption: String, CaseIterable {
        case none = "Kein Logo"
        case upload = "Logo hochladen"
        case habegger = "Habegger Logo"
    }
    
    private var availableColumns: [String] {
        project.columnOrder.isEmpty ? [] : project.columnOrder
    }
    
    private var canAnalyze: Bool {
        !selectedTypeColumn.isEmpty && !project.fixtures.isEmpty
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Projekt Übersicht")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        Text("Erstellt eine detaillierte Übersicht über Fixture-Typen, Modi und Universen")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        if availableColumns.isEmpty {
                            Text("⚠️ Keine CSV-Daten gefunden. Bitte importieren Sie zuerst eine CSV-Datei.")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack(alignment: .top, spacing: 30) {
                        // Left Column - Configuration
                        VStack(spacing: 25) {
                            // Column Selection
                            columnSelectionView
                            
                            // Logo Settings
                            logoSettingsView
                            
                            // Analysis Button
                            Button("Projekt analysieren") {
                                analyzeProject()
                            }
                            .disabled(!canAnalyze)
                            .buttonStyle(.bordered)
                            .controlSize(.large)
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Right Column - Results
                        VStack(alignment: .leading, spacing: 20) {
                            if let results = analysisResults {
                                analysisResultsView(results: results)
                            } else {
                                VStack(alignment: .leading, spacing: 15) {
                                    Text("Anleitung:")
                                        .font(.headline)
                                        .fontWeight(.medium)
                                    
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text("• Wählen Sie die Spalte für Fixture-Typen (erforderlich)")
                                        Text("• Optional: Spalte für Modi auswählen")
                                        Text("• Optional: Spalte für Universen auswählen")
                                        Text("• Klicken Sie auf 'Projekt analysieren'")
                                        Text("• Exportieren Sie die Übersicht als PDF")
                                    }
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                    
                                    Spacer()
                                }
                                .padding(15)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Export Button
                    if analysisResults != nil {
                        Button("PDF exportieren") {
                            exportPDF()
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.large)
                        .padding(.bottom, 20)
                    }
                }
                .padding(20)
            }
            .navigationTitle("Projekt Übersicht")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Schließen") {
                        saveSettings()
                        dismiss()
                    }
                }
            }
            .frame(minWidth: 1400, minHeight: 900)
            .fileImporter(
                isPresented: $showLogoImporter,
                allowedContentTypes: [.png, .jpeg, .tiff, .bmp],
                allowsMultipleSelection: false
            ) { result in
                handleLogoImport(result: result)
            }
            .onAppear {
                loadSettings()
            }
        }
    }
    
    private var columnSelectionView: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Spalten-Zuordnung:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 15) {
                // Fixture Type Column (Required)
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Fixture-Typ:")
                            .frame(width: 120, alignment: .leading)
                            .fontWeight(.medium)
                        Picker("Fixture-Typ", selection: $selectedTypeColumn) {
                            Text("-- Auswählen --").tag("")
                            ForEach(availableColumns, id: \.self) { column in
                                Text(column).tag(column)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 200)
                    }
                    Text("Erforderlich: Spalte mit Fixture-Typen/Modellen")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                // Mode Column (Optional)
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("DMX-Modus:")
                            .frame(width: 120, alignment: .leading)
                            .fontWeight(.medium)
                        Picker("DMX-Modus", selection: $selectedModeColumn) {
                            Text("-- Optional --").tag("")
                            ForEach(availableColumns, id: \.self) { column in
                                Text(column).tag(column)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 200)
                    }
                    Text("Optional: Spalte mit DMX-Modi der Fixtures")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                // Universe Column (Optional)
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Universum:")
                            .frame(width: 120, alignment: .leading)
                            .fontWeight(.medium)
                        Picker("Universum", selection: $selectedUniverseColumn) {
                            Text("-- Optional --").tag("")
                            ForEach(availableColumns, id: \.self) { column in
                                Text(column).tag(column)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 200)
                    }
                    Text("Optional: Spalte mit DMX-Universen")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(20)
        .background(Color.blue.opacity(0.05))
        .cornerRadius(12)
    }
    
    private var logoSettingsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Logo-Einstellungen:")
                .font(.headline)
                .fontWeight(.medium)
            
            VStack(spacing: 12) {
                Picker("Logo-Option", selection: $logoOption) {
                    ForEach(LogoOption.allCases, id: \.self) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: logoOption) { _, _ in
                    if logoOption != .upload {
                        uploadedLogoData = nil
                    }
                }
                
                if logoOption == .upload {
                    HStack {
                        Button("Logo auswählen") {
                            showLogoImporter = true
                        }
                        .buttonStyle(.bordered)
                        
                        if uploadedLogoData != nil {
                            Button("Logo entfernen") {
                                uploadedLogoData = nil
                            }
                            .buttonStyle(.bordered)
                            .foregroundColor(.red)
                        }
                    }
                }
                
                // Logo Preview
                if logoOption == .upload {
                    if let logoData = uploadedLogoData, let nsImage = NSImage(data: logoData) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Logo-Vorschau:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                } else if logoOption == .habegger {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logo-Vorschau:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        if let logoData = createHabeggerLogoData(), let nsImage = NSImage(data: logoData) {
                            Image(nsImage: nsImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 50)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        } else {
                            HStack {
                                Rectangle()
                                    .fill(Color(red: 0.8, green: 0.68, blue: 0.4))
                                    .frame(height: 8)
                                    .overlay(
                                        Text("HABEGGER")
                                            .font(.caption)
                                            .fontWeight(.bold)
                                            .foregroundColor(.black)
                                    )
                            }
                            .frame(width: 150, height: 30)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                        }
                    }
                }
            }
        }
        .padding(15)
        .background(Color.orange.opacity(0.1))
        .cornerRadius(10)
    }
    
    private func analysisResultsView(results: ProjectAnalysisResults) -> some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Analyse-Ergebnisse:")
                .font(.headline)
                .fontWeight(.medium)
            
            // Summary Cards
            VStack(spacing: 12) {
                // Total Fixtures
                HStack {
                    Text("Gesamte Fixtures:")
                        .fontWeight(.medium)
                    Spacer()
                    Text("\(results.totalFixtures)")
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.blue.opacity(0.1))
                .cornerRadius(8)
                
                // Fixture Types
                HStack {
                    Text("Fixture-Typen:")
                        .fontWeight(.medium)
                    Spacer()
                    Text("\(results.fixtureTypes.count)")
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.green.opacity(0.1))
                .cornerRadius(8)
                
                // Modes (if available)
                if !results.modes.isEmpty {
                    HStack {
                        Text("DMX-Modi:")
                            .fontWeight(.medium)
                        Spacer()
                        Text("\(results.modes.count)")
                            .fontWeight(.bold)
                            .foregroundColor(.purple)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.purple.opacity(0.1))
                    .cornerRadius(8)
                }
                
                // Universes (if available)
                if !results.universes.isEmpty {
                    HStack {
                        Text("Universen:")
                            .fontWeight(.medium)
                        Spacer()
                        Text("\(results.universes.count)")
                            .fontWeight(.bold)
                            .foregroundColor(.orange)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(8)
                }
            }
            
            // Top Fixture Types
            if !results.fixtureTypes.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Top Fixture-Typen:")
                        .fontWeight(.medium)
                        .foregroundColor(.green)
                    
                    ScrollView {
                        LazyVStack(spacing: 4) {
                            ForEach(Array(results.fixtureTypes.sorted { $0.value > $1.value }.prefix(5)), id: \.key) { type, count in
                                HStack {
                                    Text(type.isEmpty ? "Unbekannt" : type)
                                        .font(.subheadline)
                                    Spacer()
                                    Text("\(count)")
                                        .font(.subheadline)
                                        .fontWeight(.medium)
                                        .foregroundColor(.green)
                                }
                                .padding(.horizontal, 8)
                                .padding(.vertical, 2)
                                .background(Color.green.opacity(0.05))
                                .cornerRadius(4)
                            }
                        }
                    }
                    .frame(maxHeight: 120)
                }
            }
        }
        .padding(15)
        .background(Color.gray.opacity(0.05))
        .cornerRadius(10)
    }
    
    private func analyzeProject() {
        guard !selectedTypeColumn.isEmpty else { return }
        
        var fixtureTypes: [String: Int] = [:]
        var modes: [String: Int] = [:]
        var universes: [String: Int] = [:]
        
        for fixture in project.fixtures {
            // Analyze fixture types
            let type = fixture.rawData[selectedTypeColumn] ?? ""
            fixtureTypes[type] = (fixtureTypes[type] ?? 0) + 1
            
            // Analyze modes (if selected)
            if !selectedModeColumn.isEmpty {
                let mode = fixture.rawData[selectedModeColumn] ?? ""
                if !mode.isEmpty {
                    modes[mode] = (modes[mode] ?? 0) + 1
                }
            }
            
            // Analyze universes (if selected)
            if !selectedUniverseColumn.isEmpty {
                let universe = fixture.rawData[selectedUniverseColumn] ?? ""
                if !universe.isEmpty {
                    universes[universe] = (universes[universe] ?? 0) + 1
                }
            }
        }
        
        analysisResults = ProjectAnalysisResults(
            totalFixtures: project.fixtures.count,
            fixtureTypes: fixtureTypes,
            modes: modes,
            universes: universes,
            selectedTypeColumn: selectedTypeColumn,
            selectedModeColumn: selectedModeColumn.isEmpty ? nil : selectedModeColumn,
            selectedUniverseColumn: selectedUniverseColumn.isEmpty ? nil : selectedUniverseColumn
        )
    }
    
    private func exportPDF() {
        guard let results = analysisResults else { return }
        
        var logoData: Data? = nil
        switch logoOption {
        case .none:
            logoData = nil
        case .upload:
            logoData = uploadedLogoData
        case .habegger:
            logoData = createHabeggerLogoData()
        }
        
        let pdfCreator = ProjectOverviewPDFCreator()
        let pdfData = pdfCreator.createPDF(
            projectName: project.name,
            analysisResults: results,
            logoData: logoData
        )
        
        let filename = "Projekt_Uebersicht_\(project.name).pdf"
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = filename
        savePanel.allowedContentTypes = [.pdf]
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            do {
                try pdfData.write(to: url)
                let alert = NSAlert()
                alert.messageText = "PDF erstellt"
                alert.informativeText = "Die Projekt-Übersicht wurde erfolgreich als PDF gespeichert."
                alert.alertStyle = .informational
                alert.runModal()
            } catch {
                let alert = NSAlert()
                alert.messageText = "Fehler beim Speichern"
                alert.informativeText = "Das PDF konnte nicht gespeichert werden: \(error.localizedDescription)"
                alert.alertStyle = .warning
                alert.runModal()
            }
        }
    }
    
    private func handleLogoImport(result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            
            do {
                let securityScopedFile = url.startAccessingSecurityScopedResource()
                defer {
                    if securityScopedFile {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                
                uploadedLogoData = try Data(contentsOf: url)
            } catch {
                print("Fehler beim Laden des Logos: \(error)")
            }
            
        case .failure(let error):
            print("Fehler beim Auswählen des Logos: \(error)")
        }
    }
    
    private func createHabeggerLogoData() -> Data? {
        if let assetLogo = NSImage(named: "HabeggerLogo") {
            guard let tiffData = assetLogo.tiffRepresentation,
                  let bitmapRep = NSBitmapImageRep(data: tiffData),
                  let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
                return nil
            }
            return pngData
        }
        
        let logoSize = CGSize(width: 300, height: 80)
        let image = NSImage(size: logoSize)
        
        image.lockFocus()
        
        NSColor.clear.set()
        NSBezierPath.fill(NSRect(origin: .zero, size: logoSize))
        
        let goldColor = NSColor(red: 0.8, green: 0.68, blue: 0.4, alpha: 1.0)
        goldColor.setFill()
        let goldBarRect = NSRect(x: 0, y: 15, width: logoSize.width, height: 15)
        NSBezierPath.fill(goldBarRect)
        
        let font = NSFont.boldSystemFont(ofSize: 48)
        let textColor = NSColor.black
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: textColor
        ]
        
        let text = "HABEGGER"
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let textSize = attributedString.size()
        
        let textRect = NSRect(
            x: (logoSize.width - textSize.width) / 2,
            y: 35,
            width: textSize.width,
            height: textSize.height
        )
        
        attributedString.draw(in: textRect)
        
        image.unlockFocus()
        
        guard let tiffData = image.tiffRepresentation,
              let bitmapRep = NSBitmapImageRep(data: tiffData),
              let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
            return nil
        }
        
        return pngData
    }
    
    private func loadSettings() {
        selectedTypeColumn = project.overviewTypeColumn ?? ""
        selectedModeColumn = project.overviewModeColumn ?? ""
        selectedUniverseColumn = project.overviewUniverseColumn ?? ""
    }
    
    private func saveSettings() {
        project.overviewTypeColumn = selectedTypeColumn.isEmpty ? nil : selectedTypeColumn
        project.overviewModeColumn = selectedModeColumn.isEmpty ? nil : selectedModeColumn
        project.overviewUniverseColumn = selectedUniverseColumn.isEmpty ? nil : selectedUniverseColumn
        project.updatedAt = Date()
        
        do {
            try modelContext.save()
        } catch {
            print("Failed to save Project Overview settings: \(error)")
        }
    }
}

// MARK: - Data Models
struct ProjectAnalysisResults {
    let totalFixtures: Int
    let fixtureTypes: [String: Int]
    let modes: [String: Int]
    let universes: [String: Int]
    let selectedTypeColumn: String
    let selectedModeColumn: String?
    let selectedUniverseColumn: String?
}

// MARK: - PDF Creator
class ProjectOverviewPDFCreator {
    func createPDF(projectName: String, analysisResults: ProjectAnalysisResults, logoData: Data?) -> Data {
        let pdfData = NSMutableData()
        let consumer = CGDataConsumer(data: pdfData)!
        
        let pageWidth: CGFloat = 595.2
        let pageHeight: CGFloat = 841.8
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        var mediaBox = pageRect
        let pdfContext = CGContext(consumer: consumer, mediaBox: &mediaBox, nil)!
        
        var logoCGImage: CGImage? = nil
        if let logoData = logoData {
            logoCGImage = createCGImageFromData(logoData)
        }
        
        pdfContext.beginPDFPage(nil)
        
        drawProjectOverviewPage(
            context: pdfContext,
            projectName: projectName,
            analysisResults: analysisResults,
            pageRect: pageRect,
            logoCGImage: logoCGImage
        )
        
        pdfContext.endPDFPage()
        pdfContext.closePDF()
        
        return pdfData as Data
    }
    
    private func createCGImageFromData(_ data: Data) -> CGImage? {
        guard let dataProvider = CGDataProvider(data: data as CFData),
              let cgImage = CGImage(
                pngDataProviderSource: dataProvider,
                decode: nil,
                shouldInterpolate: true,
                intent: .defaultIntent
              ) else {
            guard let dataProvider = CGDataProvider(data: data as CFData),
                  let cgImage = CGImage(
                    jpegDataProviderSource: dataProvider,
                    decode: nil,
                    shouldInterpolate: true,
                    intent: .defaultIntent
                  ) else {
                return nil
            }
            return cgImage
        }
        return cgImage
    }
    
    private func drawProjectOverviewPage(context: CGContext, projectName: String, analysisResults: ProjectAnalysisResults, pageRect: CGRect, logoCGImage: CGImage?) {
        let margin: CGFloat = 40
        
        // Logo
        if let logo = logoCGImage {
            let logoRect = CGRect(x: pageRect.width - 120, y: pageRect.height - 50, width: 90, height: 30)
            let scaledLogoRect = calculateAspectFitRect(imageSize: CGSize(width: logo.width, height: logo.height), containerRect: logoRect)
            context.draw(logo, in: scaledLogoRect)
        }
        
        // Title
        drawText(context: context, text: projectName, rect: CGRect(x: margin, y: pageRect.height - 50, width: pageRect.width - 2 * margin, height: 25), fontSize: 18, bold: true)
        drawText(context: context, text: "Projekt-Übersicht", rect: CGRect(x: margin, y: pageRect.height - 75, width: pageRect.width - 2 * margin, height: 20), fontSize: 14, bold: true)
        
        var currentY = pageRect.height - 120
        
        // Summary Box
        let summaryRect = CGRect(x: margin, y: currentY - 60, width: pageRect.width - 2 * margin, height: 60)
        context.setFillColor(red: 0.9, green: 0.95, blue: 1.0, alpha: 1.0)
        context.fill(summaryRect)
        context.setStrokeColor(red: 0.2, green: 0.4, blue: 0.8, alpha: 1.0)
        context.setLineWidth(2.0)
        context.stroke(summaryRect)
        
        drawText(context: context, text: "Projekt-Zusammenfassung", rect: CGRect(x: margin + 20, y: currentY - 20, width: 200, height: 15), fontSize: 14, bold: true)
        drawText(context: context, text: "Gesamte Fixtures: \(analysisResults.totalFixtures)", rect: CGRect(x: margin + 20, y: currentY - 40, width: 200, height: 12), fontSize: 11, bold: false)
        drawText(context: context, text: "Fixture-Typen: \(analysisResults.fixtureTypes.count)", rect: CGRect(x: margin + 250, y: currentY - 40, width: 200, height: 12), fontSize: 11, bold: false)
        
        if !analysisResults.modes.isEmpty {
            drawText(context: context, text: "DMX-Modi: \(analysisResults.modes.count)", rect: CGRect(x: margin + 20, y: currentY - 55, width: 200, height: 12), fontSize: 11, bold: false)
        }
        
        if !analysisResults.universes.isEmpty {
            drawText(context: context, text: "Universen: \(analysisResults.universes.count)", rect: CGRect(x: margin + 250, y: currentY - 55, width: 200, height: 12), fontSize: 11, bold: false)
        }
        
        currentY -= 90
        
        // Fixture Types Table
        drawFixtureTypesTable(context: context, fixtureTypes: analysisResults.fixtureTypes, startY: currentY, pageRect: pageRect)
        currentY -= CGFloat(min(analysisResults.fixtureTypes.count + 1, 15)) * 18 + 40
        
        // Modes Table (if available)
        if !analysisResults.modes.isEmpty && currentY > 200 {
            drawModesTable(context: context, modes: analysisResults.modes, startY: currentY, pageRect: pageRect)
            currentY -= CGFloat(min(analysisResults.modes.count + 1, 10)) * 18 + 40
        }
        
        // Universes Table (if available)
        if !analysisResults.universes.isEmpty && currentY > 200 {
            drawUniversesTable(context: context, universes: analysisResults.universes, startY: currentY, pageRect: pageRect)
        }
        
        // Footer
        let footerY: CGFloat = 30
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.locale = Locale(identifier: "de_DE")
        let currentDate = dateFormatter.string(from: Date())
        
        drawText(context: context, text: "Erstellt am: \(currentDate)", rect: CGRect(x: margin, y: footerY, width: 200, height: 15), fontSize: 10, bold: false)
        drawText(context: context, text: "Seite 1 von 1", rect: CGRect(x: pageRect.width - 150, y: footerY, width: 130, height: 15), fontSize: 10, bold: false)
    }
    
    private func drawFixtureTypesTable(context: CGContext, fixtureTypes: [String: Int], startY: CGFloat, pageRect: CGRect) {
        let margin: CGFloat = 40
        let tableWidth = pageRect.width - 2 * margin
        let rowHeight: CGFloat = 18
        
        var currentY = startY
        
        // Table Title
        drawText(context: context, text: "Fixture-Typen", rect: CGRect(x: margin, y: currentY, width: 200, height: 15), fontSize: 14, bold: true)
        currentY -= 25
        
        // Table Headers
        let headerRect = CGRect(x: margin, y: currentY, width: tableWidth, height: rowHeight)
        context.setFillColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        context.fill(headerRect)
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(headerRect)
        
        drawText(context: context, text: "Fixture-Typ", rect: CGRect(x: margin + 10, y: currentY + 3, width: tableWidth * 0.7, height: 14), fontSize: 10, bold: true)
        drawText(context: context, text: "Anzahl", rect: CGRect(x: margin + tableWidth * 0.7, y: currentY + 3, width: tableWidth * 0.25, height: 14), fontSize: 10, bold: true)
        
        currentY -= rowHeight
        
        // Table Rows
        let sortedTypes = fixtureTypes.sorted { $0.value > $1.value }
        for (index, (type, count)) in sortedTypes.enumerated() {
            if index >= 14 { break } // Limit rows to fit on page
            
            let rowRect = CGRect(x: margin, y: currentY, width: tableWidth, height: rowHeight)
            
            context.setFillColor(red: index % 2 == 0 ? 1.0 : 0.95, green: index % 2 == 0 ? 1.0 : 0.95, blue: index % 2 == 0 ? 1.0 : 0.95, alpha: 1.0)
            context.fill(rowRect)
            context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
            context.setLineWidth(0.5)
            context.stroke(rowRect)
            
            let displayType = type.isEmpty ? "Unbekannt" : type
            drawText(context: context, text: displayType, rect: CGRect(x: margin + 10, y: currentY + 2, width: tableWidth * 0.7 - 20, height: 14), fontSize: 9, bold: false)
            drawText(context: context, text: "\(count)", rect: CGRect(x: margin + tableWidth * 0.7, y: currentY + 2, width: tableWidth * 0.25, height: 14), fontSize: 9, bold: false)
            
            currentY -= rowHeight
        }
    }
    
    private func drawModesTable(context: CGContext, modes: [String: Int], startY: CGFloat, pageRect: CGRect) {
        let margin: CGFloat = 40
        let tableWidth = pageRect.width - 2 * margin
        let rowHeight: CGFloat = 18
        
        var currentY = startY
        
        // Table Title
        drawText(context: context, text: "DMX-Modi", rect: CGRect(x: margin, y: currentY, width: 200, height: 15), fontSize: 14, bold: true)
        currentY -= 25
        
        // Table Headers
        let headerRect = CGRect(x: margin, y: currentY, width: tableWidth, height: rowHeight)
        context.setFillColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        context.fill(headerRect)
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(headerRect)
        
        drawText(context: context, text: "DMX-Modus", rect: CGRect(x: margin + 10, y: currentY + 3, width: tableWidth * 0.7, height: 14), fontSize: 10, bold: true)
        drawText(context: context, text: "Anzahl", rect: CGRect(x: margin + tableWidth * 0.7, y: currentY + 3, width: tableWidth * 0.25, height: 14), fontSize: 10, bold: true)
        
        currentY -= rowHeight
        
        // Table Rows
        let sortedModes = modes.sorted { $0.value > $1.value }
        for (index, (mode, count)) in sortedModes.enumerated() {
            if index >= 9 { break } // Limit rows
            
            let rowRect = CGRect(x: margin, y: currentY, width: tableWidth, height: rowHeight)
            
            context.setFillColor(red: index % 2 == 0 ? 1.0 : 0.95, green: index % 2 == 0 ? 1.0 : 0.95, blue: index % 2 == 0 ? 1.0 : 0.95, alpha: 1.0)
            context.fill(rowRect)
            context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
            context.setLineWidth(0.5)
            context.stroke(rowRect)
            
            drawText(context: context, text: mode, rect: CGRect(x: margin + 10, y: currentY + 2, width: tableWidth * 0.7 - 20, height: 14), fontSize: 9, bold: false)
            drawText(context: context, text: "\(count)", rect: CGRect(x: margin + tableWidth * 0.7, y: currentY + 2, width: tableWidth * 0.25, height: 14), fontSize: 9, bold: false)
            
            currentY -= rowHeight
        }
    }
    
    private func drawUniversesTable(context: CGContext, universes: [String: Int], startY: CGFloat, pageRect: CGRect) {
        let margin: CGFloat = 40
        let tableWidth = pageRect.width - 2 * margin
        let rowHeight: CGFloat = 18
        
        var currentY = startY
        
        // Table Title
        drawText(context: context, text: "DMX-Universen", rect: CGRect(x: margin, y: currentY, width: 200, height: 15), fontSize: 14, bold: true)
        currentY -= 25
        
        // Table Headers
        let headerRect = CGRect(x: margin, y: currentY, width: tableWidth, height: rowHeight)
        context.setFillColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        context.fill(headerRect)
        context.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        context.setLineWidth(1.0)
        context.stroke(headerRect)
        
        drawText(context: context, text: "Universum", rect: CGRect(x: margin + 10, y: currentY + 3, width: tableWidth * 0.7, height: 14), fontSize: 10, bold: true)
        drawText(context: context, text: "Fixtures", rect: CGRect(x: margin + tableWidth * 0.7, y: currentY + 3, width: tableWidth * 0.25, height: 14), fontSize: 10, bold: true)
        
        currentY -= rowHeight
        
        // Table Rows - Sort universes numerically if possible
        let sortedUniverses = universes.sorted { (first, second) in
            if let firstNum = Int(first.key), let secondNum = Int(second.key) {
                return firstNum < secondNum
            }
            return first.key < second.key
        }
        
        for (index, (universe, count)) in sortedUniverses.enumerated() {
            if index >= 9 { break } // Limit rows
            
            let rowRect = CGRect(x: margin, y: currentY, width: tableWidth, height: rowHeight)
            
            context.setFillColor(red: index % 2 == 0 ? 1.0 : 0.95, green: index % 2 == 0 ? 1.0 : 0.95, blue: index % 2 == 0 ? 1.0 : 0.95, alpha: 1.0)
            context.fill(rowRect)
            context.setStrokeColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
            context.setLineWidth(0.5)
            context.stroke(rowRect)
            
            drawText(context: context, text: "Universe \(universe)", rect: CGRect(x: margin + 10, y: currentY + 2, width: tableWidth * 0.7 - 20, height: 14), fontSize: 9, bold: false)
            drawText(context: context, text: "\(count)", rect: CGRect(x: margin + tableWidth * 0.7, y: currentY + 2, width: tableWidth * 0.25, height: 14), fontSize: 9, bold: false)
            
            currentY -= rowHeight
        }
    }
    
    private func calculateAspectFitRect(imageSize: CGSize, containerRect: CGRect) -> CGRect {
        let imageAspectRatio = imageSize.width / imageSize.height
        let containerAspectRatio = containerRect.width / containerRect.height
        
        var resultRect = containerRect
        
        if imageAspectRatio > containerAspectRatio {
            resultRect.size.height = containerRect.width / imageAspectRatio
            resultRect.origin.y = containerRect.origin.y + (containerRect.height - resultRect.height) / 2
        } else {
            resultRect.size.width = containerRect.height * imageAspectRatio
            resultRect.origin.x = containerRect.origin.x + (containerRect.width - resultRect.width) / 2
        }
        
        return resultRect
    }
    
    private func drawText(context: CGContext, text: String, rect: CGRect, fontSize: CGFloat, bold: Bool) {
        let font = bold ? NSFont.boldSystemFont(ofSize: fontSize) : NSFont.systemFont(ofSize: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.black
        ]
        
        let attributedString = NSAttributedString(string: text, attributes: attributes)
        let line = CTLineCreateWithAttributedString(attributedString)
        
        context.saveGState()
        context.textMatrix = CGAffineTransform.identity
        context.textPosition = CGPoint(x: rect.minX + 2, y: rect.minY + 2)
        context.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        CTLineDraw(line, context)
        context.restoreGState()
    }
}
